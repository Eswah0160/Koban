// Versioned migrations. Each entry is a list of single SQL statements
// (the Android bridge executes one statement per call). Never edit a shipped
// migration — append a new one.
//
// NOTE: capture_inbox / capture_seen / capture_sources are ALSO created by the
// native NotificationListener (Db.java) so capture works before the UI has
// ever run. Keep those DDL strings identical in both places.

export const CAPTURE_DDL = [
  `CREATE TABLE IF NOT EXISTS capture_inbox(id INTEGER PRIMARY KEY AUTOINCREMENT, pkg TEXT NOT NULL, title TEXT, text TEXT, posted_at INTEGER NOT NULL, status TEXT NOT NULL DEFAULT 'new', txn_id INTEGER, note TEXT)`,
  `CREATE TABLE IF NOT EXISTS capture_seen(pkg TEXT PRIMARY KEY, label TEXT, count INTEGER NOT NULL DEFAULT 0, last_seen INTEGER)`,
  `CREATE TABLE IF NOT EXISTS capture_sources(pkg TEXT PRIMARY KEY, enabled INTEGER NOT NULL DEFAULT 1, account_id INTEGER, pattern TEXT)`,
];

export const MIGRATIONS = [
  [
    `CREATE TABLE accounts(
      id INTEGER PRIMARY KEY, name TEXT NOT NULL, type TEXT NOT NULL DEFAULT 'checking',
      on_budget INTEGER NOT NULL DEFAULT 1, closed INTEGER NOT NULL DEFAULT 0,
      institution TEXT, last4 TEXT, color TEXT, note TEXT, sort INTEGER NOT NULL DEFAULT 0,
      created_at TEXT DEFAULT (datetime('now')))`,
    `CREATE TABLE category_groups(id INTEGER PRIMARY KEY, name TEXT NOT NULL, sort INTEGER NOT NULL DEFAULT 0, hidden INTEGER NOT NULL DEFAULT 0, system TEXT)`,
    `CREATE TABLE categories(
      id INTEGER PRIMARY KEY, group_id INTEGER NOT NULL, name TEXT NOT NULL, sort INTEGER NOT NULL DEFAULT 0,
      hidden INTEGER NOT NULL DEFAULT 0, note TEXT, emoji TEXT, system TEXT, cc_account_id INTEGER,
      target_type TEXT, target_amount INTEGER, target_date TEXT, target_freq TEXT)`,
    `CREATE TABLE transactions(
      id INTEGER PRIMARY KEY, account_id INTEGER NOT NULL, date TEXT NOT NULL, amount INTEGER NOT NULL,
      payee TEXT, category_id INTEGER, memo TEXT, cleared TEXT NOT NULL DEFAULT 'uncleared',
      approved INTEGER NOT NULL DEFAULT 1, flag TEXT, transfer_account_id INTEGER, transfer_txn_id INTEGER,
      is_split INTEGER NOT NULL DEFAULT 0, is_opening INTEGER NOT NULL DEFAULT 0, source TEXT NOT NULL DEFAULT 'manual',
      import_id TEXT, raw_payee TEXT, receipt_id INTEGER, scheduled_id INTEGER,
      created_at TEXT DEFAULT (datetime('now')), updated_at TEXT DEFAULT (datetime('now')))`,
    `CREATE INDEX ix_txn_date ON transactions(date)`,
    `CREATE INDEX ix_txn_account ON transactions(account_id, date)`,
    `CREATE INDEX ix_txn_category ON transactions(category_id)`,
    `CREATE INDEX ix_txn_import ON transactions(import_id)`,
    `CREATE TABLE splits(id INTEGER PRIMARY KEY, txn_id INTEGER NOT NULL, category_id INTEGER, amount INTEGER NOT NULL, memo TEXT)`,
    `CREATE INDEX ix_split_txn ON splits(txn_id)`,
    `CREATE TABLE assignments(month TEXT NOT NULL, category_id INTEGER NOT NULL, amount INTEGER NOT NULL DEFAULT 0, PRIMARY KEY(month, category_id))`,
    `CREATE TABLE scheduled(
      id INTEGER PRIMARY KEY, account_id INTEGER NOT NULL, payee TEXT, amount INTEGER NOT NULL, category_id INTEGER,
      transfer_account_id INTEGER, memo TEXT, freq TEXT NOT NULL DEFAULT 'monthly', next_date TEXT NOT NULL,
      end_date TEXT, auto_enter INTEGER NOT NULL DEFAULT 0, active INTEGER NOT NULL DEFAULT 1)`,
    `CREATE TABLE rules(
      id INTEGER PRIMARY KEY, match_type TEXT NOT NULL DEFAULT 'contains', pattern TEXT NOT NULL,
      set_payee TEXT, set_category_id INTEGER, account_id INTEGER, priority INTEGER NOT NULL DEFAULT 0,
      enabled INTEGER NOT NULL DEFAULT 1, hits INTEGER NOT NULL DEFAULT 0, created_at TEXT DEFAULT (datetime('now')))`,
    `CREATE TABLE receipts(id INTEGER PRIMARY KEY, path TEXT, ai_json TEXT, ocr_text TEXT, created_at TEXT DEFAULT (datetime('now')))`,
    `CREATE TABLE card_map(last4 TEXT PRIMARY KEY, account_id INTEGER NOT NULL)`,
    ...CAPTURE_DDL,
  ],
];
