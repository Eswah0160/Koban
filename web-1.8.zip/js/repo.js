// Data access + domain operations. All writes go through here.
import { db, meta, setMeta } from './db.js';
import { computeBudget } from './engine/budget.js';
import { addMonths, monthOf, nextOccurrence, normPayee, prettyPayee, thisMonth, today } from './util.js';

export const ACCOUNT_TYPES = {
  checking: { label: 'Everyday', budget: true },
  savings: { label: 'Savings', budget: true },
  cash: { label: 'Cash', budget: true },
  credit: { label: 'Credit card', budget: true },
  investment: { label: 'Investment', budget: false },
  super: { label: 'Super', budget: false },
  asset: { label: 'Other asset', budget: false },
  loan: { label: 'Loan', budget: false },
  mortgage: { label: 'Mortgage', budget: false },
};

// ---------- reference data ----------
export const accounts = (all = false) => db.all(`SELECT * FROM accounts ${all ? '' : 'WHERE closed=0'} ORDER BY on_budget DESC, sort, id`);
export const account = (id) => db.get('SELECT * FROM accounts WHERE id=?', [id]);
export const groups = () => db.all('SELECT * FROM category_groups ORDER BY sort, id');
export const categories = () => db.all('SELECT * FROM categories ORDER BY sort, id');
export const category = (id) => db.get('SELECT * FROM categories WHERE id=?', [id]);
export const incomeCategoryId = () => db.val("SELECT id FROM categories WHERE system='income' LIMIT 1");

export function categoryIndex() {
  const gs = groups();
  const cs = categories();
  const byId = new Map(cs.map((c) => [c.id, c]));
  const gById = new Map(gs.map((g) => [g.id, g]));
  return { groups: gs, categories: cs, byId, gById, name: (id) => (id == null || id === 0 ? 'Uncategorised' : byId.get(id)?.name ?? 'Deleted category') };
}

// ---------- setup ----------
export const TEMPLATE = [
  ['Bills', ['Rent', 'Electricity & Gas', 'Phone & Internet', 'Insurance', 'Subscriptions']],
  ['Everyday', ['Groceries', 'Eating Out', 'Transport', 'Fuel & Car', 'Health', 'Personal Care', 'Household']],
  ['Lifestyle', ['Entertainment', 'Clothing', 'Gifts', 'Hobbies', 'Holidays']],
  ['Work & Study', ['Uni & Lab', 'Tech & Software']],
  ['Savings Goals', ['Emergency Fund', 'Big Purchases']],
];

export function isSetUp() { return !!db.val("SELECT id FROM category_groups WHERE system='income'"); }

export function seed({ template = true } = {}) {
  db.tx(() => {
    const inc = db.insert('category_groups', { name: 'Income', sort: -100, hidden: 1, system: 'income' });
    db.insert('categories', { group_id: inc, name: 'Ready to Assign', system: 'income' });
    db.insert('category_groups', { name: 'Credit Card Payments', sort: -50, system: 'ccp' });
    if (template) {
      TEMPLATE.forEach(([g, cats], gi) => {
        const gid = db.insert('category_groups', { name: g, sort: gi + 1 });
        cats.forEach((c, ci) => db.insert('categories', { group_id: gid, name: c, sort: ci }));
      });
    }
  });
}

export function createAccount({ name, type = 'checking', balance = 0, date = today(), institution = null, last4 = null, on_budget }) {
  const onb = on_budget ?? (ACCOUNT_TYPES[type]?.budget ? 1 : 0);
  return db.tx(() => {
    const sort = (db.val('SELECT MAX(sort) FROM accounts') || 0) + 1;
    const id = db.insert('accounts', { name, type, on_budget: onb ? 1 : 0, institution, last4, sort });
    if (type === 'credit' && onb) ensureCcpCategory(id, name);
    if (balance) {
      const incomeCat = onb && type !== 'credit' && balance > 0 ? incomeCategoryId() : null;
      db.insert('transactions', {
        account_id: id, date, amount: balance, payee: 'Starting balance', category_id: incomeCat,
        cleared: 'cleared', is_opening: 1, source: 'manual',
      });
    }
    if (last4) db.run('INSERT OR REPLACE INTO card_map(last4, account_id) VALUES(?,?)', [last4, id]);
    return id;
  });
}

function ensureCcpCategory(accountId, name) {
  if (db.val("SELECT id FROM categories WHERE system='ccp' AND cc_account_id=?", [accountId])) return;
  let g = db.val("SELECT id FROM category_groups WHERE system='ccp'");
  if (!g) g = db.insert('category_groups', { name: 'Credit Card Payments', sort: -50, system: 'ccp' });
  db.insert('categories', { group_id: g, name, system: 'ccp', cc_account_id: accountId });
}

export function updateAccount(id, patch) {
  db.tx(() => {
    db.update('accounts', id, patch);
    if (patch.name) db.run("UPDATE categories SET name=? WHERE system='ccp' AND cc_account_id=?", [patch.name, id]);
    if (patch.last4) db.run('INSERT OR REPLACE INTO card_map(last4, account_id) VALUES(?,?)', [patch.last4, id]);
  });
}

// ---------- transactions ----------
export function txn(id) {
  const t = db.get('SELECT * FROM transactions WHERE id=?', [id]);
  if (t && t.is_split) t.splits = db.all('SELECT * FROM splits WHERE txn_id=? ORDER BY id', [id]);
  return t;
}

/**
 * Save a transaction (insert when no id). Handles transfers (paired rows) and splits.
 * t: {id?, account_id, date, amount, payee, category_id, memo, cleared, approved, flag,
 *     transfer_account_id?, splits?: [{category_id, amount, memo}], source?, import_id?, raw_payee?, receipt_id?}
 */
export function saveTxn(t) {
  invalidateSuggestions();
  return db.tx(() => {
    const prev = t.id ? db.get('SELECT * FROM transactions WHERE id=?', [t.id]) : null;
    const splits = t.splits && t.splits.length > 1 ? t.splits : null;
    const A = account(t.account_id);
    const B = t.transfer_account_id ? account(t.transfer_account_id) : null;
    // Category lives on the on-budget side of a transfer (none if both sides are on-budget).
    const catOnPair = !!(B && !A?.on_budget && B.on_budget);
    const noCat = splits || (B && A?.on_budget && B.on_budget) || catOnPair;
    const row = {
      account_id: t.account_id, date: t.date, amount: t.amount, payee: t.payee ?? null,
      category_id: noCat ? null : (t.category_id ?? null),
      memo: t.memo ?? null, cleared: t.cleared || 'uncleared', approved: t.approved ?? 1, flag: t.flag ?? null,
      transfer_account_id: t.transfer_account_id || null, is_split: splits ? 1 : 0,
      source: t.source || prev?.source || 'manual', import_id: t.import_id ?? prev?.import_id ?? null,
      raw_payee: t.raw_payee ?? prev?.raw_payee ?? null, receipt_id: t.receipt_id ?? prev?.receipt_id ?? null,
      scheduled_id: t.scheduled_id ?? prev?.scheduled_id ?? null,
    };
    let id = t.id;
    if (id) db.update('transactions', id, { ...row, updated_at: new Date().toISOString() });
    else id = db.insert('transactions', row);

    // splits
    db.run('DELETE FROM splits WHERE txn_id=?', [id]);
    if (splits) for (const s of splits) db.insert('splits', { txn_id: id, category_id: s.category_id ?? null, amount: s.amount, memo: s.memo ?? null });

    // transfer pairing
    const pairId = prev?.transfer_txn_id || null;
    if (row.transfer_account_id) {
      const other = account(row.transfer_account_id);
      const pair = {
        account_id: row.transfer_account_id, date: row.date, amount: -row.amount,
        payee: 'Transfer: ' + (account(row.account_id)?.name ?? ''), memo: row.memo,
        transfer_account_id: row.account_id, transfer_txn_id: id, approved: 1,
        category_id: catOnPair ? (t.category_id ?? null) : null, source: row.source,
      };
      let pid = pairId;
      if (pid && db.get('SELECT id FROM transactions WHERE id=?', [pid])) {
        const keepCleared = db.val('SELECT cleared FROM transactions WHERE id=?', [pid]);
        db.update('transactions', pid, { ...pair, cleared: keepCleared });
      } else pid = db.insert('transactions', { ...pair, cleared: 'uncleared' });
      db.update('transactions', id, { transfer_txn_id: pid, payee: row.payee || 'Transfer: ' + (other?.name ?? '') });
    } else if (pairId) {
      db.run('DELETE FROM transactions WHERE id=?', [pairId]);
      db.update('transactions', id, { transfer_txn_id: null });
    }
    return id;
  });
}

export function deleteTxn(id) {
  invalidateSuggestions();
  db.tx(() => {
    const t = db.get('SELECT * FROM transactions WHERE id=?', [id]);
    if (!t) return;
    db.run('DELETE FROM splits WHERE txn_id=?', [id]);
    if (t.transfer_txn_id) db.run('DELETE FROM transactions WHERE id=?', [t.transfer_txn_id]);
    db.run('DELETE FROM transactions WHERE id=?', [id]);
    db.run("UPDATE capture_inbox SET status='ignored', txn_id=NULL WHERE txn_id=?", [id]);
  });
}

export function setCleared(id, cleared) { db.update('transactions', id, { cleared }); }
export function approve(ids) { db.tx(() => ids.forEach((id) => db.update('transactions', id, { approved: 1 }))); }

export function listTxns({ accountId = null, categoryId = null, q = '', month = null, unapproved = false, flagged = false, uncategorised = false, limit = 300, offset = 0 } = {}) {
  const w = [];
  const p = [];
  if (accountId) { w.push('t.account_id=?'); p.push(accountId); }
  if (categoryId != null) { w.push('(t.category_id=? OR EXISTS(SELECT 1 FROM splits s WHERE s.txn_id=t.id AND s.category_id=?))'); p.push(categoryId, categoryId); }
  if (month) { w.push('substr(t.date,1,7)=?'); p.push(month); }
  if (unapproved) w.push('t.approved=0');
  if (flagged) w.push('t.flag IS NOT NULL');
  if (uncategorised) w.push(`t.category_id IS NULL AND t.is_split=0 AND t.is_opening=0 AND (t.transfer_account_id IS NULL OR EXISTS(SELECT 1 FROM accounts x WHERE x.id=t.transfer_account_id AND x.on_budget=0))
      AND EXISTS(SELECT 1 FROM accounts y WHERE y.id=t.account_id AND y.on_budget=1)`);
  if (q) {
    const amt = Number(q.replace(/[$,]/g, ''));
    if (!Number.isNaN(amt) && /\d/.test(q)) { w.push('(abs(t.amount)=? OR t.payee LIKE ? OR t.memo LIKE ?)'); p.push(Math.round(Math.abs(amt) * 100), `%${q}%`, `%${q}%`); }
    else { w.push('(t.payee LIKE ? OR t.memo LIKE ? OR t.raw_payee LIKE ? OR c.name LIKE ?)'); p.push(`%${q}%`, `%${q}%`, `%${q}%`, `%${q}%`); }
  }
  const sql = `SELECT t.*, a.name AS account_name, a.type AS account_type, c.name AS category_name
    FROM transactions t JOIN accounts a ON a.id=t.account_id LEFT JOIN categories c ON c.id=t.category_id
    ${w.length ? 'WHERE ' + w.join(' AND ') : ''} ORDER BY t.date DESC, t.id DESC LIMIT ? OFFSET ?`;
  return db.all(sql, [...p, limit, offset]);
}

export function splitsFor(ids) {
  if (!ids.length) return new Map();
  const rows = db.all(`SELECT * FROM splits WHERE txn_id IN (${ids.map(() => '?').join(',')})`, ids);
  const m = new Map();
  for (const r of rows) { if (!m.has(r.txn_id)) m.set(r.txn_id, []); m.get(r.txn_id).push(r); }
  return m;
}

/** Budget lines: transactions with splits expanded (parents excluded). */
export function lines() {
  return db.all(`SELECT t.id, t.date, t.account_id, t.amount, t.category_id, t.transfer_account_id, t.is_opening, t.payee
      FROM transactions t WHERE t.is_split=0
    UNION ALL
    SELECT t.id, t.date, t.account_id, s.amount, s.category_id, NULL, 0, t.payee
      FROM splits s JOIN transactions t ON t.id=s.txn_id WHERE t.is_split=1`);
}
export const allTxns = () => db.all('SELECT id, date, account_id, amount, payee, category_id, transfer_account_id, is_opening, cleared FROM transactions');

export function accountBalances() {
  const rows = db.all(`SELECT account_id,
      SUM(amount) AS balance,
      SUM(CASE WHEN cleared!='uncleared' THEN amount ELSE 0 END) AS cleared,
      SUM(CASE WHEN date<=? THEN amount ELSE 0 END) AS today_balance,
      SUM(CASE WHEN approved=0 THEN 1 ELSE 0 END) AS unapproved
    FROM transactions GROUP BY account_id`, [today()]);
  return new Map(rows.map((r) => [r.account_id, r]));
}

// ---------- budget ----------
let cache = { v: -1, to: null, data: null };
export function budget(month = thisMonth()) {
  const to = month > thisMonth() ? month : addMonths(thisMonth(), 1);
  if (cache.v === db.version && cache.to >= to) return cache.data;
  const data = computeBudget({
    accounts: db.all('SELECT * FROM accounts'),
    categories: categories(),
    lines: lines(),
    assignments: db.all('SELECT * FROM assignments'),
    toMonth: to,
  });
  cache = { v: db.version, to, data };
  return data;
}

export function setAssigned(month, categoryId, amount) {
  db.run(`INSERT INTO assignments(month, category_id, amount) VALUES(?,?,?)
    ON CONFLICT(month, category_id) DO UPDATE SET amount=excluded.amount`, [month, categoryId, Math.round(amount)]);
}
export function assignedFor(month, categoryId) {
  return db.val('SELECT amount FROM assignments WHERE month=? AND category_id=?', [month, categoryId]) || 0;
}
export function moveMoney(month, fromId, toId, amount) {
  db.tx(() => {
    if (fromId != null) setAssigned(month, fromId, assignedFor(month, fromId) - amount);
    if (toId != null) setAssigned(month, toId, assignedFor(month, toId) + amount);
  });
}
export function applyAssignments(month, map) {
  db.tx(() => { for (const [cid, v] of map) setAssigned(month, cid, v); });
}

// ---------- categories ----------
export function saveCategory(c) {
  const row = { group_id: c.group_id, name: c.name, note: c.note ?? null, emoji: c.emoji ?? null, hidden: c.hidden ? 1 : 0,
    target_type: c.target_type || null, target_amount: c.target_amount ?? null, target_date: c.target_date || null, target_freq: c.target_freq || null };
  if (c.id) { db.update('categories', c.id, row); return c.id; }
  row.sort = (db.val('SELECT MAX(sort) FROM categories WHERE group_id=?', [c.group_id]) ?? -1) + 1;
  return db.insert('categories', row);
}
export function saveGroup(g) {
  if (g.id) { db.update('category_groups', g.id, { name: g.name, hidden: g.hidden ? 1 : 0 }); return g.id; }
  return db.insert('category_groups', { name: g.name, sort: (db.val('SELECT MAX(sort) FROM category_groups') || 0) + 1 });
}
/** Delete category, reassigning its transactions and budgeted money to another category. */
export function deleteCategory(id, toId) {
  db.tx(() => {
    db.run('UPDATE transactions SET category_id=? WHERE category_id=?', [toId, id]);
    db.run('UPDATE splits SET category_id=? WHERE category_id=?', [toId, id]);
    db.run('UPDATE scheduled SET category_id=? WHERE category_id=?', [toId, id]);
    db.run('UPDATE rules SET set_category_id=? WHERE set_category_id=?', [toId, id]);
    if (toId) {
      for (const a of db.all('SELECT * FROM assignments WHERE category_id=?', [id])) setAssigned(a.month, toId, assignedFor(a.month, toId) + a.amount);
    }
    db.run('DELETE FROM assignments WHERE category_id=?', [id]);
    db.run('DELETE FROM categories WHERE id=?', [id]);
  });
}
export function reorder(table, ids) { db.tx(() => ids.forEach((id, i) => db.update(table, id, { sort: i }))); }

// ---------- rules & suggestions ----------
let rulesCache = null;
export const rules = () => (rulesCache ||= db.all('SELECT * FROM rules ORDER BY priority DESC, id'));

export function matchRule(raw, accountId = null) {
  const n = normPayee(raw);
  for (const r of rules()) {
    if (!r.enabled) continue;
    if (r.account_id && r.account_id !== accountId) continue;
    const pat = r.pattern;
    let hit = false;
    if (r.match_type === 'equals') hit = n === normPayee(pat);
    else if (r.match_type === 'starts') hit = n.startsWith(normPayee(pat));
    else if (r.match_type === 'regex') { try { hit = new RegExp(pat, 'i').test(raw || ''); } catch { hit = false; } }
    else hit = !!normPayee(pat) && n.includes(normPayee(pat));
    if (hit) return r;
  }
  return null;
}

// History index for suggestions: built once, reused until transactions/rules change
// (an import of hundreds of rows would otherwise rescan history for every row).
let histIdx = null;
export function invalidateSuggestions() { histIdx = null; rulesCache = null; }
// Any committed write (batched per task) clears the caches; a synchronous import loop keeps them.
db.onChange(() => invalidateSuggestions());
const key2 = (s) => normPayee(s).split(' ').slice(0, 2).join(' ');
function historyIndex() {
  if (histIdx) return histIdx;
  const hist = db.all(`SELECT payee, raw_payee, category_id, amount FROM transactions
    WHERE category_id IS NOT NULL AND transfer_account_id IS NULL AND is_opening=0 AND date >= ? ORDER BY date DESC LIMIT 5000`, [addMonths(thisMonth(), -18) + '-01']);
  const exact = new Map(), loose = new Map(), payeeFor = new Map();
  const add = (m, k, h, w) => {
    if (!k) return;
    if (!m.has(k)) m.set(k, new Map());
    const e = m.get(k), sign = Math.sign(h.amount);
    const cur = e.get(h.category_id) || { pos: 0, neg: 0 };
    if (sign > 0) cur.pos += w; else cur.neg += w;
    e.set(h.category_id, cur);
  };
  for (const h of hist) {
    const keys = new Set([key2(h.raw_payee || h.payee), key2(h.payee)]);
    for (const k of keys) {
      add(exact, k, h, 1);
      if (!payeeFor.has(k)) payeeFor.set(k, h.payee);
      const k1 = k.split(' ')[0];
      if (k1 && k1.length >= 5) add(loose, k1, h, 1);
    }
  }
  histIdx = { exact, loose, payeeFor };
  return histIdx;
}

/** Suggest payee + category for a raw description using rules, then history. */
export function suggest(raw, accountId = null, amount = null) {
  const r = matchRule(raw, accountId);
  let payee = r?.set_payee || null;
  let category_id = r?.set_category_id ?? null;
  let why = r ? 'rule' : null;
  if (r) db.run('UPDATE rules SET hits=hits+1 WHERE id=?', [r.id]);
  const key = key2(payee || raw);
  if (key && (category_id == null || !payee)) {
    const idx = historyIndex();
    const score = (m, k, mult) => {
      const e = m.get(k);
      if (!e) return;
      for (const [cid, c] of e) {
        const same = amount == null ? c.pos + c.neg : amount > 0 ? c.pos : c.neg;
        const other = amount == null ? 0 : amount > 0 ? c.neg : c.pos;
        counts.set(cid, (counts.get(cid) || 0) + mult * (2 * same + other));
      }
    };
    const counts = new Map();
    score(idx.exact, key, 3);
    const k1 = key.split(' ')[0];
    if (k1.length >= 5) score(idx.loose, k1, 1);
    if (category_id == null && counts.size) { category_id = [...counts.entries()].sort((a, b) => b[1] - a[1])[0][0]; why = why || 'history'; }
    if (!payee && idx.payeeFor.has(key)) payee = idx.payeeFor.get(key);
  }
  return { payee: payee || prettyPayee(raw) || raw, category_id, why, rule: r };
}

export function saveRule(r) {
  invalidateSuggestions();
  const row = { match_type: r.match_type || 'contains', pattern: r.pattern, set_payee: r.set_payee || null, set_category_id: r.set_category_id ?? null,
    account_id: r.account_id ?? null, priority: r.priority ?? 0, enabled: r.enabled ?? 1 };
  if (r.id) { db.update('rules', r.id, row); return r.id; }
  return db.insert('rules', row);
}
export function learnFrom(raw, payee, category_id) {
  const key = normPayee(raw).split(' ').slice(0, 2).join(' ');
  if (!key || key.length < 3) return;
  const existing = db.get("SELECT * FROM rules WHERE match_type='contains' AND pattern=?", [key]);
  if (existing) db.update('rules', existing.id, { set_payee: payee || existing.set_payee, set_category_id: category_id ?? existing.set_category_id });
  else saveRule({ pattern: key, set_payee: payee, set_category_id: category_id });
}

// ---------- scheduled ----------
export const scheduledList = () => db.all('SELECT * FROM scheduled WHERE active=1 ORDER BY next_date');
export function saveScheduled(s) {
  const row = { account_id: s.account_id, payee: s.payee, amount: s.amount, category_id: s.category_id ?? null, transfer_account_id: s.transfer_account_id || null,
    memo: s.memo ?? null, freq: s.freq, next_date: s.next_date, end_date: s.end_date || null, auto_enter: s.auto_enter ? 1 : 0, active: s.active ?? 1 };
  if (s.id) { db.update('scheduled', s.id, row); return s.id; }
  return db.insert('scheduled', row);
}
export function enterScheduled(s, date = s.next_date) {
  return db.tx(() => {
    const id = saveTxn({ account_id: s.account_id, date, amount: s.amount, payee: s.payee, category_id: s.category_id, memo: s.memo,
      transfer_account_id: s.transfer_account_id, source: 'scheduled', scheduled_id: s.id, approved: 1 });
    const next = nextOccurrence(date, s.freq);
    db.update('scheduled', s.id, { next_date: next, active: s.end_date && next > s.end_date ? 0 : 1 });
    return id;
  });
}
export function skipScheduled(s) {
  const next = nextOccurrence(s.next_date, s.freq);
  db.update('scheduled', s.id, { next_date: next, active: s.end_date && next > s.end_date ? 0 : 1 });
}
/** Enter all auto-enter items that are due. Returns count. */
export function runScheduled(asOf = today()) {
  let n = 0;
  for (const s of scheduledList()) {
    let guard = 0;
    let cur = s;
    while (cur.auto_enter && cur.active && cur.next_date <= asOf && guard++ < 60) {
      enterScheduled(cur);
      n++;
      cur = db.get('SELECT * FROM scheduled WHERE id=?', [s.id]);
    }
  }
  return n;
}

// ---------- reconcile ----------
export function reconcile(accountId, statementBalance, date = today()) {
  return db.tx(() => {
    const cleared = db.val("SELECT COALESCE(SUM(amount),0) FROM transactions WHERE account_id=? AND cleared!='uncleared'", [accountId]);
    const diff = statementBalance - cleared;
    if (diff !== 0) {
      const a = account(accountId);
      db.insert('transactions', { account_id: accountId, date, amount: diff, payee: 'Reconciliation adjustment', cleared: 'reconciled',
        category_id: a.on_budget && a.type !== 'credit' ? incomeCategoryId() : null, is_opening: a.on_budget && a.type !== 'credit' ? 0 : 1, source: 'manual' });
    }
    db.run("UPDATE transactions SET cleared='reconciled' WHERE account_id=? AND cleared='cleared'", [accountId]);
    setMeta('reconciled_' + accountId, date);
    return diff;
  });
}

// ---------- misc ----------
export function counts() {
  return {
    inbox: db.val('SELECT COUNT(*) FROM transactions WHERE approved=0') + db.val("SELECT COUNT(*) FROM capture_inbox WHERE status='new'"),
    uncategorised: db.val(`SELECT COUNT(*) FROM transactions t JOIN accounts a ON a.id=t.account_id
      WHERE a.on_budget=1 AND t.category_id IS NULL AND t.is_split=0 AND t.is_opening=0 AND t.transfer_account_id IS NULL`),
  };
}
export { meta, setMeta, monthOf };
