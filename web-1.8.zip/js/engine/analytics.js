// Reports & insights. Pure functions over plain rows.
import { addDays, addMonths, daysBetween, monthOf, nextOccurrence, normPayee, prettyPayee, FREQ_PER_YEAR } from '../util.js';

const LIABILITY = new Set(['credit', 'loan', 'mortgage', 'liability']);
export const isLiability = (a) => LIABILITY.has(a.type);
export const isCashLike = (a) => a.on_budget && a.type !== 'credit';

/** Balance per account (optionally up to a date, inclusive). */
export function balances(txns, { upTo } = {}) {
  const out = new Map();
  for (const t of txns) {
    if (upTo && t.date > upTo) continue;
    out.set(t.account_id, (out.get(t.account_id) || 0) + t.amount);
  }
  return out;
}

/** Month-end net worth series for the last n months. */
export function netWorthSeries(txns, accounts, endMonth, n = 12) {
  const acct = new Map(accounts.map((a) => [a.id, a]));
  const startMonth = addMonths(endMonth, -(n - 1));
  const sorted = [...txns].sort((a, b) => (a.date < b.date ? -1 : 1));
  const bal = new Map();
  let i = 0;
  const out = [];
  for (let m = startMonth; m <= endMonth; m = addMonths(m, 1)) {
    while (i < sorted.length && monthOf(sorted[i].date) <= m) {
      const t = sorted[i++];
      bal.set(t.account_id, (bal.get(t.account_id) || 0) + t.amount);
    }
    let assets = 0, debts = 0;
    for (const [id, b] of bal) {
      const a = acct.get(id);
      if (!a) continue;
      if (isLiability(a)) debts += b; else assets += b;
    }
    out.push({ month: m, assets, debts, net: assets + debts });
  }
  return out;
}

/**
 * Budget-relevant lines (splits expanded) -> per-month income and spending.
 * lines: {date, account_id, amount, category_id, transfer_account_id}
 */
export function incomeVsExpense(lines, accounts, incomeIds, endMonth, n = 12) {
  const acct = new Map(accounts.map((a) => [a.id, a]));
  const start = addMonths(endMonth, -(n - 1));
  const rows = new Map();
  for (let m = start; m <= endMonth; m = addMonths(m, 1)) rows.set(m, { month: m, income: 0, spending: 0 });
  for (const l of lines) {
    const m = monthOf(l.date);
    const r = rows.get(m);
    if (!r) continue;
    const a = acct.get(l.account_id);
    if (!a || !a.on_budget) continue;
    if (l.transfer_account_id && acct.get(l.transfer_account_id)?.on_budget) continue;
    if (l.is_opening) continue;
    if (incomeIds.has(l.category_id)) r.income += l.amount;
    else r.spending += -l.amount; // refunds reduce spending
  }
  return [...rows.values()].map((r) => ({ ...r, net: r.income - r.spending }));
}

/** Spending per category for [fromMonth, toMonth]. Returns Map(catId -> cents spent, positive). */
export function spendingByCategory(lines, accounts, incomeIds, fromMonth, toMonth, ccpIds = new Set()) {
  const acct = new Map(accounts.map((a) => [a.id, a]));
  const out = new Map();
  for (const l of lines) {
    const m = monthOf(l.date);
    if (m < fromMonth || m > toMonth) continue;
    const a = acct.get(l.account_id);
    if (!a || !a.on_budget || l.is_opening) continue;
    if (l.transfer_account_id && acct.get(l.transfer_account_id)?.on_budget) continue;
    if (incomeIds.has(l.category_id) || ccpIds.has(l.category_id)) continue;
    const c = l.category_id ?? 0;
    out.set(c, (out.get(c) || 0) - l.amount);
  }
  return out;
}

/**
 * Age of Money: FIFO-match cash outflows to the inflows that funded them; AoM is the mean age of
 * the last 10 outflows. Card purchases count when the card is paid (the payment transfer).
 */
export function ageOfMoney(txns, accounts, { window = 10 } = {}) {
  const acct = new Map(accounts.map((a) => [a.id, a]));
  const flows = [];
  for (const t of txns) {
    const a = acct.get(t.account_id);
    if (!a || !isCashLike(a)) continue;
    const other = t.transfer_account_id ? acct.get(t.transfer_account_id) : null;
    if (other && isCashLike(other)) continue; // moving cash between own cash accounts
    if (other && other.on_budget && other.type === 'credit' && t.amount > 0) continue; // cash advance in
    flows.push(t);
  }
  flows.sort((a, b) => (a.date < b.date ? -1 : a.date > b.date ? 1 : b.amount - a.amount));
  const buckets = []; // {date, left}
  let head = 0;
  const ages = [];
  for (const f of flows) {
    if (f.amount > 0) { buckets.push({ date: f.date, left: f.amount }); continue; }
    let need = -f.amount, weighted = 0, covered = 0;
    while (need > 0 && head < buckets.length) {
      const b = buckets[head];
      const take = Math.min(need, b.left);
      weighted += take * daysBetween(b.date, f.date);
      covered += take; need -= take; b.left -= take;
      if (b.left === 0) head++;
    }
    if (covered > 0) ages.push({ date: f.date, age: weighted / covered });
  }
  if (!ages.length) return { days: null, history: [] };
  const last = ages.slice(-window);
  const days = Math.round(last.reduce((s, x) => s + x.age, 0) / last.length);
  // Daily-ish history: rolling mean at each outflow (thinned to <= 60 points)
  const history = [];
  for (let i = 0; i < ages.length; i++) {
    const w = ages.slice(Math.max(0, i - window + 1), i + 1);
    history.push({ date: ages[i].date, days: w.reduce((s, x) => s + x.age, 0) / w.length });
  }
  const step = Math.max(1, Math.ceil(history.length / 60));
  return { days, history: history.filter((_, i) => i % step === 0 || i === history.length - 1) };
}

const FREQ_BANDS = [
  ['weekly', 7, 2], ['fortnightly', 14, 2], ['monthly', 30.4, 4], ['quarterly', 91, 8], ['half-yearly', 182, 12], ['yearly', 365, 15],
];

function median(xs) { const s = [...xs].sort((a, b) => a - b); const n = s.length; return n ? (n % 2 ? s[(n - 1) / 2] : (s[n / 2 - 1] + s[n / 2]) / 2) : 0; }

/**
 * Detect recurring charges (subscriptions/bills) from outflows.
 * txns: {id, date, amount, payee, category_id, transfer_account_id}
 */
export function detectRecurring(txns, { asOf, minCount = 3 } = {}) {
  const groups = new Map();
  for (const t of txns) {
    if (t.amount >= 0 || t.transfer_account_id || t.is_opening) continue;
    const key = normPayee(t.payee).split(' ').slice(0, 2).join(' ');
    if (!key) continue;
    if (!groups.has(key)) groups.set(key, []);
    groups.get(key).push(t);
  }
  const out = [];
  for (const [key, list] of groups) {
    list.sort((a, b) => (a.date < b.date ? -1 : 1));
    // Split mixed-amount groups (e.g. Woolworths groceries) by amount cluster: keep the biggest cluster.
    const amts = list.map((t) => -t.amount);
    const med = median(amts);
    const cluster = list.filter((t) => Math.abs(-t.amount - med) <= Math.max(100, med * 0.12));
    if (cluster.length < 2) continue;
    const intervals = [];
    for (let i = 1; i < cluster.length; i++) intervals.push(daysBetween(cluster[i - 1].date, cluster[i].date));
    const mi = median(intervals);
    const band = FREQ_BANDS.find(([, d, tol]) => Math.abs(mi - d) <= tol);
    if (!band) continue;
    const [freq, d, tol] = band;
    const need = freq === 'yearly' || freq === 'half-yearly' ? 2 : minCount;
    if (cluster.length < need) continue;
    const regular = intervals.filter((x) => Math.abs(x - d) <= tol * 1.5).length / intervals.length;
    if (regular < 0.7) continue;
    // Groceries-type payees hit many times at random amounts; require the cluster to dominate.
    const share = cluster.length / list.length;
    if (share < 0.5 && list.length > 6) continue;
    const last = cluster[cluster.length - 1];
    const typical = Math.round(median(cluster.map((t) => -t.amount)));
    const lastAmt = -last.amount;
    let next = last.date;
    const stepFreq = freq;
    next = nextOccurrence(last.date, stepFreq);
    const stale = asOf && daysBetween(next, asOf) > tol * 2 + 7; // missed => probably cancelled
    const catCounts = new Map();
    for (const t of cluster) catCounts.set(t.category_id, (catCounts.get(t.category_id) || 0) + 1);
    const category_id = [...catCounts.entries()].sort((a, b) => b[1] - a[1])[0][0];
    out.push({
      key, payee: prettyPayee(last.payee) || last.payee, freq, typical, last: lastAmt, lastDate: last.date, next,
      count: cluster.length, monthly: Math.round((typical * FREQ_PER_YEAR[freq]) / 12), yearly: typical * FREQ_PER_YEAR[freq],
      priceChange: lastAmt - typical, confidence: Math.min(1, regular * (cluster.length / (cluster.length + 1))),
      active: !stale, category_id, txnIds: cluster.map((t) => t.id),
    });
  }
  return out.sort((a, b) => b.monthly - a.monthly);
}

/** Expand scheduled items into occurrences within [from, to]. */
export function expandScheduled(scheduled, from, to) {
  const occ = [];
  for (const s of scheduled) {
    if (!s.active) continue;
    let d = s.next_date, guard = 0;
    while (d <= to && guard++ < 500) {
      if (s.end_date && d > s.end_date) break;
      if (d >= from) occ.push({ ...s, date: d });
      d = nextOccurrence(d, s.freq);
    }
  }
  return occ.sort((a, b) => (a.date < b.date ? -1 : 1));
}

/** Daily cash forecast for on-budget cash accounts from scheduled items. */
export function cashForecast({ startBalance, scheduled, accounts, from, days = 30 }) {
  const acct = new Map(accounts.map((a) => [a.id, a]));
  const to = addDays(from, days);
  const occ = expandScheduled(scheduled, addDays(from, 1), to).filter((o) => {
    const a = acct.get(o.account_id); return a && isCashLike(a);
  });
  let bal = startBalance;
  const series = [{ date: from, balance: bal }];
  let low = { date: from, balance: bal };
  let i = 0;
  for (let d = addDays(from, 1); d <= to; d = addDays(d, 1)) {
    while (i < occ.length && occ[i].date === d) {
      const o = occ[i++];
      // transfers between two cash accounts don't change the pooled cash balance
      const other = o.transfer_account_id ? acct.get(o.transfer_account_id) : null;
      if (!(other && isCashLike(other))) bal += o.amount;
    }
    series.push({ date: d, balance: bal });
    if (bal < low.balance) low = { date: d, balance: bal };
  }
  return { series, low, occurrences: occ };
}
