// Zero-based (envelope) budget engine. Pure function: no DB access.
//
// Rules (YNAB-style):
//  * Inflows categorised to the system "Ready to Assign" (income) category add to RTA in their month.
//  * Each category's Available = carry-in + Assigned + Activity. Positive balances roll over.
//  * Negative balances at month end reset to 0 next month:
//      - cash overspending (from cash accounts) is deducted from next month's RTA;
//      - credit overspending (card spending the category couldn't cover) becomes card debt
//        that the card's payment category doesn't cover (no RTA deduction).
//  * Spending on a credit card moves the *funded* portion from the spending category into that
//    card's payment category ("ccp"), so the cash to pay the card is set aside automatically.
//    Refunds on a card reverse this. Transfers between on-budget accounts are not budget
//    activity, except that the card side of a transfer moves its payment category
//    (paying the card spends from the payment category).
//  * Transfers between an on-budget and a tracking (off-budget) account are categorised like
//    ordinary spending/income on the on-budget side.
//  * Uncategorised lines live in a pseudo category with id 0.
//
// Identity (asserted in tests): for any month with no future assignments,
//   Σ on-budget cash-account balances == RTA + Σ Available + Σ credit-overspending-this-month
import { addMonths, monthDiff, monthOf, nextOccurrence } from '../util.js';

export const UNCATEGORIZED = 0;

export function computeBudget({ accounts, categories, lines, assignments, toMonth }) {
  const acct = new Map(accounts.map((a) => [a.id, a]));
  const cat = new Map(categories.map((c) => [c.id, c]));
  const incomeIds = new Set(categories.filter((c) => c.system === 'income').map((c) => c.id));
  const ccpByAccount = new Map(categories.filter((c) => c.system === 'ccp').map((c) => [c.cc_account_id, c.id]));
  const budgetCatIds = [UNCATEGORIZED, ...categories.filter((c) => c.system !== 'income').map((c) => c.id)];
  const isCard = (a) => a && a.type === 'credit';

  // Group assignments and lines by month.
  const assigned = new Map();
  let totalAssignedAll = 0;
  let first = toMonth;
  for (const a of assignments) {
    if (!a.amount) continue;
    if (!assigned.has(a.month)) assigned.set(a.month, new Map());
    const m = assigned.get(a.month);
    m.set(a.category_id, (m.get(a.category_id) || 0) + a.amount);
    totalAssignedAll += a.amount;
    if (a.month < first) first = a.month;
  }
  const byMonth = new Map();
  for (const l of lines) {
    const m = monthOf(l.date);
    if (m > toMonth) continue; // future months don't affect the months we compute
    if (!byMonth.has(m)) byMonth.set(m, []);
    byMonth.get(m).push(l);
    if (m < first) first = m;
  }
  for (const arr of byMonth.values()) arr.sort((x, y) => (x.date < y.date ? -1 : x.date > y.date ? 1 : x.id - y.id));

  const months = new Map();
  let carry = new Map();
  let incomeThrough = 0;
  let overspendThrough = 0; // cash overspending deducted from RTA (from months before m)

  for (let m = first; m <= toMonth; m = addMonths(m, 1)) {
    const asg = assigned.get(m) || new Map();
    const avail = new Map();
    const activity = new Map();
    const creditOS = new Map();
    const carryIn = new Map();
    for (const c of budgetCatIds) {
      const ci = carry.get(c) || 0;
      carryIn.set(c, ci);
      avail.set(c, ci + (asg.get(c) || 0));
      activity.set(c, 0);
      creditOS.set(c, 0);
    }
    const add = (c, amt) => { activity.set(c, activity.get(c) + amt); avail.set(c, avail.get(c) + amt); };
    let income = 0;

    for (const l of byMonth.get(m) || []) {
      const a = acct.get(l.account_id);
      if (!a || !a.on_budget) continue;
      if (l.transfer_account_id) {
        const other = acct.get(l.transfer_account_id);
        if (other && other.on_budget) {
          if (isCard(a)) { const p = ccpByAccount.get(a.id); if (p != null) add(p, -l.amount); }
          continue;
        }
        // on-budget <-> tracking: treat as categorised flow below
      }
      if (l.is_opening && l.category_id == null) continue; // e.g. opening card debt
      let c = l.category_id ?? UNCATEGORIZED;
      if (incomeIds.has(c)) { income += l.amount; continue; }
      if (c !== UNCATEGORIZED && !cat.has(c)) c = UNCATEGORIZED;
      const p = isCard(a) ? ccpByAccount.get(a.id) : undefined;
      if (p != null && c !== p) {
        if (l.amount < 0) {
          const x = -l.amount;
          const funded = Math.max(0, Math.min(avail.get(c), x));
          add(c, -x);
          add(p, funded);
          creditOS.set(c, creditOS.get(c) + (x - funded));
        } else {
          add(c, l.amount);
          add(p, -l.amount);
        }
      } else {
        add(c, l.amount);
      }
    }

    // Month end: roll positives, split negatives into cash vs credit overspending.
    const next = new Map();
    let cashOS = 0, creditOSTotal = 0;
    const cats = new Map();
    for (const c of budgetCatIds) {
      const av = avail.get(c);
      let cashPart = 0, creditPart = 0;
      if (av < 0) {
        const neg = -av;
        creditPart = Math.min(neg, creditOS.get(c));
        cashPart = neg - creditPart;
        next.set(c, 0);
      } else next.set(c, av);
      cashOS += cashPart;
      creditOSTotal += creditPart;
      const row = {
        id: c, assigned: asg.get(c) || 0, activity: activity.get(c), available: av, carryIn: carryIn.get(c),
        cashOverspent: cashPart, creditOverspent: creditPart,
      };
      const k = cat.get(c);
      if (k && k.target_type) row.target = targetFor(k, m, row);
      cats.set(c, row);
    }

    incomeThrough += income;
    const assignedThisMonth = sum(asg.values());
    const rta = incomeThrough - totalAssignedAll - overspendThrough;
    let availableTotal = 0, activityTotal = 0, underfunded = 0;
    for (const r of cats.values()) {
      availableTotal += r.available;
      activityTotal += r.activity;
      if (r.target) underfunded += r.target.underfunded;
    }
    months.set(m, {
      month: m, rta, income, assigned: assignedThisMonth, activity: activityTotal, available: availableTotal,
      overspentFromLastMonth: months.get(addMonths(m, -1))?.cashOverspent ?? 0,
      cashOverspent: cashOS, creditOverspent: creditOSTotal,
      underfunded, cats,
    });
    overspendThrough += cashOS;
    carry = next;
  }
  return { months, first, totalAssignedAll };
}

function sum(it) { let s = 0; for (const v of it) s += v; return s; }

/**
 * Target maths for one category in month m.
 * Types:
 *   monthly  – set aside X every month
 *   refill   – refill Available up to X every month
 *   by_date  – have X saved by target_date (spread evenly over remaining months)
 *   balance  – save X eventually (no monthly need; progress only)
 *   bill     – X due on target_date repeating every target_freq (refill semantics per due period)
 */
export function targetFor(c, m, row) {
  const X = c.target_amount || 0;
  const { carryIn, assigned, available } = row;
  let needed = 0, label = '';
  switch (c.target_type) {
    case 'monthly':
      needed = X; label = 'per month'; break;
    case 'refill':
      needed = Math.max(0, X - carryIn); label = 'refill to'; break;
    case 'by_date': {
      if (!c.target_date) { needed = 0; break; }
      const dm = monthOf(c.target_date);
      const left = monthDiff(m, dm) + 1;
      const remaining = Math.max(0, X - carryIn);
      needed = left >= 1 ? Math.ceil(remaining / left) : remaining;
      label = 'by ' + c.target_date; break;
    }
    case 'balance':
      needed = 0; label = 'goal'; break;
    case 'bill': {
      if (!c.target_date) { needed = X; break; }
      const freq = c.target_freq || 'monthly';
      if (freq === 'weekly' || freq === 'fortnightly' || freq === 'monthly') {
        const occ = occurrencesInMonth(c.target_date, freq, m);
        needed = Math.max(0, X * occ - carryIn);
        label = `${occ}× due`;
      } else {
        const due = nextDueOnOrAfter(c.target_date, freq, m + '-01');
        const left = Math.max(1, monthDiff(m, monthOf(due)) + 1);
        needed = Math.ceil(Math.max(0, X - carryIn) / left);
        label = 'due ' + due;
      }
      break;
    }
    default: return null;
  }
  const underfunded = Math.max(0, needed - assigned);
  let progress;
  if (c.target_type === 'balance' || c.target_type === 'by_date') progress = X > 0 ? Math.max(0, Math.min(1, available / X)) : 1;
  else progress = needed > 0 ? Math.max(0, Math.min(1, assigned / needed)) : 1;
  const status = underfunded > 0 ? 'underfunded' : 'funded';
  return { type: c.target_type, amount: X, needed, underfunded, progress, status, label };
}

export function occurrencesInMonth(anchor, freq, month) {
  let d = anchor;
  const start = month + '-01';
  let guard = 0;
  while (d < start && guard++ < 2000) d = nextOccurrence(d, freq); // anchor in the future: count from anchor
  let n = 0;
  while (monthOf(d) === month && guard++ < 2000) { n++; d = nextOccurrence(d, freq); }
  return n;
}

export function nextDueOnOrAfter(anchor, freq, date) {
  let d = anchor, guard = 0;
  while (d < date && guard++ < 5000) d = nextOccurrence(d, freq);
  return d;
}

/** Auto-assign strategies for a month. Returns Map(categoryId -> new assigned amount). */
export function autoAssign(strategy, budget, month, categories) {
  const cur = budget.months.get(month);
  const prev = budget.months.get(addMonths(month, -1));
  const out = new Map();
  for (const c of categories) {
    if (c.system === 'income' || c.hidden) continue;
    const row = cur?.cats.get(c.id);
    if (!row) continue;
    let v = null;
    if (strategy === 'underfunded' && row.target) v = row.assigned + row.target.underfunded;
    else if (strategy === 'last_assigned' && prev) v = prev.cats.get(c.id)?.assigned ?? 0;
    else if (strategy === 'last_spent' && prev) v = Math.max(0, -(prev.cats.get(c.id)?.activity ?? 0));
    else if (strategy === 'avg_spent') {
      let s = 0, n = 0;
      for (let i = 1; i <= 3; i++) {
        const mm = budget.months.get(addMonths(month, -i));
        if (mm) { s += Math.max(0, -(mm.cats.get(c.id)?.activity ?? 0)); n++; }
      }
      v = n ? Math.round(s / n) : null;
    } else if (strategy === 'zero_out') v = Math.max(0, row.assigned - row.available);
    else if (strategy === 'reset') v = 0;
    else if (strategy === 'cover_overspent' && row.available < 0) v = row.assigned - row.available;
    if (v != null && v !== row.assigned) out.set(c.id, v);
  }
  return out;
}
