// Boot: pick storage driver, migrate, onboarding or app, housekeeping.
import { useDriver, nativeDriver, migrate, meta, setMeta } from './db.js';
import * as repo from './repo.js';
import { mount, routeTo, screens, queueRender } from './ui/app.js';
import './ui/home.js';
import './ui/budget.js';
import './ui/txns.js';
import './ui/txedit.js';
import './ui/accounts.js';
import './ui/recurring.js';
import './ui/insights.js';
import './ui/importer.js';
import './ui/receipt.js';
import { applyTheme, backupNow } from './ui/settings.js';
import { onboarding } from './ui/onboarding.js';
import { toast } from './ui/dom.js';
import { processCaptures } from './io/notify.js';
import { today, daysBetween } from './util.js';
import * as native from './native.js';

window.addEventListener('error', (e) => toast('Error: ' + (e.message || e.error), { ms: 6000 }));
window.addEventListener('unhandledrejection', (e) => toast('Error: ' + (e.reason?.message || e.reason), { ms: 6000 }));

async function boot() {
  if (native.isNative) useDriver(nativeDriver(window.KobanNative));
  else { const { devDriver } = await import('../dev/dev.js'); useDriver(await devDriver()); }
  migrate();
  if (!native.isNative && new URLSearchParams(location.search).has('demo') && !repo.isSetUp()) {
    const { seedDemo } = await import('../dev/demo.js');
    seedDemo();
  }
  applyTheme();
  const root = document.getElementById('app');
  const checkIntent = () => {
    const r = native.pendingRoute();
    if (r) routeTo(r);
    const sh = native.pendingShare();
    if (sh?.kind === 'file') screens.importer.startText(sh.name, sh.data);
    if (sh?.kind === 'image') screens.receipt.start({ b64: sh.data });
  };
  const startApp = () => {
    mount(root);
    housekeeping();
    checkIntent();
    window.kobanCheckIntent = checkIntent;
    window.kobanOnCapture = () => { const r = processCaptures(); if (r.created) { toast(`${r.created} new from notifications`, { action: 'Review', onAction: () => routeTo('tx') }); queueRender(); } };
  };
  if (!repo.isSetUp() || !repo.accounts().length) onboarding(root, startApp);
  else startApp();
  native.bootOk();
  document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'visible' && repo.isSetUp()) housekeeping(); });
}

let lastHk = 0;
function housekeeping() {
  if (Date.now() - lastHk < 3000) return;
  lastHk = Date.now();
  try { const n = repo.runScheduled(); if (n) toast(`Entered ${n} recurring transaction${n === 1 ? '' : 's'}`); } catch (e) { console.error(e); }
  try { const r = processCaptures(); if (r.created) toast(`${r.created} new from notifications — review in Transactions`); } catch (e) { console.error(e); }
  if (meta('auto_backup', true)) {
    const last = meta('last_backup');
    if (!last || daysBetween(last, today()) >= 7) backupNow('auto');
  }
  checkForUpdates();
}

// Kura-style updates: every launch (and on return after 30 min) ask the update site for a newer UI.
// A new UI is downloaded + verified in the background; right after launch it's swapped in at once,
// otherwise it's used from the next start (or tap Reload). New APKs are offered at most once a day.
const bootAt = Date.now();
let lastCheck = 0;
function checkForUpdates() {
  if (!native.isNative || Date.now() - lastCheck < 30 * 60 * 1000) return;
  lastCheck = Date.now();
  native.checkUpdate().then(async (r) => {
    setMeta('last_update_check', new Date().toISOString());
    if (r.available) {
      const res = await native.applyUpdate();
      if (!res?.ok) return;
      if (Date.now() - bootAt < 8000 && !document.querySelector('.sheet')) native.reload();
      else toast(`Koban ${r.version} is ready`, { action: 'Reload', onAction: native.reload, ms: 10000 });
    }
    if (r.apkAvailable && meta('apk_prompted') !== today()) {
      setMeta('apk_prompted', today());
      toast(`App update ${r.apkVersion}`, { action: 'Install', onAction: () => native.installApk(r.apkUrl), ms: 12000 });
    }
  }).catch(() => {});
}

boot().catch((e) => {
  document.getElementById('app').innerHTML = `<div class="page"><h2>Koban couldn’t start</h2><pre class="log"></pre></div>`;
  document.querySelector('pre').textContent = String(e && e.stack || e);
});
