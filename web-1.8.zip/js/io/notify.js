// Parse bank / wallet push notifications captured by the Android NotificationListener.
// Bank notification wording isn't documented and changes, so this is deliberately generic:
//   1. per-app custom regex (Settings → Notification capture) with named groups
//      (?<amount>…) (?<payee>…) and optional (?<dir>in|out) / (?<last4>\d{4});
//   2. otherwise heuristics: first $ amount that isn't a balance, direction keywords,
//      "at/to/from <merchant>" or the title as merchant, card last-4.
import { db } from '../db.js';
import * as repo from '../repo.js';
import { parseMoney, toISODate, daysBetween } from '../util.js';

const IGNORE = [
  /\b(one[- ]time|verification|security)\s+(code|pin|password)\b/i, /\bnetcode\b/i, /\bOTP\b/, /\bcode is\b/i,
  /\bdeclined\b/i, /\bunsuccessful\b/i, /\bfailed\b/i, /\binsufficient funds\b/i, /\bwas not (approved|processed)\b/i,
  /\blog(ged)?\s?in\b/i, /\bsign(ed)?\s?in\b/i, /\bnew device\b/i,
];
const BALANCE_CTX = /(balance|available|limit|remaining|left to spend)\s*(is|of|:)?\s*$/i;
const IN_WORDS = /\b(received|deposit(ed)?|credited|refund(ed)?|paid you|sent you|incoming|salary|wages|has arrived|money in|transfer(red)? (in|to you)|reversal)\b/i;
const OUT_WORDS = /\b(spent|purchase[d]?|paid|payment|debited|withdrawal|withdrew|charged|you (paid|spent)|tap(ped)?|transaction|bought|direct debit)\b/i;
const AMOUNT_RE = /(?:AUD|A?\$)\s?(-?(?:\d{1,3}(?:,\d{3})+|\d+)(?:\.\d{1,2})?)|(-?(?:\d{1,3}(?:,\d{3})+|\d+)\.\d{2})\s?AUD/gi;
const PAYEE_RE = /\b(?:at|to|from|with|@|merchant:?)\s+([A-Za-z0-9][\w&'’.\-* ]{1,48}?)(?=\s+(?:on|for|using|with|via|was|has|is|card|ending|from|at)\b|[.,!;\n]|\s*\(|\s+-\s|$)/i;

export function parseNotification(n, { pattern = null } = {}) {
  const title = (n.title || '').trim();
  const text = (n.text || '').trim();
  const all = `${title}\n${text}`;
  for (const re of IGNORE) if (re.test(all)) return { ok: false, reason: 'ignored: ' + re.source.slice(0, 30) };

  if (pattern) {
    try {
      const m = new RegExp(pattern, 'is').exec(all);
      if (m && m.groups?.amount) {
        let amount = Math.abs(parseMoney(m.groups.amount));
        const dir = m.groups.dir ? (/^(in|cr|credit|received)/i.test(m.groups.dir) ? 1 : -1) : (IN_WORDS.test(all) ? 1 : -1);
        if (!Number.isNaN(amount) && amount > 0) {
          return { ok: true, amount: amount * dir, payee: (m.groups.payee || '').trim() || null, last4: m.groups.last4 || last4(all), via: 'pattern' };
        }
      }
    } catch (e) { /* bad user regex -> fall back */ }
  }

  // amount: first currency amount not preceded by balance words
  let amount = null;
  AMOUNT_RE.lastIndex = 0;
  let m;
  while ((m = AMOUNT_RE.exec(all))) {
    const before = all.slice(Math.max(0, m.index - 30), m.index);
    if (BALANCE_CTX.test(before)) continue;
    const v = parseMoney(m[1] || m[2]);
    if (!Number.isNaN(v) && v !== 0) { amount = v; break; }
  }
  if (amount == null) return { ok: false, reason: 'no amount' };
  let dir;
  if (amount < 0) dir = -1;
  else if (IN_WORDS.test(all) && !/\byou (paid|spent)\b/i.test(all)) dir = 1;
  else if (OUT_WORDS.test(all)) dir = -1;
  else dir = -1; // most money notifications are spending
  const cents = Math.abs(amount) * dir;

  let payee = null;
  const pm = PAYEE_RE.exec(text) || PAYEE_RE.exec(title);
  if (pm) payee = pm[1].trim();
  if (!payee && title && !/(?:AUD|\$)\s?\d/.test(title) && !/(payment|purchase|transaction|spent|received|bank|wallet|alert|notification|commbank|netbank|westpac|anz|nab)\b/i.test(title)) payee = title;
  if (payee) payee = payee.replace(/\s+(card|visa|mastercard|debit|credit)$/i, '').replace(/[.\s]+$/, '');
  return { ok: true, amount: cents, payee, last4: last4(all), via: 'heuristic' };
}

function last4(s) {
  const m = /(?:card|ending(?: in)?|account|acct|•+|\*{2,}|x{2,}|\.{3,})\s*[x•*]*\s*(\d{4})\b/i.exec(s);
  return m ? m[1] : null;
}

/** Convert new captures into unapproved transactions. Returns {created, ignored}. */
export function processCaptures() {
  const caps = db.all("SELECT * FROM capture_inbox WHERE status='new' ORDER BY posted_at");
  if (!caps.length) return { created: 0, ignored: 0 };
  const sources = new Map(db.all('SELECT * FROM capture_sources').map((s) => [s.pkg, s]));
  const cardMap = new Map(db.all('SELECT * FROM card_map').map((c) => [c.last4, c.account_id]));
  let created = 0, ignored = 0;
  const recent = [];
  db.tx(() => {
    for (const c of caps) {
      const src = sources.get(c.pkg);
      const p = parseNotification(c, { pattern: src?.pattern });
      if (!p.ok) { db.run("UPDATE capture_inbox SET status='ignored', note=? WHERE id=?", [p.reason, c.id]); ignored++; continue; }
      const date = toISODate(new Date(c.posted_at));
      // Same notification posted twice (some apps re-post on update)
      const dup = recent.find((r) => r.amount === p.amount && r.payee === p.payee && Math.abs(r.at - c.posted_at) < 120000);
      if (dup) { db.run("UPDATE capture_inbox SET status='ignored', note='duplicate', txn_id=? WHERE id=?", [dup.txnId, c.id]); ignored++; continue; }
      const accountId = (p.last4 && cardMap.get(p.last4)) || src?.account_id || defaultAccount();
      if (!accountId) { db.run("UPDATE capture_inbox SET note='no account mapped' WHERE id=?", [c.id]); continue; }
      // Already imported from a statement?
      const existing = db.get(`SELECT id, date FROM transactions WHERE account_id=? AND amount=? AND date BETWEEN date(?, '-3 day') AND date(?, '+3 day') AND source IN ('csv','ofx') LIMIT 1`, [accountId, p.amount, date, date]);
      if (existing && Math.abs(daysBetween(existing.date, date)) <= 3) {
        db.run("UPDATE capture_inbox SET status='accepted', note='matched import', txn_id=? WHERE id=?", [existing.id, c.id]); continue;
      }
      const raw = p.payee || c.title || c.pkg;
      const s = repo.suggest(raw, accountId, p.amount);
      const txnId = repo.saveTxn({ account_id: accountId, date, amount: p.amount, payee: s.payee, category_id: s.category_id, approved: 0, source: 'notification', raw_payee: raw, memo: null });
      db.run("UPDATE capture_inbox SET status='parsed', txn_id=?, note=? WHERE id=?", [txnId, p.via, c.id]);
      recent.push({ amount: p.amount, payee: p.payee, at: c.posted_at, txnId });
      created++;
    }
  });
  return { created, ignored };
}

function defaultAccount() {
  return db.val("SELECT id FROM accounts WHERE closed=0 AND on_budget=1 AND type='checking' ORDER BY sort, id LIMIT 1");
}
