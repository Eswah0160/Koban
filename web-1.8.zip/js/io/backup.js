// Full JSON backup/restore + Markdown month summary (for Obsidian).
import { db, meta } from '../db.js';
import * as repo from '../repo.js';
import { money, monthLabel, addMonths } from '../util.js';
import { spendingByCategory } from '../engine/analytics.js';

const TABLES = ['accounts', 'category_groups', 'categories', 'transactions', 'splits', 'assignments', 'scheduled', 'rules', 'receipts', 'card_map', 'capture_sources'];
const META_SKIP = new Set(['gemini_key']); // never put the API key in a backup file

export function exportAll() {
  const tables = {};
  for (const t of TABLES) tables[t] = db.all(`SELECT * FROM ${t}`);
  tables.meta = db.all('SELECT * FROM meta').filter((r) => !META_SKIP.has(r.key));
  return { app: 'koban', format: 1, schema: meta('schema_version'), exported_at: new Date().toISOString(), tables };
}

export function restoreAll(data) {
  if (!data || data.app !== 'koban' || !data.tables) throw new Error('Not a Koban backup file');
  db.tx(() => {
    for (const t of TABLES) {
      db.run(`DELETE FROM ${t}`);
      for (const row of data.tables[t] || []) db.insert(t, row);
    }
    for (const row of data.tables.meta || []) if (row.key !== 'schema_version' && !META_SKIP.has(row.key)) db.run('INSERT OR REPLACE INTO meta(key,value) VALUES(?,?)', [row.key, row.value]);
  });
}

export function monthMarkdown(month) {
  const b = repo.budget(month).months.get(month);
  const idx = repo.categoryIndex();
  const incomeIds = new Set(idx.categories.filter((c) => c.system === 'income').map((c) => c.id));
  const ccp = new Set(idx.categories.filter((c) => c.system === 'ccp').map((c) => c.id));
  const spend = spendingByCategory(repo.lines(), repo.accounts(true), incomeIds, month, month, ccp);
  const prev = spendingByCategory(repo.lines(), repo.accounts(true), incomeIds, addMonths(month, -1), addMonths(month, -1), ccp);
  const total = [...spend.values()].reduce((s, v) => s + v, 0);
  const rows = [...spend.entries()].filter(([, v]) => v !== 0).sort((a, b) => b[1] - a[1]);
  const lines = [
    '---', `type: budget-month`, `month: ${month}`, `income: ${(b.income / 100).toFixed(2)}`, `spent: ${(total / 100).toFixed(2)}`, `tags: [finance, koban]`, '---',
    `# ${monthLabel(month)} — budget summary`, '',
    `- Income: **${money(b.income)}**`, `- Spent: **${money(total)}**`, `- Net: **${money(b.income - total, { sign: true })}**`,
    `- Ready to Assign: ${money(b.rta)}`, b.cashOverspent ? `- Overspent (cash): ${money(b.cashOverspent)}` : null, '',
    '| Category | Spent | vs last month | Available |', '|---|---:|---:|---:|',
    ...rows.map(([cid, v]) => `| ${idx.name(cid)} | ${money(v)} | ${money(v - (prev.get(cid) || 0), { sign: true })} | ${money(b.cats.get(cid)?.available ?? 0)} |`),
    '', `_Exported from Koban ${new Date().toLocaleString('en-AU')}_`,
  ];
  return lines.filter((l) => l !== null).join('\n');
}

export function txnsCSV() {
  const rows = db.all(`SELECT t.date, a.name AS account, t.payee, COALESCE(c.name, CASE WHEN t.is_split THEN 'Split' END) AS category, t.memo, t.amount, t.cleared, t.source
    FROM transactions t JOIN accounts a ON a.id=t.account_id LEFT JOIN categories c ON c.id=t.category_id ORDER BY t.date, t.id`);
  const q = (v) => (v == null ? '' : /[",\n]/.test(String(v)) ? `"${String(v).replace(/"/g, '""')}"` : String(v));
  return ['Date,Account,Payee,Category,Memo,Amount,Cleared,Source', ...rows.map((r) => [r.date, r.account, r.payee, r.category, r.memo, (r.amount / 100).toFixed(2), r.cleared, r.source].map(q).join(','))].join('\n');
}
