// Bank statement parsing: CSV (with AU bank auto-detection + manual mapping) and OFX/QFX.
import { parseMoney, pad } from '../util.js';

export function parseCSV(text) {
  text = text.replace(/^﻿/, '');
  const rows = [];
  let row = [], field = '', q = false;
  for (let i = 0; i < text.length; i++) {
    const ch = text[i];
    if (q) {
      if (ch === '"') { if (text[i + 1] === '"') { field += '"'; i++; } else q = false; }
      else field += ch;
    } else if (ch === '"') q = true;
    else if (ch === ',') { row.push(field); field = ''; }
    else if (ch === '\n' || ch === '\r') {
      if (ch === '\r' && text[i + 1] === '\n') i++;
      row.push(field); field = '';
      if (row.some((f) => f.trim() !== '')) rows.push(row.map((f) => f.trim()));
      row = [];
    } else field += ch;
  }
  row.push(field);
  if (row.some((f) => f.trim() !== '')) rows.push(row.map((f) => f.trim()));
  return rows;
}

const MON = { jan: 1, feb: 2, mar: 3, apr: 4, may: 5, jun: 6, jul: 7, aug: 8, sep: 9, sept: 9, oct: 10, nov: 11, dec: 12 };

/** Parse AU-style dates. Returns 'YYYY-MM-DD' or null. dayFirst=true for dd/mm. */
export function parseDate(s, { dayFirst = true } = {}) {
  if (!s) return null;
  s = String(s).trim();
  let m;
  if ((m = s.match(/^(\d{4})-(\d{1,2})-(\d{1,2})/))) return iso(+m[1], +m[2], +m[3]);
  if ((m = s.match(/^(\d{4})(\d{2})(\d{2})/))) return iso(+m[1], +m[2], +m[3]); // OFX 20261004...
  if ((m = s.match(/^(\d{1,2})[/.-](\d{1,2})[/.-](\d{2,4})$/))) {
    let [a, b, y] = [+m[1], +m[2], +m[3]];
    if (y < 100) y += 2000;
    const [d, mo] = dayFirst ? [a, b] : [b, a];
    return iso(y, mo, d);
  }
  if ((m = s.match(/^(\d{1,2})[\s-]([A-Za-z]{3,4})[a-z]*[\s-](\d{2,4})$/))) {
    let y = +m[3]; if (y < 100) y += 2000;
    const mo = MON[m[2].toLowerCase()];
    return mo ? iso(y, mo, +m[1]) : null;
  }
  if ((m = s.match(/^([A-Za-z]{3})[a-z]*\s+(\d{1,2}),?\s+(\d{4})$/))) {
    const mo = MON[m[1].toLowerCase()];
    return mo ? iso(+m[3], mo, +m[2]) : null;
  }
  return null;
}
function iso(y, m, d) {
  if (!(m >= 1 && m <= 12 && d >= 1 && d <= 31 && y > 1990 && y < 2200)) return null;
  return `${y}-${pad(m)}-${pad(d)}`;
}

const isDate = (s) => !!parseDate(s);
const isMoney = (s) => s !== '' && /\d/.test(s) && !Number.isNaN(parseMoney(s)) && !/^\d{6,}$/.test(s.replace(/[-+]/, ''));

const HEADER_HINTS = {
  date: /^(transaction\s*)?date$|^posted|^effective date|^date of/i,
  amount: /^amount$|^transaction amount|^value$/i,
  debit: /debit|withdrawal|money out|paid out/i,
  credit: /credit|deposit|money in|paid in/i,
  description: /narrative|description|transaction details|details|particulars|memo|reference/i,
  payee: /merchant|payee/i,
  balance: /balance/i,
};

/**
 * Detect the layout of parsed CSV rows.
 * Returns {bank, hasHeader, map:{date, amount?|debit+credit, description, payee?, balance?}, confidence}
 * Known layouts (verify against your own exports — banks change these):
 *   CommBank  : no header — Date, Amount, Description, Balance
 *   ANZ       : no header — Date, Amount, Description
 *   Westpac   : header    — Bank Account, Date, Narrative, Debit Amount, Credit Amount, Balance, Categories, Serial
 *   NAB       : header    — Date, Amount, Account Number, , Transaction Type, Transaction Details, Balance, Category, Merchant Name
 * Anything else falls back to header hints or column-type inference.
 */
export function detectLayout(rows) {
  if (!rows.length) return null;
  const head = rows[0];
  const headerLike = head.every((c) => !isMoney(c) || /[a-z]/i.test(c)) && !head.some(isDate);
  if (headerLike) {
    const map = {};
    head.forEach((h, i) => {
      for (const [k, re] of Object.entries(HEADER_HINTS)) if (map[k] == null && re.test(h)) { map[k] = i; break; }
    });
    // "Transaction Type" is not a description; prefer "Transaction Details"/Narrative
    const lower = head.map((h) => h.toLowerCase());
    if (lower.includes('narrative')) map.description = lower.indexOf('narrative');
    if (lower.includes('transaction details')) map.description = lower.indexOf('transaction details');
    let bank = 'Generic (header)';
    if (lower[0] === 'bank account' && lower.includes('narrative')) bank = 'Westpac';
    else if (lower.includes('merchant name') && lower.includes('transaction details')) bank = 'NAB';
    if (map.amount != null) { delete map.debit; delete map.credit; }
    const ok = map.date != null && (map.amount != null || (map.debit != null && map.credit != null)) && (map.description != null || map.payee != null);
    return { bank, hasHeader: true, map, confidence: ok ? 0.9 : 0.3, columns: head };
  }
  // Headerless: infer by column types over a sample
  const sample = rows.slice(0, 30);
  const width = Math.max(...sample.map((r) => r.length));
  const score = (fn, i) => sample.filter((r) => r[i] != null && fn(r[i])).length / sample.length;
  const types = [];
  for (let i = 0; i < width; i++) {
    const d = score(isDate, i), m = score(isMoney, i);
    const avgLen = sample.reduce((s, r) => s + (r[i] || '').length, 0) / sample.length;
    types.push(d > 0.8 ? 'date' : m > 0.8 ? 'money' : avgLen > 3 ? 'text' : 'other');
  }
  const map = {};
  map.date = types.indexOf('date');
  const moneyCols = types.map((t, i) => (t === 'money' ? i : -1)).filter((i) => i >= 0);
  const textCols = types.map((t, i) => (t === 'text' ? i : -1)).filter((i) => i >= 0);
  if (moneyCols.length) map.amount = moneyCols[0];
  if (moneyCols.length > 1) map.balance = moneyCols[moneyCols.length - 1];
  if (textCols.length) map.description = textCols.sort((a, b) => avgLenOf(sample, b) - avgLenOf(sample, a))[0];
  let bank = 'Generic';
  const signed = sample.every((r) => /^[+-]/.test(r[map.amount] || ''));
  if (width === 4 && types[0] === 'date' && types[1] === 'money' && types[2] === 'text' && types[3] === 'money') bank = signed ? 'CommBank' : 'CommBank-like';
  else if (width === 3 && types[0] === 'date' && types[1] === 'money' && types[2] === 'text') bank = 'ANZ-like';
  const ok = map.date >= 0 && map.amount != null && map.description != null;
  return { bank, hasHeader: false, map, confidence: ok ? 0.8 : 0.2, columns: types.map((t, i) => `Col ${i + 1} (${t})`) };
}
const avgLenOf = (sample, i) => sample.reduce((s, r) => s + (r[i] || '').length, 0) / sample.length;

/** Apply a layout to rows -> normalised [{date, amount, description, payee, balance, valueDate, last4}] */
export function applyLayout(rows, layout, { dayFirst = true, invert = false } = {}) {
  const { map, hasHeader } = layout;
  const out = [];
  const errors = [];
  rows.slice(hasHeader ? 1 : 0).forEach((r, idx) => {
    const date = parseDate(r[map.date], { dayFirst });
    let amount;
    if (map.amount != null) amount = parseMoney(r[map.amount]);
    else {
      const d = map.debit != null ? parseMoney(r[map.debit] || '0') : 0;
      const c = map.credit != null ? parseMoney(r[map.credit] || '0') : 0;
      amount = (Number.isNaN(c) ? 0 : Math.abs(c)) - (Number.isNaN(d) ? 0 : Math.abs(d));
    }
    if (!date || Number.isNaN(amount)) { errors.push({ line: idx + 1, row: r }); return; }
    if (invert) amount = -amount;
    const description = (map.description != null ? r[map.description] : '') || '';
    const payee = map.payee != null && r[map.payee] ? r[map.payee] : null;
    const balance = map.balance != null ? parseMoney(r[map.balance]) : null;
    out.push({ date: valueDate(description) || date, postedDate: date, amount, description, payee, balance: Number.isNaN(balance) ? null : balance, last4: last4Of(description) });
  });
  return { rows: out, errors };
}

/** CommBank-style "Value Date: 29/09/2026" = the real purchase date. */
export function valueDate(desc) {
  const m = /value date:?\s*(\d{1,2}\/\d{1,2}\/\d{2,4})/i.exec(desc || '');
  return m ? parseDate(m[1]) : null;
}
export function last4Of(s) {
  const m = /(?:card|ending(?: in)?|xx|\*{2,}|•{2,})\s*x*(\d{4})\b/i.exec(s || '');
  return m ? m[1] : null;
}
export function cleanDescription(desc) {
  return (desc || '').replace(/value date:?\s*\S+/i, '').replace(/card\s*xx\d{4}/i, '').replace(/\s+/g, ' ').trim();
}

// ---------- OFX / QFX ----------
export function parseOFX(text) {
  const tag = (block, name) => {
    const m = new RegExp(`<${name}>([^<\\r\\n]*)`, 'i').exec(block);
    return m ? m[1].trim() : null;
  };
  const out = [];
  const re = /<STMTTRN>([\s\S]*?)(?:<\/STMTTRN>|(?=<STMTTRN>)|(?=<\/BANKTRANLIST>))/gi;
  let m;
  while ((m = re.exec(text))) {
    const b = m[1];
    const date = parseDate(tag(b, 'DTPOSTED'));
    const amount = parseMoney(tag(b, 'TRNAMT'));
    if (!date || Number.isNaN(amount)) continue;
    const name = tag(b, 'NAME') || '';
    const memo = tag(b, 'MEMO') || '';
    const description = [name, memo].filter(Boolean).join(' ').trim();
    out.push({ date: valueDate(description) || date, postedDate: date, amount, description, payee: null, fitid: tag(b, 'FITID'), last4: last4Of(description), balance: null });
  }
  const acct = tag(text, 'ACCTID');
  const bal = tag(text, 'BALAMT');
  return { rows: out, account: acct, ledgerBalance: bal != null ? parseMoney(bal) : null };
}

export function looksLikeOFX(text) { return /<OFX>|OFXHEADER/i.test(text.slice(0, 2000)); }
