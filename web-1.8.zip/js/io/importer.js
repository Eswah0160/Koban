// Turn normalised statement rows into transactions: dedupe, match to captured/manual entries,
// suggest payee + category.
import { db } from '../db.js';
import * as repo from '../repo.js';
import { cleanDescription } from './csv.js';
import { daysBetween, payeeSimilarity, addDays } from '../util.js';

function fnv(s) { let h = 0x811c9dc5; for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 0x01000193); } return (h >>> 0).toString(36); }

export function importIds(rows, accountId) {
  const seen = new Map();
  return rows.map((r) => {
    if (r.fitid) return `ofx:${accountId}:${r.fitid}`;
    const base = `${r.postedDate || r.date}|${r.amount}|${(r.description || '').toUpperCase().replace(/\s+/g, ' ')}`;
    const n = seen.get(base) || 0; seen.set(base, n + 1);
    return `csv:${accountId}:${fnv(base)}:${n}`;
  });
}

/**
 * Build an import plan without writing anything.
 * Returns {items:[{row, import_id, status:'new'|'match'|'duplicate', match?, suggestion}], range, statementBalance}
 */
export function planImport(rows, accountId) {
  const ids = importIds(rows, accountId);
  if (!rows.length) return { items: [], range: null };
  const dates = rows.map((r) => r.date).sort();
  const from = addDays(dates[0], -7), to = addDays(dates[dates.length - 1], 7);
  const existing = db.all(`SELECT id, date, amount, payee, raw_payee, import_id, source FROM transactions WHERE account_id=? AND date BETWEEN ? AND ?`, [accountId, from, to]);
  const byImportId = new Set(existing.filter((e) => e.import_id).map((e) => e.import_id));
  const allIds = new Set(db.all(`SELECT import_id FROM transactions WHERE account_id=? AND import_id IN (${ids.map(() => '?').join(',')})`, [accountId, ...ids]).map((r) => r.import_id));
  const claimed = new Set();
  const items = rows.map((row, i) => {
    const import_id = ids[i];
    if (byImportId.has(import_id) || allIds.has(import_id)) return { row, import_id, status: 'duplicate' };
    // Match an un-imported entry (from a notification, receipt or manual) with the same amount near the date.
    let best = null, bestScore = -1;
    for (const e of existing) {
      if (e.import_id || claimed.has(e.id) || e.amount !== row.amount) continue;
      const dd = Math.abs(daysBetween(e.date, row.date));
      if (dd > 5) continue;
      const sim = payeeSimilarity(e.raw_payee || e.payee, row.payee || row.description);
      const score = (5 - dd) + sim * 4 + (e.source === 'notification' ? 1 : 0);
      if (score > bestScore) { best = e; bestScore = score; }
    }
    if (best) { claimed.add(best.id); return { row, import_id, status: 'match', match: best }; }
    const raw = row.payee || cleanDescription(row.description);
    return { row, import_id, status: 'new', suggestion: repo.suggest(raw, accountId, row.amount) };
  });
  const withBal = rows.filter((r) => r.balance != null);
  let statementBalance = null;
  if (withBal.length) {
    // newest row's balance (files may be newest-first or oldest-first)
    const newest = [...withBal].sort((a, b) => (a.postedDate || a.date) < (b.postedDate || b.date) ? 1 : -1)[0];
    statementBalance = { balance: newest.balance, date: newest.postedDate || newest.date };
  }
  return { items, range: [dates[0], dates[dates.length - 1]], statementBalance };
}

/** Write the plan. skip: Set of item indexes the user unticked. */
export function commitImport(plan, accountId, { skip = new Set(), source = 'csv', autoApprove = false } = {}) {
  let added = 0, matched = 0;
  db.tx(() => {
    plan.items.forEach((it, i) => {
      if (skip.has(i) || it.status === 'duplicate') return;
      if (it.status === 'match') {
        db.run(`UPDATE transactions SET import_id=?, raw_payee=COALESCE(raw_payee, ?), cleared=CASE WHEN cleared='uncleared' THEN 'cleared' ELSE cleared END WHERE id=?`,
          [it.import_id, it.row.description, it.match.id]);
        matched++;
        return;
      }
      const s = it.suggestion || {};
      repo.saveTxn({
        account_id: accountId, date: it.row.date, amount: it.row.amount, payee: s.payee, category_id: s.category_id ?? null,
        cleared: 'cleared', approved: autoApprove && s.category_id != null ? 1 : 0, source, import_id: it.import_id, raw_payee: it.row.description,
      });
      added++;
    });
  });
  return { added, matched };
}
