// Gemini (free tier) helpers + on-phone fallbacks. The API key lives only in the app's SQLite
// meta table on the phone; requests go straight from the phone to Google.
import { meta } from '../db.js';
import { parseDate } from './csv.js';
import { parseMoney } from '../util.js';

const BASE = 'https://generativelanguage.googleapis.com/v1beta';
export const DEFAULT_MODEL = 'gemini-flash-latest'; // alias that tracks Google's current Flash model

export function aiConfig() {
  return { key: meta('gemini_key', ''), model: meta('gemini_model', DEFAULT_MODEL) || DEFAULT_MODEL, enabled: !!meta('gemini_key', '') };
}

async function call(model, key, body, { timeout = 45000 } = {}) {
  const ctl = new AbortController();
  const t = setTimeout(() => ctl.abort(), timeout);
  try {
    const res = await fetch(`${BASE}/models/${encodeURIComponent(model)}:generateContent`, {
      method: 'POST', headers: { 'Content-Type': 'application/json', 'x-goog-api-key': key }, body: JSON.stringify(body), signal: ctl.signal,
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) {
      const msg = data?.error?.message || res.statusText;
      if (res.status === 429) throw new Error('Gemini free-tier limit reached — try again in a minute. (' + msg + ')');
      throw new Error(`Gemini ${res.status}: ${msg}`);
    }
    const text = data?.candidates?.[0]?.content?.parts?.map((p) => p.text || '').join('') || '';
    if (!text) throw new Error('Gemini returned no content' + (data?.promptFeedback?.blockReason ? ': ' + data.promptFeedback.blockReason : ''));
    return JSON.parse(text);
  } finally { clearTimeout(t); }
}

/** List models usable with generateContent (to pick one in Settings / test the key). */
export async function listModels(key) {
  const res = await fetch(`${BASE}/models?pageSize=200`, { headers: { 'x-goog-api-key': key } });
  const data = await res.json();
  if (!res.ok) throw new Error(data?.error?.message || 'Key rejected');
  return (data.models || []).filter((m) => (m.supportedGenerationMethods || []).includes('generateContent'))
    .map((m) => m.name.replace(/^models\//, '')).filter((n) => /flash|pro|lite/.test(n) && !/tts|image|audio|live|embedding/.test(n));
}

const RECEIPT_SCHEMA = {
  type: 'OBJECT',
  properties: {
    merchant: { type: 'STRING' },
    date: { type: 'STRING', description: 'Purchase date as YYYY-MM-DD, or empty if not printed' },
    total: { type: 'NUMBER', description: 'Grand total paid in dollars' },
    gst: { type: 'NUMBER', nullable: true },
    card_last4: { type: 'STRING', nullable: true },
    category: { type: 'STRING', nullable: true, description: 'Best overall category from the provided list' },
    items: {
      type: 'ARRAY',
      items: {
        type: 'OBJECT',
        properties: {
          description: { type: 'STRING' },
          amount: { type: 'NUMBER', description: 'Line total in dollars after line discounts' },
          category: { type: 'STRING', nullable: true },
        },
        required: ['description', 'amount'],
      },
    },
  },
  required: ['merchant', 'total', 'items'],
};

/** Read a receipt image with Gemini. Returns {merchant, date, total(cents), items:[{description, amount(cents), category}], category, gst, card_last4} */
export async function geminiReceipt({ b64, mime = 'image/jpeg', categoryNames }) {
  const { key, model } = aiConfig();
  if (!key) throw new Error('No Gemini key set (Settings → AI)');
  const prompt = `This is a photo of a receipt from Australia (prices in AUD, GST included).
Extract the merchant name (short, as a person would say it), purchase date, grand total, GST, card last 4 digits if printed, and every purchased line item with its final amount.
Ignore payment lines (EFTPOS, VISA, CHANGE, CASH, ROUNDING) and subtotals. Discounts on a line reduce that line's amount.
For each item and for the receipt overall, choose the single best category from this exact list (or null): ${categoryNames.map((n) => JSON.stringify(n)).join(', ')}.`;
  const r = await call(model, key, {
    contents: [{ parts: [{ inline_data: { mime_type: mime, data: b64 } }, { text: prompt }] }],
    generationConfig: { responseMimeType: 'application/json', responseSchema: RECEIPT_SCHEMA, temperature: 0 },
  });
  return {
    merchant: r.merchant || '', date: parseDate(r.date) || null, total: Math.round((r.total || 0) * 100), gst: r.gst != null ? Math.round(r.gst * 100) : null,
    card_last4: r.card_last4 || null, category: r.category || null,
    items: (r.items || []).map((i) => ({ description: i.description, amount: Math.round((i.amount || 0) * 100), category: i.category || null })), via: 'gemini',
  };
}

/** Ask Gemini to categorise payees. items: [{id, payee, raw, amount}] -> Map(id -> categoryName) */
export async function geminiCategorise(items, categoryNames) {
  const { key, model } = aiConfig();
  if (!key) throw new Error('No Gemini key set');
  const r = await call(model, key, {
    contents: [{ parts: [{ text: `Categorise these Australian bank transactions for a personal budget. Use only these category names: ${JSON.stringify(categoryNames)}. If unsure use null.
Transactions (amount in AUD, negative = spending): ${JSON.stringify(items.map((i) => ({ id: i.id, payee: i.payee, description: i.raw, amount: i.amount / 100 })))}` }] }],
    generationConfig: {
      responseMimeType: 'application/json', temperature: 0,
      responseSchema: { type: 'ARRAY', items: { type: 'OBJECT', properties: { id: { type: 'INTEGER' }, category: { type: 'STRING', nullable: true }, payee: { type: 'STRING', nullable: true } }, required: ['id'] } },
    },
  });
  return new Map((r || []).map((x) => [x.id, { category: x.category, payee: x.payee }]));
}

// ---------- offline fallback: parse OCR text (from on-device ML Kit) ----------
const SKIP = /\b(sub\s?total|gst|tax|change|cash|eftpos|visa|mastercard|amex|debit|credit|rounding|tendered|balance|card|auth|approved|ref|terminal|abn|invoice|tel|phone|www|thank)\b/i;
export function parseReceiptText(text) {
  const lines = (text || '').split(/\n+/).map((l) => l.trim()).filter(Boolean);
  const amountIn = (l) => { const m = l.match(/-?\$?\s?(\d{1,4}(?:,\d{3})*\.\d{2})\s*(?:-|cr)?\s*$/i); return m ? parseMoney(m[1]) * (/(-|cr)\s*$/i.test(l) ? -1 : 1) : null; };
  let merchant = lines.find((l) => /[A-Za-z]{3}/.test(l) && !/tax invoice|receipt|abn|welcome|^\d/i.test(l)) || '';
  merchant = merchant.replace(/\s{2,}.*/, '');
  let date = null;
  for (const l of lines) {
    const m = l.match(/\b(\d{1,2}[/.-]\d{1,2}[/.-]\d{2,4}|\d{4}-\d{2}-\d{2}|\d{1,2}\s+[A-Za-z]{3}\s+\d{2,4})\b/);
    if (m && (date = parseDate(m[1].replace(/\./g, '/')))) break;
  }
  let total = null;
  for (const l of lines) if (/\btotal\b/i.test(l) && !/sub\s?total/i.test(l)) { const a = amountIn(l); if (a != null) total = a; }
  if (total == null) for (const l of lines) if (/amount due|to pay|eftpos|purchase/i.test(l)) { const a = amountIn(l); if (a != null) total = a; }
  const all = lines.map(amountIn).filter((a) => a != null);
  if (total == null && all.length) total = Math.max(...all);
  const items = [];
  for (const l of lines) {
    if (SKIP.test(l) || /\btotal\b/i.test(l)) continue;
    const a = amountIn(l);
    if (a == null) continue;
    const desc = l.replace(/-?\$?\s?\d{1,4}(?:,\d{3})*\.\d{2}\s*(?:-|cr)?\s*$/i, '').replace(/\s+\d+\s*@.*$/, '').trim();
    if (desc.length >= 2) items.push({ description: desc, amount: a, category: null });
  }
  return { merchant, date, total: total ?? 0, items, gst: null, card_last4: null, category: null, via: 'ocr' };
}

/** Downscale an image File/Blob to JPEG base64 (max side px) to keep requests small. */
export async function imageToB64(file, max = 1600, quality = 0.82) {
  const bmp = await createImageBitmap(file);
  const s = Math.min(1, max / Math.max(bmp.width, bmp.height));
  const c = document.createElement('canvas');
  c.width = Math.round(bmp.width * s); c.height = Math.round(bmp.height * s);
  c.getContext('2d').drawImage(bmp, 0, 0, c.width, c.height);
  const url = c.toDataURL('image/jpeg', quality);
  return { b64: url.split(',')[1], mime: 'image/jpeg', dataUrl: url, width: c.width, height: c.height };
}
