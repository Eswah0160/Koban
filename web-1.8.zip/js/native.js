// Wrapper around the Android bridge (window.KobanNative) with browser fallbacks,
// so the same UI runs on the phone and in a desktop browser for development.
const N = typeof window !== 'undefined' ? window.KobanNative : null;
export const isNative = !!N;

const cbs = new Map();
let seq = 0;
if (typeof window !== 'undefined') {
  window.__kobanCb = (id, json) => {
    const f = cbs.get(id); cbs.delete(id);
    if (f) f(typeof json === 'string' ? JSON.parse(json) : json);
  };
}
function callAsync(fn, ...args) {
  return new Promise((resolve, reject) => {
    const id = 'c' + ++seq;
    cbs.set(id, (r) => (r && r.error ? reject(new Error(r.error)) : resolve(r)));
    try { N[fn](id, ...args); } catch (e) { cbs.delete(id); reject(e); }
  });
}
const sync = (fn, ...a) => { const r = JSON.parse(N[fn](...a)); if (r && r.error) throw new Error(r.error); return r; };

export function info() {
  if (!N) return { appVersion: 'web', versionCode: 0, webVersion: window.KOBAN_WEB_VERSION || 'dev', webSource: 'browser', listenerEnabled: false, biometric: false, native: false };
  return { ...sync('info'), native: true };
}

export function openNotificationAccess() { if (N) N.openNotificationAccess(); }
export function openAppSettings() { if (N) N.openAppSettings(); }

/** Save a text file to Downloads/Koban (phone) or trigger a browser download. */
export function saveFile(name, mime, text, { subdir = 'Koban' } = {}) {
  if (N) return sync('saveFile', name, mime, text, subdir);
  const a = document.createElement('a');
  a.href = URL.createObjectURL(new Blob([text], { type: mime }));
  a.download = name; a.click();
  setTimeout(() => URL.revokeObjectURL(a.href), 2000);
  return { ok: true, uri: name };
}

export async function share(text, { subject = '', filename = null, mime = 'text/plain' } = {}) {
  if (N) { sync('share', text, subject, filename || '', mime); return true; }
  if (navigator.share) { try { await navigator.share({ title: subject, text }); return true; } catch { return false; } }
  await navigator.clipboard?.writeText(text);
  return 'copied';
}

/** Store a receipt image privately; returns a URL the WebView can display. */
export function saveReceiptImage(id, b64) {
  if (N) return sync('saveReceipt', String(id), b64).url;
  return 'data:image/jpeg;base64,' + b64;
}
export function receiptUrl(path) {
  if (!path) return null;
  if (path.startsWith('data:')) return path;
  return N ? 'https://appassets.androidplatform.net/files/' + path : null;
}

export const ocrAvailable = () => !!(N && N.ocr);
export function ocr(b64) { return N ? callAsync('ocr', b64) : Promise.reject(new Error('OCR only on the phone')); }

export const checkUpdate = () => (N ? callAsync('checkUpdate') : Promise.resolve({ available: false, reason: 'browser' }));
export const applyUpdate = () => (N ? callAsync('applyUpdate') : Promise.resolve({ ok: false }));
export const installApk = (url) => (N ? callAsync('installApk', url) : Promise.resolve({ ok: false }));
export function reload() { if (N) N.reload(); else location.reload(); }
export function bootOk() { if (N) N.bootOk(); }
export function setSecure(on) { if (N) N.setSecure(!!on); }
export function setLock(on) { if (N) N.setLock(!!on); }
export function haptic(kind = 'tick') { if (N && N.haptic) N.haptic(kind); else navigator.vibrate?.(kind === 'tick' ? 8 : 18); }
export function openUrl(url) { if (N) N.openUrl(url); else window.open(url, '_blank', 'noopener'); }
export function pendingRoute() { return N && N.pendingRoute ? N.pendingRoute() : ''; }
/** A file or image shared to Koban from another app: {kind:'file'|'image', name, data} or null. */
export function pendingShare() {
  if (!N || !N.pendingShare) return null;
  const s = N.pendingShare();
  return s ? JSON.parse(s) : null;
}
export function exitApp() { if (N) N.exitApp(); }
