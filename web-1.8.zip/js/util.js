// Money is always integer cents. Dates are local 'YYYY-MM-DD', months 'YYYY-MM'.

export const CURRENCY = 'AUD';
const fmt = new Intl.NumberFormat('en-AU', { style: 'currency', currency: CURRENCY });
const fmt0 = new Intl.NumberFormat('en-AU', { style: 'currency', currency: CURRENCY, maximumFractionDigits: 0 });

export function money(cents, { sign = false, whole = false } = {}) {
  const v = (cents || 0) / 100;
  const s = (whole ? fmt0 : fmt).format(Math.abs(v));
  if (cents < 0) return '−' + s;
  if (sign && cents > 0) return '+' + s;
  return s;
}

/** Parse user/bank text into cents. Handles "$1,234.50", "-12", "(12.00)", "12.5 CR", "1.234,50" (rare). */
export function parseMoney(input) {
  if (typeof input === 'number') return Math.round(input * 100);
  if (input == null) return NaN;
  let s = String(input).trim();
  if (!s) return NaN;
  let neg = false;
  if (/^\(.*\)$/.test(s)) { neg = true; s = s.slice(1, -1); }
  if (/\bDR\b/i.test(s)) neg = true;
  s = s.replace(/\b(CR|DR|AUD)\b/gi, '').replace(/[\s$A]/g, '');
  if (s.startsWith('-') || s.startsWith('−')) { neg = !neg; s = s.slice(1); }
  if (s.startsWith('+')) s = s.slice(1);
  if (s.endsWith('-')) { neg = !neg; s = s.slice(0, -1); }
  // European style "1.234,50"
  if (/^\d{1,3}(\.\d{3})+,\d{1,2}$/.test(s)) s = s.replace(/\./g, '').replace(',', '.');
  s = s.replace(/,/g, '');
  if (!/^\d*\.?\d+$/.test(s) && !/^\d+\.$/.test(s)) return NaN;
  const cents = Math.round(parseFloat(s) * 100);
  return neg ? -cents : cents;
}

export const pad = (n) => String(n).padStart(2, '0');
export function toISODate(d) { return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`; }
export function today() { return toISODate(new Date()); }
export function monthOf(date) { return date.slice(0, 7); }
export function thisMonth() { return monthOf(today()); }
export function parseISO(s) { const [y, m, d] = String(s || today()).split('-').map(Number); return new Date(y, m - 1, d || 1); }
export function addMonths(month, n) {
  const [y, m] = month.split('-').map(Number);
  const t = y * 12 + (m - 1) + n;
  return `${Math.floor(t / 12)}-${pad((t % 12) + 1)}`;
}
export function monthDiff(a, b) { // b - a in months
  const [ya, ma] = a.split('-').map(Number); const [yb, mb] = b.split('-').map(Number);
  return (yb * 12 + mb) - (ya * 12 + ma);
}
export function addDays(date, n) { const d = parseISO(date); d.setDate(d.getDate() + n); return toISODate(d); }
export function daysBetween(a, b) { return Math.round((parseISO(b) - parseISO(a)) / 86400000); }
export function daysInMonth(month) { const [y, m] = month.split('-').map(Number); return new Date(y, m, 0).getDate(); }
export function monthLabel(month, opts = { month: 'long', year: 'numeric' }) {
  return parseISO(month + '-01').toLocaleDateString('en-AU', opts);
}
export function dateLabel(date) {
  if (!date) return 'no date';
  const t = today();
  if (date === t) return 'Today';
  if (date === addDays(t, -1)) return 'Yesterday';
  const d = parseISO(date);
  const sameYear = date.slice(0, 4) === t.slice(0, 4);
  return d.toLocaleDateString('en-AU', { weekday: 'short', day: 'numeric', month: 'short', ...(sameYear ? {} : { year: 'numeric' }) });
}

/** Advance a date by a schedule frequency. */
export function nextOccurrence(date, freq) {
  switch (freq) {
    case 'weekly': return addDays(date, 7);
    case 'fortnightly': return addDays(date, 14);
    case 'monthly': return addMonthsToDate(date, 1);
    case 'quarterly': return addMonthsToDate(date, 3);
    case 'half-yearly': return addMonthsToDate(date, 6);
    case 'yearly': return addMonthsToDate(date, 12);
    default: return addMonthsToDate(date, 1);
  }
}
export function addMonthsToDate(date, n) {
  const day = Number(date.slice(8, 10));
  const m = addMonths(monthOf(date), n);
  return `${m}-${pad(Math.min(day, daysInMonth(m)))}`;
}
export const FREQS = ['weekly', 'fortnightly', 'monthly', 'quarterly', 'half-yearly', 'yearly'];
export const FREQ_PER_YEAR = { weekly: 52, fortnightly: 26, monthly: 12, quarterly: 4, 'half-yearly': 2, yearly: 1 };

/** Normalise a merchant/payee string for matching (strip card noise, locations, refs). */
export function normPayee(s) {
  if (!s) return '';
  return String(s).toUpperCase()
    .replace(/\.(COM|NET|ORG|IO|CO)(\.AU)?\b/g, ' ')
    .replace(/\b(SYDNEY|MELBOURNE|BRISBANE|PERTH|ADELAIDE|HOBART|CANBERRA|DARWIN|PARRAMATTA|NORTH SYDNEY|NS|VI|QL)\b/g, ' ')
    .replace(/\b(VISA|DEBIT|CREDIT|PURCHASE|EFTPOS|CARD|POS|AUTHORI[SZ]ATION|PENDING|TAP AND PAY|CONTACTLESS|DIRECT|TRANSFER|PAYMENT|PMT|VALUE DATE)\b/g, ' ')
    .replace(/\bxx\d+|\*+\d+|\b\d{4,}\b/gi, ' ')
    .replace(/\b(AUS|AU|NSW|VIC|QLD|SA|WA|TAS|ACT|NT)\b/g, ' ')
    .replace(/\d{2}\/\d{2}(\/\d{2,4})?/g, ' ')
    .replace(/[^A-Z0-9& ]/g, ' ')
    .replace(/\s+/g, ' ').trim();
}

/** Pretty payee from raw bank narration: "WOOLWORTHS 1234 SYDNEY NS AUS Card xx1234" -> "Woolworths". */
export function prettyPayee(raw) {
  const n = normPayee(raw);
  if (!n) return (raw || '').trim();
  const words = n.split(' ').filter((w) => !/^\d+$/.test(w)).slice(0, 3);
  return words.map((w) => (w.length <= 3 && /^[A-Z&]+$/.test(w) && !/^(THE|AND|CO)$/.test(w) ? w : w[0] + w.slice(1).toLowerCase())).join(' ');
}

/** Similarity 0..1 between two payees (token Jaccard on normalised forms). */
export function payeeSimilarity(a, b) {
  const A = new Set(normPayee(a).split(' ').filter(Boolean));
  const B = new Set(normPayee(b).split(' ').filter(Boolean));
  if (!A.size || !B.size) return 0;
  let inter = 0; for (const t of A) if (B.has(t)) inter++;
  return inter / (A.size + B.size - inter);
}

export function uid() { return Math.random().toString(36).slice(2, 10); }
export function esc(s) {
  return String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}
export function debounce(fn, ms = 200) { let t; return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); }; }
export function groupBy(arr, key) {
  const m = new Map();
  for (const x of arr) { const k = typeof key === 'function' ? key(x) : x[key]; if (!m.has(k)) m.set(k, []); m.get(k).push(x); }
  return m;
}
export function sum(arr, f = (x) => x) { let s = 0; for (const x of arr) s += f(x); return s; }
