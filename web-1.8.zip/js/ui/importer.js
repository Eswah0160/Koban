// Statement import flow: file -> account -> layout (CSV) -> review -> commit.
import * as repo from '../repo.js';
import { db } from '../db.js';
import { html, raw, openSheet, toast, confirmDlg } from './dom.js';
import { registerScreen, go } from './app.js';
import { pickAccount } from './pickers.js';
import { parseCSV, detectLayout, applyLayout, parseOFX, looksLikeOFX, cleanDescription } from '../io/csv.js';
import { planImport, commitImport } from '../io/importer.js';
import { money, dateLabel } from '../util.js';

export function pickFile(accept) {
  return new Promise((resolve) => {
    const inp = document.createElement('input');
    inp.type = 'file'; inp.accept = accept;
    inp.onchange = () => resolve(inp.files[0] || null);
    inp.click();
  });
}

async function start(accountId = null) {
  const f = await pickFile('.csv,.ofx,.qfx,.qif,.txt,text/csv,text/plain,application/vnd.ms-excel,application/x-ofx,*/*');
  if (!f) return;
  return startText(f.name, await f.text(), accountId);
}

/** Entry point for text already in hand (e.g. a CSV shared to Koban from the bank app). */
async function startText(name, text, accountId = null) {
  const f = { name };
  if (/^\s*\{/.test(text) && text.includes('"app":"koban"')) return toast('That’s a Koban backup — restore it from Settings');
  let rows, ofxInfo = null, kind;
  if (looksLikeOFX(text)) { const r = parseOFX(text); rows = r.rows; ofxInfo = r; kind = 'ofx'; }
  else { kind = 'csv'; }
  if (!accountId) {
    // Guess by card last-4 in descriptions
    let guess = null;
    const sample = kind === 'ofx' ? rows : null;
    const cmap = new Map(db.all('SELECT * FROM card_map').map((c) => [c.last4, c.account_id]));
    const m = /(?:card\s*xx|xx)(\d{4})/i.exec(text);
    if (m && cmap.has(m[1])) guess = cmap.get(m[1]);
    accountId = guess || await pickAccount({ title: `Import ${f.name} into` });
    if (!accountId) return;
  }
  if (kind === 'csv') return layoutStep(f.name, text, accountId);
  return reviewStep(f.name, rows, accountId, ofxInfo?.ledgerBalance != null ? { balance: ofxInfo.ledgerBalance } : null, 'ofx');
}

function layoutStep(name, text, accountId) {
  const raw0 = parseCSV(text);
  if (!raw0.length) return toast('That file is empty');
  let layout = detectLayout(raw0);
  let opts = { dayFirst: true, invert: false };
  const roles = [['date', 'Date'], ['amount', 'Amount (signed)'], ['debit', 'Debit / money out'], ['credit', 'Credit / money in'], ['description', 'Description'], ['payee', 'Merchant / payee'], ['balance', 'Balance']];
  const width = Math.max(...raw0.slice(0, 20).map((r) => r.length));
  const colName = (i) => (layout.hasHeader ? raw0[0][i] || `Column ${i + 1}` : `Column ${i + 1}: ${(raw0[0][i] || '').slice(0, 24)}`);
  const body = () => {
    const { rows, errors } = applyLayout(raw0, layout, opts);
    return html`
      <p class="small">Detected <b>${layout.bank}</b> layout${layout.confidence < 0.5 ? html` — <b class="neg">please check the columns</b>` : ''}. ${rows.length} rows${errors.length ? html`, <span class="neg">${errors.length} unreadable</span>` : ''}.</p>
      <div class="row small" style="margin-bottom:8px"><label class="row"><input type="checkbox" id="hh" ${layout.hasHeader ? raw('checked') : ''}> First row is a header</label></div>
      ${roles.map(([k, l]) => html`<label class="pickrow"><span class="k" style="width:130px">${l}</span><select data-role="${k}"><option value="">—</option>${Array.from({ length: width }, (_, i) => html`<option value="${i}" ${layout.map[k] === i ? raw('selected') : ''}>${colName(i)}</option>`)}</select></label>`)}
      <div class="row wrap small" style="margin:10px 0"><label class="row"><input type="checkbox" id="df" ${opts.dayFirst ? raw('checked') : ''}> Dates are day/month</label>
        <label class="row"><input type="checkbox" id="inv" ${opts.invert ? raw('checked') : ''}> Flip signs (if spending shows as positive)</label></div>
      <div class="lbl">Preview</div>
      <table class="tbl">${rows.slice(0, 6).map((r) => html`<tr><td class="small">${r.date}</td><td class="small ellipsis" style="max-width:180px">${r.payee || cleanDescription(r.description)}</td><td class="n ${r.amount > 0 ? 'pos' : ''}">${money(r.amount)}</td></tr>`)}</table>`;
  };
  const s = openSheet({
    title: `Import ${name}`, body: body(),
    footer: html`<button class="btn primary block" data-act="next">Review transactions</button>`,
    actions: { next: (b, e, api) => { const { rows } = applyLayout(raw0, layout, opts); if (!rows.length) return toast('No readable rows — check the columns'); api.close(); reviewStep(name, rows, accountId, null, 'csv'); } },
  });
  s.el.addEventListener('change', (e) => {
    const r = e.target.dataset.role;
    if (r) { layout = { ...layout, map: { ...layout.map, [r]: e.target.value === '' ? undefined : +e.target.value } }; if (r === 'amount' && e.target.value !== '') { delete layout.map.debit; delete layout.map.credit; } }
    if (e.target.id === 'hh') layout = { ...layout, hasHeader: e.target.checked };
    if (e.target.id === 'df') opts.dayFirst = e.target.checked;
    if (e.target.id === 'inv') opts.invert = e.target.checked;
    s.setBody(body());
  });
}

function reviewStep(name, rows, accountId, stmtBal, source) {
  const plan = planImport(rows, accountId);
  const idx = repo.categoryIndex();
  const skip = new Set();
  let autoApprove = false;
  const n = (st) => plan.items.filter((i) => i.status === st).length;
  const body = () => html`
    <p class="small">${repo.account(accountId)?.name} · ${plan.range ? `${dateLabel(plan.range[0])} – ${dateLabel(plan.range[1])}` : ''}</p>
    <div class="chips"><span class="chip acc">${n('new')} new</span><span class="chip">${n('match')} matched</span><span class="chip">${n('duplicate')} already imported</span></div>
    <label class="row small" style="margin-bottom:8px"><input type="checkbox" id="aa" ${autoApprove ? raw('checked') : ''}> Auto-approve rows that got a category (others go to Review)</label>
    <div class="card">${plan.items.map((it, i) => html`<div class="tx" style="${it.status === 'duplicate' ? 'opacity:.45' : ''}">
      ${it.status === 'duplicate' ? html`<div class="ic">=</div>` : html`<input type="checkbox" data-i="${i}" ${skip.has(i) ? '' : raw('checked')} style="width:20px;height:20px">`}
      <div class="main"><div class="p">${it.status === 'match' ? it.match.payee : it.suggestion?.payee || cleanDescription(it.row.description)}</div>
        <div class="c">${dateLabel(it.row.date)} · ${it.status === 'match' ? html`<b>matches your entry</b> — will mark cleared` : it.status === 'duplicate' ? 'already imported' : it.suggestion?.category_id != null ? html`${idx.name(it.suggestion.category_id)} <span class="muted">(${it.suggestion.why})</span>` : html`<span class="uncat">needs category</span>`}</div></div>
      <div class="r"><div class="amt ${it.row.amount > 0 ? 'in' : ''}">${money(it.row.amount)}</div></div></div>`)}</div>`;
  const s = openSheet({
    title: 'Review import', body: body(),
    footer: html`<button class="btn primary block" data-act="go">Import ${n('new')} · match ${n('match')}</button>`,
    actions: {
      go: async (b, e, api) => {
        const r = commitImport(plan, accountId, { skip, source, autoApprove });
        api.close();
        toast(`Imported ${r.added}, matched ${r.matched}`);
        const sb = stmtBal || plan.statementBalance;
        if (sb && sb.balance != null) {
          const app = db.val('SELECT COALESCE(SUM(amount),0) FROM transactions WHERE account_id=? AND date<=?', [accountId, sb.date || '9999-12-31']);
          if (app !== sb.balance && await confirmDlg(`The statement says ${money(sb.balance)}${sb.date ? ' on ' + dateLabel(sb.date) : ''}, Koban has ${money(app)}. Open the account to reconcile?`, { ok: 'Open account', title: 'Balance check' })) go('account', accountId);
        }
      },
    },
  });
  s.el.addEventListener('change', (e) => {
    if (e.target.id === 'aa') { autoApprove = e.target.checked; return; }
    const i = e.target.dataset.i; if (i == null) return;
    e.target.checked ? skip.delete(+i) : skip.add(+i);
  });
}

registerScreen('importer', { start, startText, render() {} });
