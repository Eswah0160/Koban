// Minimal SVG charts following the dataviz spec: thin marks, 4px rounded data-ends, hairline
// grid, one axis, crosshair/per-mark tooltips, legend for >= 2 series.
import { html } from './dom.js';
import { money } from '../util.js';

function niceTicks(min, max, n = 4) {
  if (min === max) { max = min + 1; }
  const span = max - min;
  const step0 = span / n;
  const mag = 10 ** Math.floor(Math.log10(step0));
  const step = [1, 2, 2.5, 5, 10].map((k) => k * mag).find((s) => s >= step0) || mag * 10;
  const lo = Math.floor(min / step) * step, hi = Math.ceil(max / step) * step;
  const ticks = [];
  for (let v = lo; v <= hi + step / 2; v += step) ticks.push(Math.round(v));
  return ticks;
}
const short = (c) => {
  const v = c / 100, a = Math.abs(v);
  const s = a >= 1e6 ? (a / 1e6).toFixed(1) + 'M' : a >= 1e4 ? Math.round(a / 1e3) + 'k' : a >= 1e3 ? (a / 1e3).toFixed(1) + 'k' : Math.round(a).toString();
  return (v < 0 ? '−$' : '$') + s;
};

function tooltip(el) {
  let tip = el.querySelector('.tip');
  if (!tip) { tip = document.createElement('div'); tip.className = 'tip'; tip.hidden = true; el.append(tip); }
  return tip;
}

/** Grouped columns. data: [{label, key, values:{seriesKey: cents}}]; series: [{key, label, color}] */
export function columns(el, { data, series, height = 200, onPick = null }) {
  const W = Math.max(280, el.clientWidth || 320), H = height, padL = 44, padB = 22, padT = 8;
  const all = data.flatMap((d) => series.map((s) => d.values[s.key] || 0));
  const ticks = niceTicks(Math.min(0, ...all), Math.max(0, ...all));
  const y0 = ticks[0], y1 = ticks[ticks.length - 1];
  const Y = (v) => padT + (H - padT - padB) * (1 - (v - y0) / (y1 - y0 || 1));
  const band = (W - padL) / data.length;
  const bw = Math.min(24, (band * 0.7 - 2 * (series.length - 1)) / series.length);
  const groupW = bw * series.length + 2 * (series.length - 1);
  let marks = '';
  data.forEach((d, i) => {
    const gx = padL + i * band + (band - groupW) / 2;
    series.forEach((s, j) => {
      const v = d.values[s.key] || 0;
      const x = gx + j * (bw + 2);
      const ya = Y(Math.max(0, v)), yb = Y(Math.min(0, v));
      const h = Math.max(1, yb - ya);
      const r = Math.min(4, bw / 2, h);
      // rounded data-end, square at baseline
      const path = v >= 0
        ? `M${x},${yb} V${ya + r} Q${x},${ya} ${x + r},${ya} H${x + bw - r} Q${x + bw},${ya} ${x + bw},${ya + r} V${yb} Z`
        : `M${x},${ya} V${yb - r} Q${x},${yb} ${x + r},${yb} H${x + bw - r} Q${x + bw},${yb} ${x + bw},${yb - r} V${ya} Z`;
      marks += `<path d="${path}" fill="${s.color}"/>`;
    });
    marks += `<rect x="${padL + i * band}" y="${padT}" width="${band}" height="${H - padT - padB}" fill="transparent" data-i="${i}" class="hit"/>`;
    if (data.length <= 12 || i % Math.ceil(data.length / 12) === 0) marks += `<text x="${padL + i * band + band / 2}" y="${H - 6}" text-anchor="middle">${d.label}</text>`;
  });
  const grid = ticks.map((t) => `<line class="${t === 0 ? 'base' : 'grid'}" x1="${padL}" x2="${W}" y1="${Y(t)}" y2="${Y(t)}"/><text x="${padL - 6}" y="${Y(t) + 4}" text-anchor="end">${short(t)}</text>`).join('');
  el.innerHTML = `${series.length > 1 ? String(html`<div class="legend">${series.map((s) => html`<span><i style="background:${s.color}"></i>${s.label}</span>`)}</div>`) : ''}<svg viewBox="0 0 ${W} ${H}" height="${H}" role="img">${grid}${marks}</svg>`;
  const tip = tooltip(el);
  const svg = el.querySelector('svg');
  const show = (i, evt) => {
    const d = data[i];
    tip.innerHTML = String(html`<div class="small muted">${d.full || d.label}</div>${series.map((s) => html`<div class="tr"><span class="key" style="background:${s.color}"></span><span class="tv">${money(d.values[s.key] || 0)}</span><span>${s.label}</span></div>`)}${d.extra ? html`<div class="small" style="margin-top:2px">${d.extra}</div>` : ''}`);
    const box = el.getBoundingClientRect();
    const sx = box.width / W;
    tip.style.left = Math.min(box.width - 70, Math.max(70, (padL + i * band + band / 2) * sx)) + 'px';
    tip.style.top = (svg.offsetTop + padT * sx) + 'px';
    tip.hidden = false;
  };
  svg.addEventListener('pointermove', (e) => { const r = e.target.closest?.('.hit'); if (r) show(+r.dataset.i, e); });
  svg.addEventListener('pointerdown', (e) => { const r = e.target.closest?.('.hit'); if (r) { show(+r.dataset.i, e); onPick && onPick(data[+r.dataset.i]); } });
  svg.addEventListener('pointerleave', () => { tip.hidden = true; });
}

/** Single-series line with area wash + crosshair. points: [{label, full, y}] */
export function line(el, { points, color = 'var(--series-1)', height = 180, zero = true, markLow = false, fmt = money, tick = short }) {
  if (!points.length) { el.innerHTML = '<p class="small muted">Not enough data yet.</p>'; return; }
  const W = Math.max(280, el.clientWidth || 320), H = height, padL = 46, padB = 22, padT = 14, padR = 8;
  const ys = points.map((p) => p.y);
  const ticks = niceTicks(Math.min(zero ? 0 : Infinity, ...ys), Math.max(zero ? 0 : -Infinity, ...ys));
  const y0 = ticks[0], y1 = ticks[ticks.length - 1];
  const X = (i) => padL + (W - padL - padR) * (points.length === 1 ? 0.5 : i / (points.length - 1));
  const Y = (v) => padT + (H - padT - padB) * (1 - (v - y0) / (y1 - y0 || 1));
  const d = points.map((p, i) => `${i ? 'L' : 'M'}${X(i).toFixed(1)},${Y(p.y).toFixed(1)}`).join(' ');
  const base = Y(Math.max(y0, Math.min(0, y1)));
  const area = `${d} L${X(points.length - 1)},${base} L${X(0)},${base} Z`;
  const grid = ticks.map((t) => `<line class="${t === 0 ? 'base' : 'grid'}" x1="${padL}" x2="${W - padR}" y1="${Y(t)}" y2="${Y(t)}"/><text x="${padL - 6}" y="${Y(t) + 4}" text-anchor="end">${tick(t)}</text>`).join('');
  const every = Math.ceil(points.length / 6);
  const xl = points.map((p, i) => (i % every === 0 || i === points.length - 1 ? `<text x="${X(i)}" y="${H - 6}" text-anchor="${i === 0 ? 'start' : i === points.length - 1 ? 'end' : 'middle'}">${p.label}</text>` : '')).join('');
  const last = points.length - 1;
  let low = '';
  if (markLow) { let li = 0; ys.forEach((v, i) => { if (v < ys[li]) li = i; }); low = `<circle cx="${X(li)}" cy="${Y(ys[li])}" r="4.5" fill="${ys[li] < 0 ? 'var(--bad)' : color}" stroke="var(--surface)" stroke-width="2"/>`; }
  el.innerHTML = `<svg viewBox="0 0 ${W} ${H}" height="${H}" role="img">${grid}
    <path d="${area}" fill="${color}" opacity=".1"/><path d="${d}" fill="none" stroke="${color}" stroke-width="2" stroke-linejoin="round" stroke-linecap="round"/>
    ${low}<circle cx="${X(last)}" cy="${Y(ys[last])}" r="4" fill="${color}" stroke="var(--surface)" stroke-width="2"/>
    <line class="xh" x1="0" x2="0" y1="${padT}" y2="${H - padB}" stroke="var(--line-strong)" stroke-width="1" visibility="hidden"/>
    <circle class="xd" r="4" fill="${color}" stroke="var(--surface)" stroke-width="2" visibility="hidden"/>${xl}
    <rect x="${padL}" y="0" width="${W - padL}" height="${H}" fill="transparent" class="hitarea"/></svg>`;
  const svg = el.querySelector('svg');
  const tip = tooltip(el);
  const xh = svg.querySelector('.xh'), xd = svg.querySelector('.xd');
  const move = (e) => {
    const box = svg.getBoundingClientRect();
    const sx = W / box.width;
    const px = (e.clientX - box.left) * sx;
    const i = Math.max(0, Math.min(points.length - 1, Math.round(((px - padL) / (W - padL - padR)) * (points.length - 1))));
    xh.setAttribute('x1', X(i)); xh.setAttribute('x2', X(i)); xh.setAttribute('visibility', 'visible');
    xd.setAttribute('cx', X(i)); xd.setAttribute('cy', Y(points[i].y)); xd.setAttribute('visibility', 'visible');
    tip.innerHTML = String(html`<div class="tv">${fmt(points[i].y)}</div><div class="small muted">${points[i].full || points[i].label}</div>`);
    tip.style.left = Math.min(box.width - 60, Math.max(60, X(i) / sx)) + 'px';
    tip.style.top = (Y(points[i].y) / sx) + 'px';
    tip.hidden = false;
  };
  svg.addEventListener('pointermove', move);
  svg.addEventListener('pointerdown', move);
  svg.addEventListener('pointerleave', () => { tip.hidden = true; xh.setAttribute('visibility', 'hidden'); xd.setAttribute('visibility', 'hidden'); });
}

/** Multi-series line chart with one shared axis + crosshair listing every series.
 * labels: x labels; series: [{label, color, values:[cents|null], dashed}] */
export function lines(el, { labels, full = labels, series, height = 190, fmt = money }) {
  const W = Math.max(280, el.clientWidth || 320), H = height, padL = 46, padB = 22, padT = 10, padR = 8;
  const all = series.flatMap((s) => s.values.filter((v) => v != null));
  if (!all.length) { el.innerHTML = '<p class="small muted">Not enough data yet.</p>'; return; }
  const ticks = niceTicks(Math.min(0, ...all), Math.max(0, ...all));
  const y0 = ticks[0], y1 = ticks[ticks.length - 1];
  const n = labels.length;
  const X = (i) => padL + (W - padL - padR) * (n === 1 ? 0.5 : i / (n - 1));
  const Y = (v) => padT + (H - padT - padB) * (1 - (v - y0) / (y1 - y0 || 1));
  const grid = ticks.map((t) => `<line class="${t === 0 ? 'base' : 'grid'}" x1="${padL}" x2="${W - padR}" y1="${Y(t)}" y2="${Y(t)}"/><text x="${padL - 6}" y="${Y(t) + 4}" text-anchor="end">${short(t)}</text>`).join('');
  const every = Math.ceil(n / 6);
  const xl = labels.map((l, i) => (i % every === 0 || i === n - 1 ? `<text x="${X(i)}" y="${H - 6}" text-anchor="${i === 0 ? 'start' : i === n - 1 ? 'end' : 'middle'}">${l}</text>` : '')).join('');
  const paths = series.map((s) => {
    let d = '', pen = false, last = -1;
    s.values.forEach((v, i) => { if (v == null) { pen = false; return; } d += `${pen ? 'L' : 'M'}${X(i).toFixed(1)},${Y(v).toFixed(1)}`; pen = true; last = i; });
    const end = last >= 0 ? `<circle cx="${X(last)}" cy="${Y(s.values[last])}" r="3.5" fill="${s.color}" stroke="var(--surface)" stroke-width="2"/>` : '';
    return `<path d="${d}" fill="none" stroke="${s.color}" stroke-width="${s.dashed ? 1.6 : 2}" ${s.dashed ? 'stroke-dasharray="4 4"' : ''} stroke-linejoin="round" stroke-linecap="round"/>${end}`;
  }).join('');
  el.innerHTML = `${series.length > 1 ? String(html`<div class="legend">${series.map((s) => html`<span><i style="background:${s.color};height:2px;border-radius:1px"></i>${s.label}</span>`)}</div>`) : ''}
    <svg viewBox="0 0 ${W} ${H}" height="${H}" role="img">${grid}${paths}${xl}
    <line class="xh" x1="0" x2="0" y1="${padT}" y2="${H - padB}" stroke="var(--line-strong)" stroke-width="1" visibility="hidden"/>
    <rect x="${padL}" y="0" width="${W - padL}" height="${H}" fill="transparent"/></svg>`;
  const svg = el.querySelector('svg'), xh = svg.querySelector('.xh');
  const tip = tooltip(el);
  const move = (e) => {
    const box = svg.getBoundingClientRect(), sx = W / box.width;
    const i = Math.max(0, Math.min(n - 1, Math.round((((e.clientX - box.left) * sx - padL) / (W - padL - padR)) * (n - 1))));
    xh.setAttribute('x1', X(i)); xh.setAttribute('x2', X(i)); xh.setAttribute('visibility', 'visible');
    tip.innerHTML = String(html`<div class="small muted">${full[i]}</div>${series.map((s) => html`<div class="tr"><span class="key" style="background:${s.color}"></span><span class="tv">${s.values[i] == null ? '—' : fmt(s.values[i])}</span><span>${s.label}</span></div>`)}`);
    tip.style.left = Math.min(box.width - 80, Math.max(80, X(i) / sx)) + 'px';
    tip.style.top = '0px'; tip.style.transform = 'translate(-50%, 0)';
    tip.hidden = false;
  };
  svg.addEventListener('pointermove', move); svg.addEventListener('pointerdown', move);
  svg.addEventListener('pointerleave', () => { tip.hidden = true; xh.setAttribute('visibility', 'hidden'); });
}
