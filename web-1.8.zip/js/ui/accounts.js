// Accounts, account detail (reconcile/import), recurring & upcoming.
import * as repo from '../repo.js';
import { db } from '../db.js';
import { html, raw, icon, openSheet, toast, confirmDlg, promptDlg, menu, evalAmount } from './dom.js';
import { state, go, registerScreen, screens } from './app.js';
import { money, today, dateLabel, FREQS, addDays } from '../util.js';
import { isLiability, expandScheduled } from '../engine/analytics.js';

function render(root) {
  const accts = repo.accounts();
  const bal = repo.accountBalances();
  const b = (id) => bal.get(id)?.balance || 0;
  const budgetAccts = accts.filter((a) => a.on_budget);
  const tracking = accts.filter((a) => !a.on_budget);
  const assets = accts.filter((a) => !isLiability(a)).reduce((s, a) => s + b(a.id), 0);
  const debts = accts.filter(isLiability).reduce((s, a) => s + b(a.id), 0);
  const upcoming = expandScheduled(repo.scheduledList(), '0000-01-01', addDays(today(), 14));
  const closed = repo.accounts(true).filter((a) => a.closed);
  const acctRow = (a) => {
    const x = bal.get(a.id) || {};
    const rec = repo.meta('reconciled_' + a.id);
    return html`<li class="item tap" data-acct="${a.id}"><div class="grow"><div class="title ellipsis">${a.name}</div>
      <div class="sub">${repo.ACCOUNT_TYPES[a.type]?.label || a.type}${x.unapproved ? html` · <b style="color:var(--accent)">${x.unapproved} to review</b>` : ''}${rec ? ` · reconciled ${dateLabel(rec)}` : ''}</div></div>
      <div class="right"><div class="amt ${(x.balance || 0) < 0 ? 'neg' : ''}">${money(x.balance || 0)}</div>${x.cleared !== x.balance ? html`<div class="tiny muted">cleared ${money(x.cleared || 0)}</div>` : ''}</div></li>`;
  };
  root.innerHTML = String(html`<div class="page">
    <div class="tiles">
      <div class="tile"><div class="l">Net worth</div><div class="v ${assets + debts < 0 ? 'neg' : ''}">${money(assets + debts)}</div><div class="d">${money(assets)} assets · ${money(debts)} debts</div></div>
      <div class="tile"><div class="l">In budget accounts</div><div class="v">${money(budgetAccts.reduce((s, a) => s + b(a.id), 0))}</div><div class="d">${budgetAccts.length} accounts</div></div>
    </div>
    <div class="wgrid"><div><div class="card"><div class="card-h"><span class="grow">Budget accounts</span><button class="btn sm ghost" data-act="add">+ Add</button></div>
      ${budgetAccts.length ? html`<ul class="list">${budgetAccts.map(acctRow)}</ul>` : html`<div class="empty">Add your everyday account, savings and credit cards.</div>`}</div>
    ${tracking.length ? html`<div class="card"><div class="card-h">Tracking (not budgeted)</div><ul class="list">${tracking.map(acctRow)}</ul></div>` : ''}
    </div><div><div class="card"><div class="card-h"><span class="grow">Upcoming · 14 days</span><button class="btn sm ghost" data-act="scheduled">All recurring</button></div>
      ${upcoming.length ? html`<ul class="list">${upcoming.map((o) => html`<li class="item tap" data-sched="${o.id}" data-date="${o.date}"><div class="grow"><div class="title ellipsis">${o.payee || 'Transfer'}</div>
        <div class="sub">${o.date < today() ? html`<b class="neg">Overdue</b> · ` : ''}${dateLabel(o.date)} · ${o.freq}${o.auto_enter ? ' · auto' : ''}</div></div><div class="amt ${o.amount > 0 ? 'in' : ''}">${money(o.amount)}</div></li>`)}</ul>`
        : html`<p class="card-b small muted">Nothing due. Make any transaction recurring from its edit sheet.</p>`}</div>
    </div></div>
    ${closed.length ? html`<details class="more"><summary>Closed accounts (${closed.length})</summary><ul class="list card">${closed.map(acctRow)}</ul></details>` : ''}
  </div>`);
  root.onclick = async (e) => {
    const t = e.target;
    const act = t.closest('[data-act]')?.dataset.act;
    if (act === 'add') return addAccount();
    if (act === 'scheduled') return go('scheduled');
    const a = t.closest('[data-acct]');
    if (a) return go('account', a.dataset.acct);
    const sc = t.closest('[data-sched]');
    if (sc) { const { openRecurring } = await import('./recurring.js'); return openRecurring(+sc.dataset.sched); }
  };
}

export function addAccount({ onDone } = {}) {
  let type = 'checking';
  const body = () => html`
    <div class="field"><label>Name</label><input class="input" id="an" placeholder="e.g. CommBank Smart Access" autocomplete="off"></div>
    <div class="field"><label>Type</label><select class="input" id="at">${Object.entries(repo.ACCOUNT_TYPES).map(([k, v]) => html`<option value="${k}" ${k === type ? raw('selected') : ''}>${v.label}${v.budget ? '' : ' (tracking)'}</option>`)}</select></div>
    <div class="field"><label>Current balance ${type === 'credit' || type === 'loan' || type === 'mortgage' ? '(amount owed)' : ''}</label><input class="input num" id="ab" inputmode="decimal" placeholder="0.00"></div>
    <p class="small muted">Budget accounts hold money you spend (everyday, savings, cash, credit cards). Tracking accounts (super, shares, loans) count towards net worth only.</p>`;
  const s = openSheet({
    title: 'Add account', body: body(),
    footer: html`<button class="btn primary block" data-act="save">Add account</button>`,
    actions: {
      save: (b, e, api) => {
        const name = s.el.querySelector('#an').value.trim();
        if (!name) return toast('Give it a name');
        const t = s.el.querySelector('#at').value;
        let bal = evalAmount(s.el.querySelector('#ab').value || '0');
        if (Number.isNaN(bal)) return toast('Balance didn’t parse');
        if (['credit', 'loan', 'mortgage'].includes(t)) bal = -Math.abs(bal);
        const id = repo.createAccount({ name, type: t, balance: bal });
        api.close(id); toast(`${name} added`);
        onDone && onDone(id);
      },
    },
  });
  const onType = (e) => { type = e.target.value; const n = s.el.querySelector('#an').value; s.setBody(body()); s.el.querySelector('#an').value = n; s.el.querySelector('#at').addEventListener('change', onType); };
  s.el.querySelector('#at').addEventListener('change', onType);
  setTimeout(() => s.el.querySelector('#an').focus(), 80);
}

// ---------- account detail ----------
function renderAccount(root) {
  const a = repo.account(+state.params.id);
  if (!a) return go('accounts');
  state.tx.accountId = a.id;
  const x = repo.accountBalances().get(a.id) || {};
  const rec = repo.meta('reconciled_' + a.id);
  root.innerHTML = String(html`<div class="page">
    <div class="tiles">
      <div class="tile"><div class="l">Balance</div><div class="v ${x.balance < 0 ? 'neg' : ''}">${money(x.balance || 0)}</div><div class="d">${money(x.cleared || 0)} cleared · ${money((x.balance || 0) - (x.cleared || 0))} pending</div></div>
      <div class="tile"><div class="l">${a.on_budget ? 'Budget account' : 'Tracking account'}</div><div class="v" style="font-size:17px">${repo.ACCOUNT_TYPES[a.type]?.label}</div><div class="d">${rec ? 'Reconciled ' + dateLabel(rec) : 'Never reconciled'}</div></div>
    </div>
    <div class="row wrap" style="margin-bottom:12px">
      <button class="btn sm primary" data-act="reconcile">${icon('check')} Reconcile</button>
      <button class="btn sm" data-act="import">${icon('upload')} Import statement</button>
      <button class="btn sm" data-act="txs">${icon('list')} Transactions</button>
      <button class="btn sm" data-act="edit">${icon('edit')} Edit</button>
    </div>
    <div id="recent"></div></div>`);
  const recent = repo.listTxns({ accountId: a.id, limit: 30 });
  root.querySelector('#recent').innerHTML = String(html`<div class="sectionlabel"><span>Recent</span></div><div class="card"><ul class="list">${recent.map((t) => html`<li class="item tap" data-tx="${t.id}"><div class="grow"><div class="title ellipsis">${t.payee || '—'}</div><div class="sub">${dateLabel(t.date)} · ${t.category_name || (t.transfer_account_id ? 'Transfer' : t.is_split ? 'Split' : '—')}</div></div><div class="right"><div class="amt ${t.amount > 0 ? 'in' : ''}">${money(t.amount)}</div><div class="tiny muted">${t.cleared}</div></div></li>`)}</ul></div>`);
  root.onclick = async (e) => {
    const act = e.target.closest('[data-act]')?.dataset.act;
    if (act === 'reconcile') return reconcileFlow(a);
    if (act === 'import') return screens.importer.start(a.id);
    if (act === 'txs') { state.tx.filter = 'all'; return go('tx'); }
    if (act === 'edit') return editAccount(a);
    const tx = e.target.closest('[data-tx]');
    if (tx) return screens.txedit.open({ id: +tx.dataset.tx });
  };
}

async function reconcileFlow(a) {
  const x = repo.accountBalances().get(a.id) || {};
  const v = await promptDlg(`Reconcile ${a.name}`, { inputmode: 'decimal', value: ((x.cleared || 0) / 100).toFixed(2), ok: 'Reconcile',
    hint: `Enter the balance your bank app shows now${a.type === 'credit' ? ' (negative if you owe money)' : ''}. Koban’s cleared balance is ${money(x.cleared || 0)}. Mark transactions cleared first.` });
  if (v == null) return;
  const cents = evalAmount(v);
  if (Number.isNaN(cents)) return toast('Didn’t parse');
  const diff = cents - (x.cleared || 0);
  if (diff !== 0 && !(await confirmDlg(`Your bank says ${money(cents)} but cleared transactions add up to ${money(x.cleared || 0)}. Create a ${money(diff)} adjustment?`, { ok: 'Adjust & reconcile', title: 'Balance differs' }))) return;
  repo.reconcile(a.id, cents);
  toast(diff ? `Reconciled with ${money(diff)} adjustment` : 'Reconciled — all matches 🎉');
}

async function editAccount(a) {
  const k = await menu(a.name, [
    { value: 'rename', label: 'Rename' },
    { value: 'budget', label: a.on_budget ? 'Make tracking account' : 'Make budget account', sub: 'Only change this before adding transactions' },
    { value: 'close', label: a.closed ? 'Reopen account' : 'Close account', sub: 'Hides it; history stays' },
    { value: 'delete', label: 'Delete account and its transactions', danger: true },
  ]);
  if (k === 'rename') { const n = await promptDlg('Rename', { value: a.name }); if (n) repo.updateAccount(a.id, { name: n.trim() }); }
  if (k === 'budget') repo.updateAccount(a.id, { on_budget: a.on_budget ? 0 : 1 });
  if (k === 'close') { repo.updateAccount(a.id, { closed: a.closed ? 0 : 1 }); go('accounts'); }
  if (k === 'delete' && await confirmDlg(`Delete ${a.name} and all its transactions? This can’t be undone.`, { danger: true, ok: 'Delete' })) {
    db.tx(() => {
      for (const t of db.all('SELECT id FROM transactions WHERE account_id=?', [a.id])) repo.deleteTxn(t.id);
      db.run("DELETE FROM categories WHERE system='ccp' AND cc_account_id=?", [a.id]);
      db.run('DELETE FROM scheduled WHERE account_id=? OR transfer_account_id=?', [a.id, a.id]);
      db.run('DELETE FROM card_map WHERE account_id=?', [a.id]);
      db.run('DELETE FROM accounts WHERE id=?', [a.id]);
    });
    go('accounts');
  }
}

registerScreen('accounts', { title: 'Accounts', top: () => ({ title: 'Accounts', back: true, actions: [{ id: 'add', icon: 'plus', label: 'Add account' }] }), topAction: (a) => a === 'add' && addAccount(), render });
registerScreen('account', { top: () => ({ title: repo.account(+state.params.id)?.name || 'Account', back: true }), render: renderAccount });
