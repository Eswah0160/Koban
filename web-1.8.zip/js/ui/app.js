// App shell: router, nav, render loop.
import { db, meta, setMeta } from '../db.js';
import * as repo from '../repo.js';
import { html, raw, icon, $, closeTopSheet, sheetOpen, toast } from './dom.js';
import { thisMonth } from '../util.js';
import * as native from '../native.js';

const screens = {};
export function registerScreen(name, mod) { screens[name] = mod; }

export const state = {
  route: 'home', params: {}, month: thisMonth(), selectedCat: null,
  closedGroups: new Set(),
  tx: { filter: 'all', q: '', accountId: null, selecting: false, selected: new Set() },
  insightsTab: 'spending',
};

const NAV = [
  ['home', 'Home', 'home'],
  ['budget', 'Budget', 'budget'],
  ['add', '', 'plus'],
  ['tx', 'Activity', 'list'],
  ['more', 'More', 'grid'],
];

let appEl, mainEl, topEl, navEl;
let renderQueued = false;

export function mount(root) {
  appEl = root;
  state.closedGroups = new Set(meta('closed_groups', []) || []);
  appEl.innerHTML = String(html`<header class="topbar" id="top"></header><main id="main"></main><nav class="bottomnav" id="nav"></nav>`);
  mainEl = $('#main'); topEl = $('#top'); navEl = $('#nav');
  navEl.addEventListener('click', (e) => {
    const b = e.target.closest('[data-nav]');
    if (!b) return;
    native.haptic('tick');
    if (b.dataset.nav === 'add') return screens.txedit.open({});
    go(b.dataset.nav);
  });
  topEl.addEventListener('click', (e) => {
    const b = e.target.closest('[data-top]');
    if (!b) return;
    const a = b.dataset.top;
    if (a === 'back') return back();
    if (a === 'settings') return go('settings');
    const scr = screens[state.route];
    scr?.topAction && scr.topAction(a, b);
  });
  window.addEventListener('hashchange', fromHash);
  db.onChange(() => queueRender());
  // Android back button / gesture (native calls this; returns true if handled)
  window.kobanBack = () => {
    if (sheetOpen()) { closeTopSheet(); return true; }
    if (state.tx.selecting) { state.tx.selecting = false; state.tx.selected.clear(); render(); return true; }
    if (state.route !== 'home') { back(); return true; }
    return false;
  };
  window.kobanRoute = (r) => routeTo(r);
  fromHash();
}

export function routeTo(r) {
  if (!r) return;
  if (r === 'add') return screens.txedit.open({});
  if (r === 'receipt') return screens.receipt?.start();
  if (r === 'import') return screens.importer?.start();
  location.hash = '#/' + r;
}

function fromHash() {
  const parts = (location.hash.replace(/^#\/?/, '') || 'home').split('/');
  state.route = screens[parts[0]] ? parts[0] : 'home';
  state.params = { id: parts[1] ? decodeURIComponent(parts[1]) : null };
  mainEl.scrollTop = 0;
  render();
}
export function go(route, id = null) { location.hash = '#/' + route + (id != null ? '/' + encodeURIComponent(id) : ''); }
export function back() { if (history.length > 1) history.back(); else go('home'); }

export function queueRender() {
  if (renderQueued) return;
  renderQueued = true;
  requestAnimationFrame(() => { renderQueued = false; render(); });
}

export function render() {
  const scr = screens[state.route];
  if (!scr) return;
  const c = repo.counts();
  const top = scr.top ? scr.top(state) : { title: scr.title };
  topEl.innerHTML = String(html`
    ${top.back ? html`<button class="iconbtn" data-top="back" aria-label="Back">${icon('back')}</button>` : ''}
    ${top.center ? raw(String(top.center)) : html`<h1 class="grow ellipsis">${top.title || ''}</h1>`}
    ${(top.actions || []).map((a) => html`<button class="iconbtn" data-top="${a.id}" aria-label="${a.label}" title="${a.label}">${icon(a.icon)}</button>`)}
    ${top.noSettings ? '' : html`<button class="iconbtn" data-top="settings" aria-label="Settings">${icon('gear')}</button>`}`);
  navEl.innerHTML = String(html`${NAV.map(([id, label, ic]) => id === 'add'
    ? html`<div style="display:grid"><button class="fab" data-nav="add" aria-label="Add transaction">${icon(ic)}</button></div>`
    : html`<button class="navbtn ${navActive(id) ? 'on' : ''}" data-nav="${id}">${icon(ic)}<span>${label}</span>${id === 'tx' && c.inbox ? html`<span class="badge">${c.inbox}</span>` : ''}</button>`)}`);
  const st = mainEl.scrollTop;
  scr.render(mainEl, state, c);
  mainEl.scrollTop = st;
}
function navActive(id) {
  const r = state.route;
  if (id === r) return true;
  if (id === 'more' && ['accounts', 'account', 'scheduled', 'insights', 'settings', 'categories', 'rules', 'capture'].includes(r)) return true;
  return false;
}

export function saveClosedGroups() { setMeta('closed_groups', [...state.closedGroups]); }
export { screens, toast };
