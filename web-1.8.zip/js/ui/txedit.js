// Add / edit transaction sheet (spend, income, transfer, splits, flags, receipt, recurring).
import * as repo from '../repo.js';
import { db } from '../db.js';
import { html, raw, icon, openSheet, toast, confirmDlg, menu, evalAmount } from './dom.js';
import { registerScreen, screens } from './app.js';
import { pickCategory } from './pickers.js';
import { money, today, FREQS, nextOccurrence, normPayee } from '../util.js';
import * as native from '../native.js';

const FLAGS = ['red', 'orange', 'yellow', 'green', 'blue', 'purple'];

function recentPayees() {
  return db.all(`SELECT payee, COUNT(*) n FROM transactions WHERE payee IS NOT NULL AND transfer_account_id IS NULL AND is_opening=0
    GROUP BY payee ORDER BY MAX(date) DESC LIMIT 300`).map((r) => r.payee);
}

/** open({id}) to edit, or open({prefill}) for new. Returns the sheet. */
function open({ id = null, prefill = {} } = {}) {
  const orig = id ? repo.txn(id) : null;
  const accts = repo.accounts();
  if (!accts.length) { toast('Add an account first'); screens.accounts && (location.hash = '#/accounts'); return; }
  const lastAcct = Number(repo.meta('last_account', 0)) || accts.find((a) => a.on_budget)?.id || accts[0].id;
  const t = orig ? { ...orig, splits: orig.splits ? orig.splits.map((s) => ({ ...s })) : null } : {
    account_id: lastAcct, date: today(), amount: 0, payee: '', category_id: null, memo: '', cleared: 'uncleared', approved: 1, flag: null, ...prefill,
  };
  let kind = t.transfer_account_id ? 'transfer' : t.amount > 0 ? 'income' : 'spend';
  let catTouched = !!orig;
  let learn = !!(orig && orig.raw_payee && !orig.approved);
  const inc = repo.incomeCategoryId();
  const idx = repo.categoryIndex();

  const amtStr = () => (t.amount ? (Math.abs(t.amount) / 100).toFixed(2) : '');
  const splitTotal = () => (t.splits || []).reduce((s, x) => s + (x.amount || 0), 0);

  const body = () => html`
    <div class="seg" style="margin-bottom:6px">${[['spend', 'Spend'], ['income', 'Income'], ['transfer', 'Transfer']].map(([k, l]) => html`<button data-act="kind" data-k="${k}" class="${kind === k ? 'on' : ''}">${l}</button>`)}</div>
    <div class="amtrow"><span class="cur">${kind === 'income' ? '+$' : kind === 'transfer' ? '$' : '−$'}</span><input class="bigamt ${kind === 'income' ? 'in' : 'out'}" id="amt" inputmode="decimal" placeholder="0.00" value="${amtStr()}" autocomplete="off"></div>
    ${kind !== 'transfer' ? html`<label class="pickrow"><span class="k">Payee</span><input id="payee" list="payees" value="${t.payee || ''}" placeholder="Who" autocomplete="off"></label>
      <datalist id="payees">${recentPayees().map((p) => html`<option value="${p}">`)}</datalist>` : ''}
    ${orig?.raw_payee ? html`<div class="small muted" style="padding:6px 2px">Bank text: <span class="kbd">${orig.raw_payee}</span></div>
      <label class="row small" style="padding:2px 2px 6px"><input type="checkbox" id="learn" ${learn ? raw('checked') : ''}> Remember payee + category for “${normPayee(orig.raw_payee).split(' ').slice(0, 2).join(' ')}”</label>` : ''}
    ${kind === 'transfer' ? '' : t.splits ? splitsHtml() : html`<button class="pickrow" data-act="cat"><span class="k">Category</span><span class="v ${t.category_id == null ? 'muted' : ''}">${t.category_id == null ? 'Choose…' : idx.name(t.category_id)}</span>
        <span class="btn sm" data-act="split">${icon('split')} Split</span></button>`}
    <label class="pickrow"><span class="k">${kind === 'transfer' ? 'From' : 'Account'}</span><select id="acct">${accts.map((a) => html`<option value="${a.id}" ${a.id === t.account_id ? raw('selected') : ''}>${a.name}</option>`)}</select></label>
    ${kind === 'transfer' ? html`<label class="pickrow"><span class="k">To</span><select id="to">${accts.filter((a) => a.id !== t.account_id).map((a) => html`<option value="${a.id}" ${a.id === t.transfer_account_id ? raw('selected') : ''}>${a.name}</option>`)}</select></label>
      ${transferNeedsCat() ? html`<button class="pickrow" data-act="cat"><span class="k">Category</span><span class="v ${t.category_id == null ? 'muted' : ''}">${t.category_id == null ? 'Choose… (tracking account)' : idx.name(t.category_id)}</span></button>` : ''}` : ''}
    <label class="pickrow"><span class="k">Date</span><input id="date" type="date" value="${t.date}"></label>
    <label class="pickrow"><span class="k">Memo</span><input id="memo" value="${t.memo || ''}" placeholder="Optional"></label>
    <div class="pickrow"><span class="k">Cleared</span><span class="v small muted">${t.cleared === 'reconciled' ? 'Reconciled 🔒' : 'Shows on your bank statement'}</span><label class="toggle"><input type="checkbox" id="cleared" ${t.cleared !== 'uncleared' ? raw('checked') : ''} ${t.cleared === 'reconciled' ? raw('disabled') : ''}><span></span></label></div>
    <div class="pickrow"><span class="k">Flag</span><span class="v row">${FLAGS.map((f) => html`<button data-act="flag" data-f="${f}" class="iconbtn" style="width:32px;height:32px;${t.flag === f ? 'background:var(--surface-3)' : ''}" aria-label="${f}"><span class="flag ${f}" style="width:14px;height:14px;margin:0"></span></button>`)}</span></div>
    <div class="row wrap" style="margin-top:12px">
      ${t.receipt_id ? html`<button class="btn sm" data-act="view-receipt">${icon('receipt')} Receipt</button>` : html`<button class="btn sm" data-act="add-receipt">${icon('camera')} Attach receipt</button>`}
      ${kind !== 'transfer' || true ? html`<button class="btn sm" data-act="repeat">${icon('repeat')} ${t.scheduled_id ? 'Recurring' : 'Make recurring'}</button>` : ''}
    </div>`;

  const remText = (rem) => (rem === 0 ? 'Balanced ✓' : `${money(Math.abs(rem))} ${rem > 0 ? 'left to split' : 'over'}`);
  const splitsHtml = () => {
    const rem = Math.abs(t.amount) - Math.abs(splitTotal());
    return html`<div class="lbl" style="margin-top:10px">Split</div>
      ${t.splits.map((s, i) => html`<div class="row" style="padding:6px 0;border-bottom:1px solid var(--line)">
        <button class="btn sm grow" data-act="split-cat" data-i="${i}" style="justify-content:flex-start">${s.category_id == null ? 'Category…' : idx.name(s.category_id)}</button>
        <input class="input num" style="width:110px;min-height:36px" data-split-amt="${i}" inputmode="decimal" value="${s.amount ? (Math.abs(s.amount) / 100).toFixed(2) : ''}" placeholder="0.00">
        <button class="iconbtn" data-act="split-del" data-i="${i}" style="width:36px;height:36px">${icon('close')}</button></div>`)}
      <div class="row" style="padding:8px 0"><button class="btn sm" data-act="split-add">+ Add split</button><span class="grow"></span>
        <span class="small ${rem === 0 ? 'pos' : 'neg'}" id="split-rem">${remText(rem)}</span></div>`;
  };

  function transferNeedsCat() {
    const A = repo.account(t.account_id), B = t.transfer_account_id ? repo.account(t.transfer_account_id) : accts.find((a) => a.id !== t.account_id);
    return A && B && A.on_budget !== B.on_budget;
  }

  function readForm() {
    const el = s.el;
    const a = evalAmount(el.querySelector('#amt').value);
    const mag = Number.isNaN(a) ? 0 : Math.abs(a);
    t.amount = kind === 'income' ? mag : -mag;
    if (kind === 'transfer') t.amount = -mag;
    const p = el.querySelector('#payee'); if (p) t.payee = p.value.trim();
    t.account_id = +el.querySelector('#acct').value;
    const to = el.querySelector('#to'); t.transfer_account_id = kind === 'transfer' && to ? +to.value : null;
    t.date = el.querySelector('#date').value || today();
    t.memo = el.querySelector('#memo').value.trim() || null;
    const cl = el.querySelector('#cleared'); if (t.cleared !== 'reconciled') t.cleared = cl.checked ? 'cleared' : 'uncleared';
    const lr = el.querySelector('#learn'); if (lr) learn = lr.checked;
    if (t.splits) el.querySelectorAll('[data-split-amt]').forEach((inp) => {
      const v = evalAmount(inp.value); t.splits[+inp.dataset.splitAmt].amount = Number.isNaN(v) ? 0 : (t.amount < 0 ? -Math.abs(v) : Math.abs(v));
    });
  }
  const redraw = () => { readForm(); s.setBody(body()); bindInputs(); };

  async function save(approve = true) {
    readForm();
    if (!t.amount) return toast('Enter an amount');
    if (kind === 'transfer' && !t.transfer_account_id) return toast('Pick the other account');
    if (t.splits) {
      if (t.splits.some((x) => x.category_id == null)) return toast('Every split needs a category');
      if (Math.abs(splitTotal()) !== Math.abs(t.amount)) return toast('Splits must add up to the total');
    }
    if (kind === 'income' && t.category_id == null && !t.splits) t.category_id = inc;
    t.approved = approve ? 1 : t.approved;
    const savedId = repo.saveTxn(t);
    if (learn && orig?.raw_payee && (t.payee || t.category_id != null)) repo.learnFrom(orig.raw_payee, t.payee, t.splits ? null : t.category_id);
    repo.setMeta('last_account', t.account_id);
    native.haptic('confirm');
    s.close(savedId);
    if (!orig) toast(`Saved ${money(t.amount)}`, { action: 'Undo', onAction: () => repo.deleteTxn(savedId) });
    return savedId;
  }

  const s = openSheet({
    title: orig ? (orig.approved ? 'Edit transaction' : 'Review transaction') : 'New transaction',
    body: body(),
    footer: html`${orig ? html`<button class="btn danger" data-act="delete" aria-label="Delete">${icon('trash')}</button>` : html`<button class="btn" data-act="save-add">Save + new</button>`}
      <button class="btn primary grow" data-act="save">${orig && !orig.approved ? 'Approve' : 'Save'}</button>`,
    actions: {
      kind: (b) => { readForm(); kind = b.dataset.k; if (kind === 'income' && !catTouched) t.category_id = inc; if (kind === 'spend' && t.category_id === inc) t.category_id = null; if (kind === 'transfer') t.splits = null; redraw(); },
      cat: async () => { readForm(); const c = await pickCategory({ date: t.date, allowIncome: kind !== 'spend' || true }); if (c !== undefined) { t.category_id = c; catTouched = true; learn = learn || !!orig?.raw_payee; s.setBody(body()); bindInputs(); } },
      split: (b, e) => { e.stopPropagation(); readForm(); t.splits = [{ category_id: t.category_id, amount: t.amount }, { category_id: null, amount: 0 }]; redraw(); },
      'split-add': () => { readForm(); const rem = t.amount - splitTotal(); t.splits.push({ category_id: null, amount: rem }); redraw(); },
      'split-del': (b) => { readForm(); t.splits.splice(+b.dataset.i, 1); if (t.splits.length < 2) { t.category_id = t.splits[0]?.category_id ?? null; t.splits = null; } redraw(); },
      'split-cat': async (b) => { readForm(); const c = await pickCategory({ date: t.date }); if (c !== undefined) { t.splits[+b.dataset.i].category_id = c; s.setBody(body()); bindInputs(); } },
      flag: (b) => { readForm(); t.flag = t.flag === b.dataset.f ? null : b.dataset.f; redraw(); },
      save: () => save(true),
      'save-add': async () => { const id2 = await save(true); if (id2) open({ prefill: { account_id: t.account_id, date: t.date } }); },
      delete: async () => { if (await confirmDlg('Delete this transaction?', { danger: true, ok: 'Delete' })) { const snapshot = repo.txn(orig.id); repo.deleteTxn(orig.id); s.close(); toast('Deleted', { action: 'Undo', onAction: () => { delete snapshot.id; delete snapshot.transfer_txn_id; repo.saveTxn(snapshot); } }); } },
      'add-receipt': () => { readForm(); s.close(); screens.receipt.start({ attachTo: orig?.id ?? null, draft: orig ? null : { ...t } }); },
      'view-receipt': () => screens.receipt.view(t.receipt_id),
      repeat: () => { readForm(); makeRecurring(t); },
    },
  });
  function bindInputs() {
    const p = s.el.querySelector('#payee');
    if (p) p.addEventListener('change', () => {
      if (catTouched || !p.value.trim()) return;
      const sug = repo.suggest(p.value, t.account_id, kind === 'income' ? 1 : -1);
      if (sug.category_id != null) { readForm(); t.category_id = sug.category_id; s.setBody(body()); bindInputs(); toast(`Category: ${idx.name(sug.category_id)} (${sug.why})`, { ms: 1800 }); }
    });
    const acct = s.el.querySelector('#acct');
    acct.addEventListener('change', () => redraw());
    const to = s.el.querySelector('#to');
    if (to) to.addEventListener('change', () => redraw());
    // Update "left to split" live without re-rendering (keeps focus/keyboard while typing)
    const updRem = () => {
      readForm();
      const rem = Math.abs(t.amount) - Math.abs(splitTotal());
      const el = s.el.querySelector('#split-rem');
      if (el) { el.textContent = remText(rem); el.className = 'small ' + (rem === 0 ? 'pos' : 'neg'); }
    };
    s.el.querySelectorAll('[data-split-amt]').forEach((i) => i.addEventListener('input', updRem));
    if (t.splits) s.el.querySelector('#amt').addEventListener('input', updRem);
  }
  bindInputs();
  if (!orig) setTimeout(() => s.el.querySelector('#amt')?.focus(), 80);
  return s;
}

async function makeRecurring(t) {
  const { openRecurring } = await import('./recurring.js');
  if (t.scheduled_id && db.get('SELECT id FROM scheduled WHERE id=?', [t.scheduled_id])) return openRecurring(t.scheduled_id);
  openRecurring(null, { account_id: t.account_id, payee: t.payee, amount: t.amount, category_id: t.splits ? null : t.category_id,
    transfer_account_id: t.transfer_account_id, freq: 'monthly', next_date: nextOccurrence(t.date || today(), 'monthly'), auto_enter: 1 });
}

registerScreen('txedit', { open, render() {} });
export { open as openTxn };
