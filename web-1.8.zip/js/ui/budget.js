// Budget screen: month view of envelopes + category detail.
import * as repo from '../repo.js';
import { db, meta, setMeta } from '../db.js';
import { html, raw, icon, openSheet, menu, promptDlg, toast, confirmDlg, evalAmount } from './dom.js';
import { state, go, registerScreen, saveClosedGroups, queueRender } from './app.js';
import { pickCategory } from './pickers.js';
import { autoAssign, UNCATEGORIZED } from '../engine/budget.js';
import { money, monthLabel, addMonths, thisMonth, FREQS, dateLabel, today } from '../util.js';
import * as native from '../native.js';

const isWide = () => window.matchMedia('(min-width: 720px)').matches;
let filter = null; // 'underfunded' | 'overspent' | null

function pillClass(row, cat) {
  if (!row) return '';
  if (row.available < 0) return 'bad';
  if (row.target && row.target.underfunded > 0) return 'warn';
  if (cat?.system === 'ccp' && row.available >= 0) return row.available > 0 ? 'good' : '';
  return row.available > 0 ? 'good' : '';
}

function catRow(c, row, sel) {
  const t = row?.target;
  let bar = '';
  if (t) {
    const cls = row.available < 0 ? 'bad' : t.underfunded > 0 ? 'warn' : '';
    bar = html`<div class="bar"><i class="${cls}" style="width:${Math.round(t.progress * 100)}%"></i></div>`;
  } else if (row && row.assigned + row.carryIn > 0 && row.activity < 0) {
    const used = Math.min(1, -row.activity / (row.assigned + row.carryIn));
    bar = html`<div class="bar"><i class="${row.available < 0 ? 'bad' : ''}" style="width:${Math.round(used * 100)}%;opacity:.55"></i></div>`;
  }
  let meta = '';
  if (row?.available < 0) meta = row.creditOverspent > 0 && row.cashOverspent === 0 ? 'Overspent on credit' : 'Overspent — cover it';
  else if (t?.underfunded > 0) meta = `${money(t.underfunded)} more needed ${t.label ? '· ' + t.label : ''}`;
  else if (t) meta = t.type === 'balance' || t.type === 'by_date' ? `${Math.round(t.progress * 100)}% of ${money(t.amount, { whole: true })}` : 'Funded';
  return html`<div class="cat ${sel ? 'sel' : ''}" data-cat="${c.id}">
    <div class="nm"><div class="ellipsis">${c.emoji ? c.emoji + ' ' : ''}${c.name}</div>${bar}${meta ? html`<div class="meta ellipsis">${meta}</div>` : ''}</div>
    <div class="as" data-assign="${c.id}">${money(row?.assigned ?? 0)}</div>
    <div class="act">${money(row?.activity ?? 0)}</div>
    <div class="pill ${pillClass(row, c)}">${money(row?.available ?? 0)}</div>
  </div>`;
}

function render(root) {
  const m = state.month;
  const B = repo.budget(m);
  const b = B.months.get(m);
  const idx = repo.categoryIndex();
  const c = repo.counts();
  const rta = b?.rta ?? 0;
  const wide = isWide();
  if (wide && state.selectedCat == null) state.selectedCat = idx.categories.find((x) => !x.system)?.id ?? null;

  const overspent = [...(b?.cats.values() || [])].filter((r) => r.available < 0);
  const groupsHtml = [];
  const uncat = b?.cats.get(UNCATEGORIZED);
  if (uncat && (uncat.activity !== 0 || uncat.available !== 0)) {
    groupsHtml.push(html`<div class="grp-h"><span>Needs a category</span><span></span><span class="act"></span><span></span></div>
      <div class="cat" data-uncat="1"><div class="nm"><div>Uncategorised</div><div class="meta">${c.uncategorised} transaction${c.uncategorised === 1 ? '' : 's'} — tap to categorise</div></div><div class="as"></div><div class="act">${money(uncat.activity)}</div><div class="pill ${uncat.available < 0 ? 'bad' : ''}">${money(uncat.available)}</div></div>`);
  }
  for (const g of idx.groups) {
    if (g.system === 'income' || g.hidden) continue;
    let cats = idx.categories.filter((x) => x.group_id === g.id && !x.hidden);
    if (filter === 'underfunded') cats = cats.filter((x) => b?.cats.get(x.id)?.target?.underfunded > 0);
    if (filter === 'overspent') cats = cats.filter((x) => b?.cats.get(x.id)?.available < 0);
    if (!cats.length) continue;
    const closed = state.closedGroups.has(g.id) && !filter;
    const tot = cats.reduce((s, x) => { const r = b?.cats.get(x.id); s.a += r?.assigned || 0; s.act += r?.activity || 0; s.av += r?.available || 0; return s; }, { a: 0, act: 0, av: 0 });
    groupsHtml.push(html`<div class="grp-h ${closed ? 'closed' : ''}" data-grp="${g.id}"><span class="ellipsis"><span class="chev">▾</span> ${g.name}</span><span class="right num">${money(tot.a)}</span><span class="act">${money(tot.act)}</span><span class="right num">${money(tot.av)}</span></div>`);
    if (!closed) for (const x of cats) groupsHtml.push(catRow(x, b?.cats.get(x.id), wide && state.selectedCat === x.id));
  }

  const rtaCls = rta > 0 ? 'pos' : rta < 0 ? 'neg' : '';
  const rtaLabel = rta > 0 ? 'Ready to Assign' : rta < 0 ? 'Assigned more than you have' : 'All money assigned';
  const list = html`
    <button class="rta ${rtaCls}" data-act="rta" style="width:100%;border:0;text-align:left">
      <div class="grow"><div class="v num">${money(rta)}</div><div class="l">${rtaLabel}${b?.overspentFromLastMonth ? html` · ${money(-b.overspentFromLastMonth)} overspent in ${monthLabel(addMonths(m, -1), { month: 'short' })}` : ''}</div></div>
      <span class="btn sm primary">${rta > 0 ? 'Assign' : rta < 0 ? 'Fix' : 'Auto'}</span>
    </button>
    ${c.inbox ? html`<button class="banner" data-act="inbox">${icon('inbox')}<span class="grow">${c.inbox} transaction${c.inbox === 1 ? '' : 's'} to review</span>${icon('fwd')}</button>` : ''}
    <div class="chips">
      <button class="chip ${filter === 'underfunded' ? 'on' : b?.underfunded ? 'warn' : ''}" data-act="f-under">Underfunded ${money(b?.underfunded ?? 0)}</button>
      <button class="chip ${filter === 'overspent' ? 'on' : overspent.length ? 'bad' : ''}" data-act="f-over">Overspent ${overspent.length}</button>
      <span class="chip">Assigned ${money(b?.assigned ?? 0)}</span>
      <span class="chip">Spent ${money(-(b?.activity ?? 0))}</span>
    </div>
    <div class="card ${wide ? 'cols-3' : ''}" id="cats">
      <div class="grp-h" style="background:var(--surface)"><span class="muted">CATEGORY</span><span class="right muted">ASSIGNED</span><span class="act muted">ACTIVITY</span><span class="right muted">AVAILABLE</span></div>
      ${groupsHtml.length ? groupsHtml : html`<div class="empty">${filter ? 'Nothing here — nice.' : 'No categories yet.'}</div>`}
    </div>
    <button class="btn ghost block" data-act="edit-cats">${icon('edit')} Edit categories</button>`;

  root.innerHTML = String(html`<div class="page"><div class="split"><div>${list}</div><div class="pane-detail card" id="detail">${wide && state.selectedCat != null ? detailHtml(state.selectedCat) : ''}</div></div></div>`);
  root.onclick = (e) => onClick(e, root);
  if (wide) bindDetail(root.querySelector('#detail'), state.selectedCat);
}

async function onClick(e, root) {
  const t = e.target;
  const a = t.closest('[data-act]')?.dataset.act;
  if (t.closest('#detail')) return; // handled by bindDetail
  if (a === 'rta') return assignMenu();
  if (a === 'inbox') { state.tx.filter = 'review'; return go('tx'); }
  if (a === 'f-under') { filter = filter === 'underfunded' ? null : 'underfunded'; return queueRender(); }
  if (a === 'f-over') { filter = filter === 'overspent' ? null : 'overspent'; return queueRender(); }
  if (a === 'edit-cats') return go('categories');
  const grp = t.closest('[data-grp]');
  if (grp) { const id = +grp.dataset.grp; state.closedGroups.has(id) ? state.closedGroups.delete(id) : state.closedGroups.add(id); saveClosedGroups(); return queueRender(); }
  if (t.closest('[data-uncat]')) { state.tx.filter = 'uncat'; return go('tx'); }
  const as = t.closest('[data-assign]');
  if (as) return editAssigned(+as.dataset.assign);
  const cat = t.closest('[data-cat]');
  if (cat) {
    const id = +cat.dataset.cat;
    if (isWide()) { state.selectedCat = id; return queueRender(); }
    return openCategory(id);
  }
}

export async function editAssigned(cid) {
  const m = state.month;
  const cur = repo.assignedFor(m, cid);
  const row = repo.budget(m).months.get(m).cats.get(cid);
  const name = repo.category(cid)?.name;
  const v = await promptDlg(`Assign to ${name}`, { value: cur ? (cur / 100).toFixed(2) : '', inputmode: 'decimal', placeholder: '0.00',
    hint: `Available now ${money(row?.available ?? 0)}. You can type maths, e.g. 120+45 or +50 to add.` });
  if (v == null) return;
  let cents;
  if (/^\s*[+]/.test(v)) cents = cur + evalAmount(v.replace(/^\s*\+/, ''));
  else cents = evalAmount(v || '0');
  if (Number.isNaN(cents)) return toast('That amount didn’t parse');
  repo.setAssigned(m, cid, cents);
  native.haptic('tick');
}

async function assignMenu() {
  const m = state.month;
  const B = repo.budget(m);
  const cats = repo.categories();
  const preview = (s) => { const p = autoAssign(s, B, m, cats); let d = 0; for (const [cid, v] of p) d += v - (B.months.get(m).cats.get(cid)?.assigned || 0); return { p, d }; };
  const opts = [
    ['underfunded', 'Fund underfunded targets'], ['cover_overspent', 'Cover all overspending'], ['last_assigned', 'Assigned last month'],
    ['last_spent', 'Spent last month'], ['avg_spent', 'Average spent (3 months)'], ['zero_out', 'Reset available to zero'], ['reset', 'Reset all assigned to zero'],
  ].map(([k, l]) => { const { p, d } = preview(k); return { value: k, label: l, sub: p.size ? `${d >= 0 ? 'Assigns' : 'Frees'} ${money(Math.abs(d))} across ${p.size} categor${p.size === 1 ? 'y' : 'ies'}` : 'Nothing to change', disabled: !p.size, danger: k === 'reset' }; });
  const k = await menu(`Auto-assign · ${monthLabel(m)}`, opts);
  if (!k) return;
  const { p } = preview(k);
  const before = new Map([...p.keys()].map((cid) => [cid, repo.assignedFor(m, cid)]));
  repo.applyAssignments(m, p);
  toast(`Updated ${p.size} categories`, { action: 'Undo', onAction: () => repo.applyAssignments(m, before) });
}

// ---------- category detail ----------
function detailHtml(cid) {
  const c = repo.category(cid);
  if (!c) return html`<div class="empty">Select a category</div>`;
  const m = state.month;
  const B = repo.budget(m);
  const r = B.months.get(m).cats.get(cid) || { assigned: 0, activity: 0, available: 0, carryIn: 0 };
  const prev = B.months.get(addMonths(m, -1))?.cats.get(cid);
  const hist = [];
  for (let i = 5; i >= 0; i--) { const mm = addMonths(m, -i); hist.push({ m: mm, spent: Math.max(0, -(B.months.get(mm)?.cats.get(cid)?.activity ?? 0)) }); }
  const maxSpent = Math.max(1, ...hist.map((h) => h.spent));
  const avg = Math.round(hist.slice(0, 5).reduce((s, h) => s + h.spent, 0) / 5);
  const txs = repo.listTxns({ categoryId: cid, limit: 6 });
  const t = r.target;
  const quick = [];
  if (t?.underfunded) quick.push(['set', r.assigned + t.underfunded, `Fund target ${money(t.underfunded, { sign: true })}`]);
  if (r.available < 0) quick.push(['set', r.assigned - r.available, `Cover ${money(-r.available)}`]);
  if (prev) quick.push(['set', prev.assigned, `Last month ${money(prev.assigned)}`]);
  if (avg) quick.push(['set', avg, `Avg spent ${money(avg)}`]);
  return html`
    <div class="card-b" style="padding-top:14px">
      <div class="row"><div class="grow"><div class="small muted">${repo.categoryIndex().gById.get(c.group_id)?.name}</div><div style="font-size:19px;font-weight:650">${c.emoji ? c.emoji + ' ' : ''}${c.name}</div></div>
        <span class="pill ${pillClass(r, c)}" style="font-size:17px">${money(r.available)}</span></div>
      <table class="tbl" style="margin:10px 0">
        <tr><td class="muted">Carried from last month</td><td class="n">${money(r.carryIn)}</td></tr>
        <tr><td class="muted">Assigned this month</td><td class="n">${money(r.assigned)}</td></tr>
        <tr><td class="muted">Activity</td><td class="n">${money(r.activity)}</td></tr>
        <tr><td><b>Available</b></td><td class="n"><b>${money(r.available)}</b></td></tr>
      </table>
      ${r.available < 0 ? html`<p class="small ${r.creditOverspent && !r.cashOverspent ? '' : 'neg'}">${r.creditOverspent && !r.cashOverspent
        ? 'Overspent on a credit card: if not covered this month it becomes card debt (it won’t reduce Ready to Assign).'
        : 'Cash overspending: cover it, or it comes out of next month’s Ready to Assign.'}</p>` : ''}
      <div class="lbl">Assign</div>
      <div class="row" style="margin:4px 0 6px"><input class="input num" id="asg" inputmode="decimal" value="${(r.assigned / 100).toFixed(2)}"><button class="btn primary" data-d="assign">Set</button></div>
      <div class="chips wrap">${quick.map(([k, v, l]) => html`<button class="chip acc" data-d="quick" data-v="${v}">${l}</button>`)}</div>
      <div class="row" style="margin:4px 0 14px"><button class="btn sm grow" data-d="move-out">${icon('move')} Move to…</button><button class="btn sm grow" data-d="cover-from">Take from…</button></div>

      <div class="lbl">Target</div>
      ${t ? html`<div class="row" style="margin:6px 0"><div class="grow"><b>${targetText(c)}</b><div class="small muted">${t.underfunded ? money(t.underfunded) + ' more needed this month' : 'On track this month'}</div></div><button class="btn sm" data-d="target">Edit</button></div>
          <div class="cat" style="padding:0;border:0;min-height:0;display:block"><div class="bar"><i class="${t.underfunded ? 'warn' : ''}" style="width:${Math.round(t.progress * 100)}%"></i></div></div>`
        : html`<button class="btn sm block" data-d="target" style="margin:6px 0">${icon('target')} Add a target</button>`}

      ${c.system === 'ccp' ? ccpHtml(c, r) : html`<div class="lbl" style="margin-top:14px">Spending, last 6 months · avg ${money(avg)}</div>
      ${hist.map((h) => html`<div class="hbar"><span class="small ink2">${monthLabel(h.m, { month: 'short', year: '2-digit' })}</span><span class="track"><i style="width:${(h.spent / maxSpent) * 100}%"></i></span><span class="small num">${money(h.spent, { whole: true })}</span></div>`)}`}

      <div class="lbl" style="margin-top:14px">Recent</div>
      ${txs.length ? html`<ul class="list">${txs.map((x) => html`<li class="item tap" data-d="tx" data-id="${x.id}" style="padding:8px 0"><div class="grow"><div class="title ellipsis">${x.payee || '—'}</div><div class="sub">${dateLabel(x.date)} · ${x.account_name}</div></div><div class="amt ${x.amount > 0 ? 'in' : ''}">${money(x.amount)}</div></li>`)}</ul>
        <button class="btn ghost sm" data-d="all-tx">See all</button>` : html`<p class="small muted">No transactions yet.</p>`}
      ${c.note ? html`<p class="small ink2" style="white-space:pre-wrap">${c.note}</p>` : ''}
      <div class="row wrap" style="margin-top:12px">
        ${c.system ? '' : html`<button class="btn sm" data-d="pin">${(meta('pinned_cats', []) || []).includes(c.id) ? 'Unpin from home' : 'Pin to home'}</button>`}
        <button class="btn sm" data-d="rename">Rename</button><button class="btn sm" data-d="note">Note</button>
        ${c.system ? '' : html`<button class="btn sm" data-d="hide">Hide</button><button class="btn sm danger" data-d="delete">Delete</button>`}
      </div>
    </div>`;
}

function ccpHtml(c, r) {
  const bal = repo.accountBalances().get(c.cc_account_id)?.balance || 0;
  const owed = Math.max(0, -bal);
  const gap = owed - Math.max(0, r.available);
  return html`<div class="lbl" style="margin-top:14px">Card</div>
    <table class="tbl" style="margin:6px 0"><tr><td class="muted">Card balance owed</td><td class="n">${money(owed)}</td></tr>
      <tr><td class="muted">Set aside to pay it</td><td class="n">${money(Math.max(0, r.available))}</td></tr>
      <tr><td><b>${gap > 0 ? 'Not yet covered' : 'Covered'}</b></td><td class="n ${gap > 0 ? 'neg' : 'pos'}"><b>${money(Math.abs(gap))}</b></td></tr></table>
    <p class="small muted">Card purchases from funded categories move money here automatically. ${gap > 0 ? 'Assign the uncovered amount here to pay the card in full (it comes from older debt or overspending on the card).' : 'Pay the card by transferring this amount from your everyday account.'}</p>
    ${gap > 0 ? html`<button class="chip acc" data-d="quick" data-v="${r.assigned + gap}">Cover ${money(gap)}</button>` : ''}`;
}

function targetText(c) {
  const X = money(c.target_amount || 0);
  switch (c.target_type) {
    case 'monthly': return `${X} every month`;
    case 'refill': return `Refill up to ${X} each month`;
    case 'by_date': return `${X} by ${dateLabel(c.target_date)}`;
    case 'balance': return `Save ${X}`;
    case 'bill': return `${X} ${c.target_freq || 'monthly'}, next due ${dateLabel(c.target_date)}`;
    default: return '';
  }
}

function bindDetail(el, cid, sheet = null) {
  if (!el) return;
  el.onclick = async (e) => {
    const b = e.target.closest('[data-d]');
    if (!b) return;
    const d = b.dataset.d;
    const m = state.month;
    const c = repo.category(cid);
    if (d === 'assign') {
      const v = evalAmount(el.querySelector('#asg').value);
      if (Number.isNaN(v)) return toast('That amount didn’t parse');
      repo.setAssigned(m, cid, v); native.haptic('tick'); return refresh();
    }
    if (d === 'quick') { repo.setAssigned(m, cid, +b.dataset.v); native.haptic('tick'); return refresh(); }
    if (d === 'move-out' || d === 'cover-from') {
      const other = await pickCategory({ month: m, allowIncome: true, exclude: cid, title: d === 'move-out' ? 'Move money to' : 'Take money from' });
      if (other === undefined || other === null) return;
      const row = repo.budget(m).months.get(m).cats.get(cid);
      const def = d === 'cover-from' && row.available < 0 ? -row.available : d === 'move-out' && row.available > 0 ? row.available : 0;
      const v = await promptDlg('Amount', { value: def ? (def / 100).toFixed(2) : '', inputmode: 'decimal' });
      const amt = evalAmount(v);
      if (v == null || Number.isNaN(amt) || amt <= 0) return;
      const inc = repo.incomeCategoryId();
      // moving to/from Ready to Assign = changing only this category's assigned
      if (d === 'move-out') repo.moveMoney(m, cid, other === inc ? null : other, amt);
      else repo.moveMoney(m, other === inc ? null : other, cid, amt);
      return refresh();
    }
    if (d === 'target') return editTarget(cid).then(refresh);
    if (d === 'tx') { const { screens } = await import('./app.js'); return screens.txedit.open({ id: +b.dataset.id }); }
    if (d === 'all-tx') { sheet?.close(); state.tx.filter = 'cat:' + cid; return go('tx'); }
    if (d === 'pin') {
      const p = meta('pinned_cats', []) || [];
      setMeta('pinned_cats', p.includes(cid) ? p.filter((x) => x !== cid) : [...p, cid].slice(-8));
      toast(p.includes(cid) ? 'Removed from home' : 'Pinned to home'); return refresh();
    }
    if (d === 'rename') { const n = await promptDlg('Rename category', { value: c.name }); if (n) { repo.saveCategory({ ...c, name: n.trim() }); refresh(); } return; }
    if (d === 'note') { const n = await promptDlg('Note', { value: c.note || '' }); if (n != null) { repo.saveCategory({ ...c, note: n }); refresh(); } return; }
    if (d === 'hide') { repo.saveCategory({ ...c, hidden: 1 }); sheet?.close(); state.selectedCat = null; return toast(`${c.name} hidden`, { action: 'Undo', onAction: () => repo.saveCategory({ ...c, hidden: 0 }) }); }
    if (d === 'delete') {
      const n = db.val('SELECT COUNT(*) FROM transactions WHERE category_id=?', [cid]) + db.val('SELECT COUNT(*) FROM splits WHERE category_id=?', [cid]);
      let to = null;
      if (n) { to = await pickCategory({ title: `Move ${n} transactions + budgeted money to`, exclude: cid, allowIncome: false }); if (to == null) return; }
      if (!(await confirmDlg(`Delete ${c.name}?`, { danger: true, ok: 'Delete' }))) return;
      repo.deleteCategory(cid, to); sheet?.close(); state.selectedCat = null; return;
    }
  };
  function refresh() {
    if (sheet) { sheet.setBody(detailHtml(cid)); bindDetail(sheet.el.querySelector('.sheet-b'), cid, sheet); }
  }
}

export function openCategory(cid) {
  const s = openSheet({ title: '', body: detailHtml(cid) });
  bindDetail(s.el.querySelector('.sheet-b'), cid, s);
  return s;
}

export function editTarget(cid) {
  const c = repo.category(cid);
  return new Promise((resolve) => {
    let type = c.target_type || 'monthly';
    const body = () => html`
      <div class="seg" style="margin-bottom:12px;flex-wrap:wrap">${[['monthly', 'Monthly'], ['refill', 'Refill'], ['bill', 'Bill'], ['by_date', 'By date'], ['balance', 'Goal']].map(([k, l]) => html`<button data-act="type" data-t="${k}" class="${type === k ? 'on' : ''}">${l}</button>`)}</div>
      <p class="small muted" style="margin-top:0">${{
        monthly: 'Set aside the same amount every month (e.g. groceries).',
        refill: 'Top the category back up to this amount each month (unused money counts).',
        bill: 'A bill of this amount due on a date and repeating. Weekly/fortnightly bills count how many fall in each month.',
        by_date: 'Have this much saved by a date, spread evenly over the months left.',
        balance: 'Save towards this total with no deadline.',
      }[type]}</p>
      <div class="field"><label>Amount</label><input class="input num" id="ta" inputmode="decimal" value="${c.target_amount ? (c.target_amount / 100).toFixed(2) : ''}"></div>
      ${type === 'by_date' || type === 'bill' ? html`<div class="field"><label>${type === 'bill' ? 'Next due date' : 'Target date'}</label><input class="input" id="td" type="date" value="${c.target_date || today()}"></div>` : ''}
      ${type === 'bill' ? html`<div class="field"><label>Repeats</label><select class="input" id="tf">${FREQS.map((f) => html`<option ${f === (c.target_freq || 'monthly') ? raw('selected') : ''}>${f}</option>`)}</select></div>` : ''}`;
    const s = openSheet({
      title: `Target · ${c.name}`, body: body(),
      footer: html`${c.target_type ? html`<button class="btn danger" data-act="clear">Remove</button>` : ''}<button class="btn primary grow" data-act="save">Save</button>`,
      onClose: () => resolve(),
      actions: {
        type: (b) => { type = b.dataset.t; s.setBody(body()); },
        clear: (b, e, api) => { repo.saveCategory({ ...c, target_type: null, target_amount: null, target_date: null, target_freq: null }); api.close(); },
        save: (b, e, api) => {
          const amt = evalAmount(s.el.querySelector('#ta').value);
          if (Number.isNaN(amt) || amt <= 0) return toast('Enter an amount');
          if ((type === 'bill' || type === 'by_date') && !s.el.querySelector('#td')?.value) return toast('Pick a date');
          repo.saveCategory({ ...c, target_type: type, target_amount: amt, target_date: s.el.querySelector('#td')?.value || null, target_freq: s.el.querySelector('#tf')?.value || null });
          api.close();
        },
      },
    });
  });
}

registerScreen('budget', {
  top: () => ({
    center: html`<div class="monthbar grow"><button class="iconbtn" data-top="prev" aria-label="Previous month">${icon('back')}</button><button class="m" data-top="month" style="border:0;background:none">${monthLabel(state.month)}</button><button class="iconbtn" data-top="next" aria-label="Next month">${icon('fwd')}</button></div>`,
    actions: [{ id: 'auto', icon: 'sparkle', label: 'Auto-assign' }],
  }),
  topAction(a) {
    if (a === 'prev') { state.month = addMonths(state.month, -1); queueRender(); }
    if (a === 'next') { state.month = addMonths(state.month, 1); queueRender(); }
    if (a === 'month') { state.month = thisMonth(); queueRender(); }
    if (a === 'auto') assignMenu();
  },
  render,
});
