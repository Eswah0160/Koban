// Insights — focused answers: How is this month going? Where does money go? Who gets it?
// What's changing? What repeats? What am I worth?
import * as repo from '../repo.js';
import { db } from '../db.js';
import { html, icon, openSheet, toast } from './dom.js';
import { state, go, registerScreen, queueRender, screens } from './app.js';
import { columns, line, lines } from './charts.js';
import { money, thisMonth, addMonths, monthLabel, today, dateLabel, addDays, daysInMonth, normPayee, prettyPayee, monthOf } from '../util.js';
import { ageOfMoney, incomeVsExpense, netWorthSeries, detectRecurring, cashForecast, isCashLike } from '../engine/analytics.js';

const TABS = [['overview', 'Overview'], ['categories', 'Categories'], ['payees', 'Payees'], ['trends', 'Trends'], ['recurring', 'Subscriptions'], ['networth', 'Net worth']];
let catRange = 1; // months
let payRange = 1;

/** Spending lines (positive = money out) for budget accounts, excluding income, card payments, internal transfers. */
function spendData() {
  const idx = repo.categoryIndex();
  const accts = new Map(repo.accounts(true).map((a) => [a.id, a]));
  const incomeIds = new Set(idx.categories.filter((c) => c.system === 'income').map((c) => c.id));
  const ccp = new Set(idx.categories.filter((c) => c.system === 'ccp').map((c) => c.id));
  const out = [];
  let income = [];
  for (const l of repo.lines()) {
    const a = accts.get(l.account_id);
    if (!a || !a.on_budget || l.is_opening) continue;
    if (l.transfer_account_id && accts.get(l.transfer_account_id)?.on_budget) continue;
    if (incomeIds.has(l.category_id)) { income.push({ date: l.date, month: monthOf(l.date), amount: l.amount }); continue; }
    if (ccp.has(l.category_id)) continue;
    out.push({ id: l.id, date: l.date, month: monthOf(l.date), cat: l.category_id ?? 0, amount: -l.amount, payee: l.payee || '' });
  }
  return { idx, spend: out, income };
}
const sumBy = (arr, f) => { const m = new Map(); for (const x of arr) { const k = f(x); m.set(k, (m.get(k) || 0) + x.amount); } return m; };
const inMonths = (arr, from, to) => arr.filter((x) => x.month >= from && x.month <= to);
function delta(cur, prev, { invert = false } = {}) {
  if (!prev) return html`<span class="muted">—</span>`;
  const p = Math.round(((cur - prev) / Math.abs(prev)) * 100);
  const good = invert ? p < 0 : p > 0;
  return html`<span class="${p === 0 ? 'muted' : good ? 'pos' : 'neg'}">${p > 0 ? '▲' : p < 0 ? '▼' : '='} ${Math.abs(p)}%</span>`;
}

function render(root) {
  const m = state.insightsMonth || thisMonth();
  const tab = TABS.some(([k]) => k === state.insightsTab) ? state.insightsTab : 'overview';
  root.innerHTML = String(html`<div class="page">
    <div class="row" style="margin-bottom:6px">
      <button class="iconbtn" data-m="-1" aria-label="Previous month">${icon('back')}</button>
      <div class="grow" style="text-align:center;font-family:var(--f-mono);letter-spacing:.14em;text-transform:uppercase;font-size:13px">${monthLabel(m)}</div>
      <button class="iconbtn" data-m="1" aria-label="Next month" ${m >= thisMonth() ? 'disabled' : ''}>${icon('fwd')}</button>
    </div>
    <div class="tabs">${TABS.map(([k, l]) => html`<button data-tab="${k}" class="${tab === k ? 'on' : ''}">${l}</button>`)}</div>
    <div id="tb"></div></div>`);
  const D = spendData();
  ({ overview, categories, payees, trends, recurring, networth })[tab](root.querySelector('#tb'), D, m);
  root.querySelectorAll('[data-tab]').forEach((b) => (b.onclick = () => { state.insightsTab = b.dataset.tab; queueRender(); }));
  root.querySelectorAll('[data-m]').forEach((b) => (b.onclick = () => { const n = addMonths(m, +b.dataset.m); if (n <= thisMonth()) { state.insightsMonth = n; queueRender(); } }));
}

// ---------- Overview: how is this month going? ----------
function overview(el, { idx, spend, income }, m) {
  const pm = addMonths(m, -1);
  const cur = inMonths(spend, m, m), prev = inMonths(spend, pm, pm);
  const spent = cur.reduce((s, x) => s + x.amount, 0), spentPrev = prev.reduce((s, x) => s + x.amount, 0);
  const inc = inMonths(income, m, m).reduce((s, x) => s + x.amount, 0), incPrev = inMonths(income, pm, pm).reduce((s, x) => s + x.amount, 0);
  const isCur = m === thisMonth();
  const dim = daysInMonth(m), day = isCur ? Number(today().slice(8, 10)) : dim;
  const saved = inc - spent, rate = inc > 0 ? Math.round((saved / inc) * 100) : null;
  const avg3 = [1, 2, 3].map((i) => inMonths(spend, addMonths(m, -i), addMonths(m, -i)).reduce((s, x) => s + x.amount, 0));
  const avg3v = Math.round(avg3.reduce((a, b) => a + b, 0) / 3);

  // cumulative daily spend: this month vs last month vs 3-month average
  const cum = (rows, days) => { const d = new Array(days).fill(0); for (const x of rows) d[Number(x.date.slice(8, 10)) - 1] += x.amount; let s = 0; return d.map((v) => (s += v)); };
  const curCum = cum(cur, dim).map((v, i) => (i < day ? v : null));
  const prevCum = cum(prev, daysInMonth(pm));
  const avgCum = Array.from({ length: dim }, (_, i) => Math.round([1, 2, 3].reduce((s, k) => { const mm = addMonths(m, -k); const c = cum(inMonths(spend, mm, mm), daysInMonth(mm)); return s + (c[Math.min(i, c.length - 1)] || 0); }, 0) / 3));
  const atDayPrev = prevCum[Math.min(day, prevCum.length) - 1] || 0;
  const diff = (curCum[day - 1] || 0) - atDayPrev;

  // movers vs last month by category
  const cc = sumBy(cur, (x) => x.cat), pc = sumBy(prev, (x) => x.cat);
  const keys = new Set([...cc.keys(), ...pc.keys()]);
  const movers = [...keys].map((k) => ({ k, d: (cc.get(k) || 0) - (pc.get(k) || 0) })).filter((x) => x.d !== 0).sort((a, b) => Math.abs(b.d) - Math.abs(a.d)).slice(0, 5);
  const big = [...cur].sort((a, b) => b.amount - a.amount).slice(0, 5);
  const B = repo.budget(m).months.get(m);
  const over = idx.categories.filter((c) => !c.system && (B?.cats.get(c.id)?.available ?? 0) < 0);

  el.innerHTML = String(html`<div class="dash">
    <section class="dcard span2">
      <div class="kv" style="grid-template-columns:repeat(4,minmax(0,1fr))">
        <div><span class="lbl">Income</span><b class="pos">${money(inc, { whole: true })}</b><span class="tiny">${delta(inc, incPrev)}</span></div>
        <div><span class="lbl">Spent</span><b>${money(spent, { whole: true })}</b><span class="tiny">${delta(spent, spentPrev, { invert: true })}</span></div>
        <div><span class="lbl">Saved</span><b class="${saved < 0 ? 'neg' : ''}">${money(saved, { whole: true })}</b><span class="tiny muted">${rate == null ? '—' : rate + '% of income'}</span></div>
        <div><span class="lbl">Per day</span><b>${money(Math.round(spent / Math.max(1, day)), { whole: true })}</b><span class="tiny muted">3-mo avg ${money(Math.round(avg3v / 30), { whole: true })}</span></div>
      </div>
    </section>
    <section class="dcard span2">
      <h2>Spending pace</h2>
      <p class="small" style="margin:0">${isCur ? html`Day ${day}: ${diff > 0 ? html`<b class="neg">${money(diff)} more</b>` : html`<b class="pos">${money(-diff)} less</b>`} than at the same point last month.` : html`${monthLabel(m)} total ${money(spent)} vs ${money(spentPrev)} the month before.`}</p>
      <div class="chart" id="pace"></div>
    </section>
    <section class="dcard">
      <h2>Biggest changes vs ${monthLabel(pm, { month: 'short' })}</h2>
      ${movers.length ? movers.map((x) => html`<button class="mini env" data-cat="${x.k}" style="display:flex"><span class="t">${idx.name(x.k)}<small>${money(cc.get(x.k) || 0)} vs ${money(pc.get(x.k) || 0)}</small></span><span class="amt ${x.d > 0 ? 'neg' : 'pos'}">${x.d > 0 ? '+' : '−'}${money(Math.abs(x.d))}</span></button>`) : html`<p class="muted small" style="margin:0">No spending to compare yet.</p>`}
    </section>
    <section class="dcard">
      <h2>Largest this month</h2>
      ${big.length ? big.map((x) => html`<button class="mini env" data-tx="${x.id}" style="display:flex"><span class="t">${x.payee || '—'}<small>${dateLabel(x.date)} · ${idx.name(x.cat)}</small></span><span class="amt">${money(x.amount)}</span></button>`) : html`<p class="muted small" style="margin:0">Nothing yet.</p>`}
    </section>
    <section class="dcard">
      <h2>Budget health</h2>
      ${over.length ? over.map((c) => html`<button class="mini env" data-cat="${c.id}" style="display:flex"><span class="t">${c.name}<small>overspent</small></span><span class="amt neg">${money(B.cats.get(c.id).available)}</span></button>`) : html`<div class="allclear">✓ No overspent envelopes</div>`}
      ${B?.underfunded ? html`<p class="small" style="margin:0">Targets still need <b>${money(B.underfunded)}</b> this month.</p>` : ''}
    </section>
    <section class="dcard">
      <h2>Cash, next 30 days<button class="more" data-tab2="networth">Net worth</button></h2>
      <div class="chart" id="fc"></div>
    </section>
  </div>`);
  const short = (d) => String(Number(d));
  lines(el.querySelector('#pace'), {
    labels: Array.from({ length: dim }, (_, i) => short(i + 1)), full: Array.from({ length: dim }, (_, i) => `Day ${i + 1}`),
    series: [
      { label: monthLabel(m, { month: 'short' }), color: 'var(--ink)', values: curCum },
      { label: monthLabel(pm, { month: 'short' }), color: 'var(--series-2)', values: Array.from({ length: dim }, (_, i) => prevCum[Math.min(i, prevCum.length - 1)]) },
      { label: '3-mo avg', color: 'var(--ink-3)', values: avgCum, dashed: true },
    ],
  });
  const accts = repo.accounts(true), bal = repo.accountBalances();
  const f = cashForecast({ startBalance: accts.filter((a) => isCashLike(a) && !a.closed).reduce((s, a) => s + (bal.get(a.id)?.today_balance || 0), 0), scheduled: repo.scheduledList(), accounts: accts, from: today(), days: 30 });
  line(el.querySelector('#fc'), { points: f.series.map((p) => ({ label: p.date.slice(8) + '/' + p.date.slice(5, 7), full: dateLabel(p.date), y: p.balance })), markLow: true, height: 150 });
  el.onclick = clicks;
}

// ---------- Categories: where does money go? ----------
function categories(el, { idx, spend }, m) {
  const from = addMonths(m, -(catRange - 1)), pFrom = addMonths(from, -catRange), pTo = addMonths(m, -catRange);
  const cur = sumBy(inMonths(spend, from, m), (x) => x.cat), prev = sumBy(inMonths(spend, pFrom, pTo), (x) => x.cat);
  const B = repo.budget(m);
  const planned = new Map();
  for (let mm = from; mm <= m; mm = addMonths(mm, 1)) for (const [cid, r] of B.months.get(mm)?.cats || []) planned.set(cid, (planned.get(cid) || 0) + Math.max(0, r.assigned));
  const rows = [...cur.entries()].filter(([, v]) => v > 0).sort((a, b) => b[1] - a[1]);
  const total = rows.reduce((s, [, v]) => s + v, 0);
  const max = Math.max(1, ...rows.map(([k, v]) => Math.max(v, planned.get(k) || 0)));
  const groups = new Map();
  for (const [cid, v] of rows) { const g = idx.byId.get(cid)?.group_id ?? 0; groups.set(g, (groups.get(g) || 0) + v); }
  el.innerHTML = String(html`
    <div class="chips">${[[1, 'Month'], [3, '3 months'], [6, '6 months'], [12, '12 months']].map(([n, l]) => html`<button class="chip ${catRange === n ? 'on' : ''}" data-range="${n}">${l}</button>`)}</div>
    <div class="dash">
    <section class="dcard span2">
      <h2>By category <span class="lbl" style="margin-left:auto">${money(total)}${catRange > 1 ? html` · ${money(Math.round(total / catRange))}/mo` : ''}</span></h2>
      <p class="tiny muted" style="margin:0">Bar = spent · line = budgeted · % = change vs previous ${catRange === 1 ? 'month' : catRange + ' months'}. Tap for detail.</p>
      ${rows.length ? rows.map(([cid, v]) => { const p = planned.get(cid) || 0; return html`<button class="env" data-cat="${cid}">
        <span class="ellipsis">${idx.name(cid)} <span class="tiny muted">${Math.round((v / total) * 100)}%</span></span>
        <span class="v">${money(v, { whole: v >= 10000 })} <span class="tiny">${delta(v, prev.get(cid) || 0, { invert: true })}</span></span>
        <span class="bar" style="position:relative;height:8px"><i class="${p && v > p ? 'bad' : ''}" style="width:${(v / max) * 100}%"></i>${p ? html`<u style="position:absolute;top:-2px;bottom:-2px;width:2px;background:var(--red);left:${(p / max) * 100}%"></u>` : ''}</span></button>`; })
        : html`<p class="muted small" style="margin:0">No spending in this period.</p>`}
    </section>
    <section class="dcard span2">
      <h2>By group</h2>
      <table class="tbl">${[...groups.entries()].sort((a, b) => b[1] - a[1]).map(([g, v]) => html`<tr><td>${idx.gById.get(g)?.name || 'Uncategorised'}</td><td class="n">${money(v)}</td><td class="n muted">${Math.round((v / (total || 1)) * 100)}%</td></tr>`)}</table>
    </section></div>`);
  el.onclick = (e) => { const r = e.target.closest('[data-range]'); if (r) { catRange = +r.dataset.range; return queueRender(); } clicks(e); };
}

// ---------- Payees: who gets the money? ----------
function payees(el, { idx, spend }, m) {
  const from = addMonths(m, -(payRange - 1));
  const list = inMonths(spend, from, m);
  const g = new Map();
  for (const x of list) { const k = normPayee(x.payee).split(' ').slice(0, 2).join(' ') || '—'; const e = g.get(k) || { name: x.payee, n: 0, total: 0, cats: new Map() }; e.n++; e.total += x.amount; e.cats.set(x.cat, (e.cats.get(x.cat) || 0) + 1); g.set(k, e); }
  const rows = [...g.values()].filter((e) => e.total > 0).sort((a, b) => b.total - a.total).slice(0, 40);
  const total = rows.reduce((s, e) => s + e.total, 0);
  el.innerHTML = String(html`
    <div class="chips">${[[1, 'Month'], [3, '3 months'], [12, '12 months']].map(([n, l]) => html`<button class="chip ${payRange === n ? 'on' : ''}" data-prange="${n}">${l}</button>`)}</div>
    <section class="dcard"><h2>Top payees <span class="lbl" style="margin-left:auto">${rows.length} places</span></h2>
    ${rows.length ? rows.map((e) => { const cat = [...e.cats.entries()].sort((a, b) => b[1] - a[1])[0][0]; return html`<button class="mini env" data-q="${e.name}" style="display:flex">
      <span class="t">${prettyPayee(e.name) || e.name}<small>${e.n}× · avg ${money(Math.round(e.total / e.n))} · ${idx.name(cat)}</small></span>
      <span class="right"><span class="amt">${money(e.total)}</span><small class="tiny muted" style="display:block">${Math.round((e.total / (total || 1)) * 100)}%</small></span></button>`; })
      : html`<p class="muted small" style="margin:0">No spending in this period.</p>`}</section>`);
  el.onclick = (e) => {
    const r = e.target.closest('[data-prange]'); if (r) { payRange = +r.dataset.prange; return queueRender(); }
    const q = e.target.closest('[data-q]'); if (q) { state.tx.filter = 'all'; state.tx.q = normPayee(q.dataset.q).split(' ')[0] || q.dataset.q; state.tx.accountId = null; return go('tx'); }
  };
}

// ---------- Trends ----------
function trends(el, { idx }, m) {
  const accts = repo.accounts(true);
  const incomeIds = new Set(idx.categories.filter((c) => c.system === 'income').map((c) => c.id));
  const ive = incomeVsExpense(repo.lines(), accts, incomeIds, m, 12);
  const aom = ageOfMoney(repo.allTxns(), accts);
  const withData = ive.filter((r) => r.income || r.spending);
  const avgIn = withData.length ? Math.round(withData.reduce((s, r) => s + r.income, 0) / withData.length) : 0;
  const avgOut = withData.length ? Math.round(withData.reduce((s, r) => s + r.spending, 0) / withData.length) : 0;
  el.innerHTML = String(html`<div class="dash">
    <section class="dcard span2"><h2>Income vs spending · 12 months</h2>
      <div class="kv"><div><span class="lbl">Avg income</span><b class="pos">${money(avgIn, { whole: true })}</b></div><div><span class="lbl">Avg spending</span><b>${money(avgOut, { whole: true })}</b></div><div><span class="lbl">Avg saved</span><b class="${avgIn - avgOut < 0 ? 'neg' : ''}">${money(avgIn - avgOut, { whole: true })}</b></div></div>
      <div class="chart" id="c1"></div>
      <details class="more"><summary>Table</summary><table class="tbl"><tr><th>Month</th><th class="n">In</th><th class="n">Out</th><th class="n">Saved</th><th class="n">Rate</th></tr>
      ${[...ive].reverse().map((r) => html`<tr><td>${monthLabel(r.month, { month: 'short', year: '2-digit' })}</td><td class="n">${money(r.income, { whole: true })}</td><td class="n">${money(r.spending, { whole: true })}</td><td class="n ${r.net < 0 ? 'neg' : 'pos'}">${money(r.net, { sign: true, whole: true })}</td><td class="n">${r.income > 0 ? Math.round((r.net / r.income) * 100) + '%' : '—'}</td></tr>`)}</table></details></section>
    <section class="dcard"><h2>Savings rate</h2><div class="chart" id="c2"></div></section>
    <section class="dcard"><h2>Age of money <span class="lbl" style="margin-left:auto">${aom.days != null ? aom.days + ' days' : '—'}</span></h2><div class="chart" id="c3"></div>
      <p class="tiny muted" style="margin:0">How long money sits before you spend it. Higher means more buffer.</p></section>
  </div>`);
  columns(el.querySelector('#c1'), {
    data: ive.map((r) => ({ label: monthLabel(r.month, { month: 'narrow' }), full: monthLabel(r.month), values: { income: r.income, spending: r.spending }, extra: `Saved ${money(r.net, { sign: true })}` })),
    series: [{ key: 'income', label: 'Income', color: 'var(--series-1)' }, { key: 'spending', label: 'Spending', color: 'var(--series-2)' }],
  });
  line(el.querySelector('#c2'), { points: ive.map((r) => ({ label: monthLabel(r.month, { month: 'short' }), full: monthLabel(r.month), y: r.income > 0 ? Math.round((r.net / r.income) * 10000) : 0 })), fmt: (v) => Math.round(v / 100) + '%', tick: (v) => Math.round(v / 100) + '%', height: 150 });
  line(el.querySelector('#c3'), { points: aom.history.map((h) => ({ label: h.date.slice(5), full: dateLabel(h.date), y: Math.round(h.days * 100) })), fmt: (v) => Math.round(v / 100) + ' days', tick: (v) => Math.round(v / 100) + 'd', height: 150 });
}

// ---------- Subscriptions ----------
function recurring(el, { idx }) {
  const tx = db.all(`SELECT id, date, amount, payee, raw_payee, category_id, transfer_account_id, is_opening, account_id FROM transactions WHERE date >= ? AND is_split=0`, [addDays(today(), -400)]);
  const found = detectRecurring(tx.map((t) => ({ ...t, payee: t.raw_payee || t.payee })), { asOf: today() });
  const sched = db.all('SELECT * FROM scheduled WHERE active=1');
  const tracked = (r) => sched.some((s) => normPayee(s.payee).split(' ')[0] === r.key.split(' ')[0]);
  const active = found.filter((r) => r.active), gone = found.filter((r) => !r.active);
  const monthly = active.reduce((s, r) => s + r.monthly, 0);
  const rises = active.filter((r) => r.priceChange > 0);
  const row = (r, i) => html`<li class="item"><div class="grow"><div class="title ellipsis">${r.payee}</div>
    <div class="sub">${r.freq} · ${r.count}× · ${r.active ? `next ~${dateLabel(r.next)}` : `last ${dateLabel(r.lastDate)}`}${r.priceChange > 0 ? html` · <b class="neg">up ${money(r.priceChange)}</b>` : ''} · ${idx.name(r.category_id)}</div></div>
    <div class="right"><div class="amt">${money(r.typical)}</div><div class="tiny muted">${money(r.yearly, { whole: true })}/yr</div></div>
    ${tracked(r) ? html`<span class="tiny muted" style="width:52px;text-align:center">tracked</span>` : html`<button class="btn sm" data-track="${i}">Track</button>`}</li>`;
  el.innerHTML = String(html`<div class="dash">
    <section class="dcard span2"><div class="kv"><div><span class="lbl">Per month</span><b>${money(monthly, { whole: true })}</b></div><div><span class="lbl">Per year</span><b>${money(monthly * 12, { whole: true })}</b></div><div><span class="lbl">Price rises</span><b class="${rises.length ? 'neg' : ''}">${rises.length}</b></div></div>
      <p class="tiny muted" style="margin:0">Found from payees that charge a similar amount on a regular schedule. Track one to put it in Recurring, so it shows in your upcoming bills and forecast.</p></section>
    <section class="dcard span2"><h2>Active</h2>${active.length ? html`<ul class="list">${active.map((r) => row(r, found.indexOf(r)))}</ul>` : html`<p class="muted small" style="margin:0">Nothing detected yet — needs a few months of history.</p>`}</section>
    ${gone.length ? html`<section class="dcard span2"><h2>Looks cancelled</h2><ul class="list">${gone.map((r) => row(r, found.indexOf(r)))}</ul></section>` : ''}
  </div>`);
  el.onclick = async (e) => {
    const b = e.target.closest('[data-track]'); if (!b) return;
    const r = found[+b.dataset.track];
    const t = db.get('SELECT * FROM transactions WHERE id=?', [r.txnIds[r.txnIds.length - 1]]);
    const { openRecurring } = await import('./recurring.js');
    openRecurring(null, { account_id: t.account_id, payee: r.payee, amount: -r.typical, category_id: r.category_id, freq: r.freq, next_date: r.next < today() ? today() : r.next, auto_enter: 1 });
  };
}

// ---------- Net worth ----------
function networth(el, D, m) {
  const accts = repo.accounts(true);
  const s = netWorthSeries(repo.allTxns(), accts, m, 24);
  const bal = repo.accountBalances();
  const last = s[s.length - 1], yearAgo = s[s.length - 13] || s[0];
  el.innerHTML = String(html`<div class="dash">
    <section class="dcard span2"><div class="kv"><div><span class="lbl">Net worth</span><b>${money(last.net, { whole: true })}</b></div><div><span class="lbl">Assets</span><b>${money(last.assets, { whole: true })}</b></div><div><span class="lbl">Debts</span><b class="${last.debts < 0 ? 'neg' : ''}">${money(-last.debts, { whole: true })}</b></div></div>
      <p class="small" style="margin:0">${money(last.net - yearAgo.net, { sign: true })} over 12 months.</p>
      <div class="chart" id="c1"></div></section>
    <section class="dcard span2"><h2>Accounts</h2><table class="tbl">${accts.filter((a) => !a.closed).map((a) => html`<tr data-acct="${a.id}"><td>${a.name} <span class="muted small">${repo.ACCOUNT_TYPES[a.type]?.label}</span></td><td class="n">${money(bal.get(a.id)?.balance || 0)}</td></tr>`)}</table></section>
  </div>`);
  lines(el.querySelector('#c1'), {
    labels: s.map((r) => monthLabel(r.month, { month: 'short' })), full: s.map((r) => monthLabel(r.month)),
    series: [{ label: 'Net worth', color: 'var(--ink)', values: s.map((r) => r.net) }, { label: 'Assets', color: 'var(--series-1)', values: s.map((r) => r.assets) }, { label: 'Debts', color: 'var(--series-2)', values: s.map((r) => r.debts), dashed: true }],
  });
  el.onclick = (e) => { const a = e.target.closest('[data-acct]'); if (a) go('account', a.dataset.acct); };
}

// ---------- shared clicks + category drill-down ----------
function clicks(e) {
  const t2 = e.target.closest('[data-tab2]'); if (t2) { state.insightsTab = t2.dataset.tab2; return queueRender(); }
  const c = e.target.closest('[data-cat]'); if (c) return categorySheet(+c.dataset.cat);
  const t = e.target.closest('[data-tx]'); if (t) return screens.txedit.open({ id: +t.dataset.tx });
}

function categorySheet(cid) {
  const { idx, spend } = spendData();
  const m = state.insightsMonth || thisMonth();
  const months = Array.from({ length: 12 }, (_, i) => addMonths(m, i - 11));
  const B = repo.budget(m);
  const series = months.map((mm) => ({ m: mm, spent: inMonths(spend, mm, mm).filter((x) => x.cat === cid).reduce((s, x) => s + x.amount, 0), plan: Math.max(0, B.months.get(mm)?.cats.get(cid)?.assigned || 0) }));
  const nz = series.filter((x) => x.spent);
  const avg = nz.length ? Math.round(nz.reduce((s, x) => s + x.spent, 0) / nz.length) : 0;
  const mine = spend.filter((x) => x.cat === cid && x.month >= months[0]);
  const pay = new Map(); for (const x of mine) { const k = prettyPayee(x.payee) || x.payee || '—'; pay.set(k, (pay.get(k) || 0) + x.amount); }
  const top = [...pay.entries()].sort((a, b) => b[1] - a[1]).slice(0, 6);
  const recent = [...mine].sort((a, b) => (a.date < b.date ? 1 : -1)).slice(0, 8);
  const s = openSheet({
    title: idx.name(cid),
    body: html`<div class="kv"><div><span class="lbl">${monthLabel(m, { month: 'short' })}</span><b>${money(series[11].spent, { whole: true })}</b></div><div><span class="lbl">Avg / month</span><b>${money(avg, { whole: true })}</b></div><div><span class="lbl">12 months</span><b>${money(series.reduce((t, x) => t + x.spent, 0), { whole: true })}</b></div></div>
      <div class="chart" id="cs" style="margin-top:10px"></div>
      <div class="lbl" style="margin-top:12px">Top payees · 12 months</div>
      ${top.length ? top.map(([n, v]) => html`<div class="mini"><span class="t">${n}</span><span class="amt">${money(v)}</span></div>`) : html`<p class="muted small">None.</p>`}
      <div class="lbl" style="margin-top:12px">Recent</div>
      ${recent.map((x) => html`<button class="mini env" data-tx="${x.id}" style="display:flex"><span class="t">${x.payee || '—'}<small>${dateLabel(x.date)}</small></span><span class="amt">${money(x.amount)}</span></button>`)}
      ${cid ? html`<button class="btn block" data-act="budget" style="margin-top:12px">Open in Budget</button>` : ''}`,
    actions: { budget: async (b, e, api) => { api.close(); const { openCategory } = await import('./budget.js'); openCategory(cid); } },
  });
  columns(s.el.querySelector('#cs'), {
    data: series.map((x) => ({ label: monthLabel(x.m, { month: 'narrow' }), full: monthLabel(x.m), values: { spent: x.spent, plan: x.plan } })),
    series: [{ key: 'spent', label: 'Spent', color: 'var(--ink)' }, { key: 'plan', label: 'Budgeted', color: 'var(--series-1)' }], height: 170,
  });
  s.el.addEventListener('click', (e) => { const t = e.target.closest('[data-tx]'); if (t) screens.txedit.open({ id: +t.dataset.tx }); });
}

registerScreen('insights', { top: () => ({ title: 'Insights', back: true }), render });
