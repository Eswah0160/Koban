// Tiny view helpers: auto-escaping html`` templates, sheets, menus, toasts.
import { esc } from '../util.js';

export class Raw { constructor(s) { this.s = s; } toString() { return this.s; } }
export const raw = (s) => new Raw(s);
const fmtVal = (v) => (v instanceof Raw ? v.s : Array.isArray(v) ? v.map(fmtVal).join('') : v == null || v === false ? '' : esc(String(v)));
/** Tagged template: interpolations are HTML-escaped unless wrapped in raw()/html``. */
export function html(strings, ...vals) {
  let out = '';
  strings.forEach((s, i) => { out += s; if (i < vals.length) out += fmtVal(vals[i]); });
  return new Raw(out);
}
export const $ = (sel, root = document) => root.querySelector(sel);
export const $$ = (sel, root = document) => [...root.querySelectorAll(sel)];

const P = {
  budget: '<path d="M3 7h18v12H3z"/><path d="M3 7l3-3h12l3 3"/><path d="M16 13h2"/>',
  list: '<path d="M8 6h13M8 12h13M8 18h13"/><circle cx="4" cy="6" r="1"/><circle cx="4" cy="12" r="1"/><circle cx="4" cy="18" r="1"/>',
  plus: '<path d="M12 5v14M5 12h14"/>',
  bank: '<path d="M3 10l9-6 9 6"/><path d="M5 10v8M9 10v8M15 10v8M19 10v8M3 20h18"/>',
  chart: '<path d="M4 20V10M10 20V4M16 20v-7M22 20H2"/>',
  gear: '<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1.1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.5-1.1 1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.8.3H9a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.8V9a1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1z"/>',
  search: '<circle cx="11" cy="11" r="7"/><path d="M21 21l-4.3-4.3"/>',
  back: '<path d="M15 18l-6-6 6-6"/>',
  fwd: '<path d="M9 18l6-6-6-6"/>',
  close: '<path d="M18 6L6 18M6 6l12 12"/>',
  check: '<path d="M20 6L9 17l-5-5"/>',
  more: '<circle cx="12" cy="5" r="1"/><circle cx="12" cy="12" r="1"/><circle cx="12" cy="19" r="1"/>',
  camera: '<path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z"/><circle cx="12" cy="13" r="4"/>',
  upload: '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4M17 8l-5-5-5 5M12 3v12"/>',
  repeat: '<path d="M17 1l4 4-4 4"/><path d="M3 11V9a4 4 0 0 1 4-4h14M7 23l-4-4 4-4"/><path d="M21 13v2a4 4 0 0 1-4 4H3"/>',
  inbox: '<path d="M22 12h-6l-2 3h-4l-2-3H2"/><path d="M5.5 5h13L22 12v7a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2v-7z"/>',
  trash: '<path d="M3 6h18M8 6V4h8v2M19 6l-1 14H6L5 6"/>',
  edit: '<path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4z"/>',
  flag: '<path d="M4 15s1-1 4-1 5 2 8 2 4-1 4-1V3s-1 1-4 1-5-2-8-2-4 1-4 1zM4 22v-7"/>',
  sparkle: '<path d="M12 3l1.9 5.1L19 10l-5.1 1.9L12 17l-1.9-5.1L5 10l5.1-1.9z"/><path d="M19 17l.8 2.2L22 20l-2.2.8L19 23l-.8-2.2L16 20l2.2-.8z"/>',
  lock: '<rect x="4" y="11" width="16" height="10" rx="2"/><path d="M8 11V7a4 4 0 0 1 8 0v4"/>',
  split: '<path d="M16 3h5v5M8 3H3v5M21 3l-7 7M3 3l7 7M12 12v9"/>',
  swap: '<path d="M7 16V4M3 8l4-4 4 4M17 8v12M21 16l-4 4-4-4"/>',
  receipt: '<path d="M4 2v20l3-2 3 2 2-2 2 2 3-2 3 2V2l-3 2-3-2-2 2-2-2-3 2z"/><path d="M8 8h8M8 12h8M8 16h5"/>',
  filter: '<path d="M22 3H2l8 9.5V19l4 2v-8.5z"/>',
  bell: '<path d="M18 8a6 6 0 0 0-12 0c0 7-3 9-3 9h18s-3-2-3-9M13.7 21a2 2 0 0 1-3.4 0"/>',
  link: '<path d="M10 13a5 5 0 0 0 7.5.5l3-3a5 5 0 0 0-7-7l-1.7 1.7"/><path d="M14 11a5 5 0 0 0-7.5-.5l-3 3a5 5 0 0 0 7 7l1.7-1.7"/>',
  download: '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4M7 10l5 5 5-5M12 15V3"/>',
  target: '<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1"/>',
  home: '<path d="M3 11l9-7 9 7"/><path d="M5 10v10h14V10"/><path d="M10 20v-6h4v6"/>',
  grid: '<rect x="4" y="4" width="6" height="6" rx="1"/><rect x="14" y="4" width="6" height="6" rx="1"/><rect x="4" y="14" width="6" height="6" rx="1"/><rect x="14" y="14" width="6" height="6" rx="1"/>',
  move: '<path d="M5 12h14M13 6l6 6-6 6"/>',
};
export const icon = (name) => raw(`<svg viewBox="0 0 24 24" aria-hidden="true">${P[name] || ''}</svg>`);

// ---------- sheets ----------
const stack = [];
export function openSheet({ title = '', body = '', footer = '', onClose = null, className = '', actions = {} } = {}) {
  const scrim = document.createElement('div');
  scrim.className = 'scrim';
  const el = document.createElement('div');
  el.className = 'sheet ' + className;
  el.setAttribute('role', 'dialog');
  el.innerHTML = String(html`<div class="grab"></div>
    <div class="sheet-h"><h2>${title}</h2><button class="iconbtn" data-act="close" aria-label="Close">${icon('close')}</button></div>
    <div class="sheet-b">${body}</div>${footer ? html`<div class="sheet-f">${footer}</div>` : ''}`);
  document.body.append(scrim, el);
  const api = {
    el, closed: false,
    close(result) {
      if (api.closed) return; api.closed = true;
      scrim.remove(); el.remove();
      const i = stack.indexOf(api); if (i >= 0) stack.splice(i, 1);
      onClose && onClose(result);
    },
    setBody(b) { el.querySelector('.sheet-b').innerHTML = String(b); },
    setFooter(f) { const ft = el.querySelector('.sheet-f'); if (ft) ft.innerHTML = String(f); },
    setTitle(t) { el.querySelector('.sheet-h h2').textContent = t; },
  };
  scrim.addEventListener('click', () => api.close());
  el.addEventListener('click', (e) => {
    const b = e.target.closest('[data-act]');
    if (!b || !el.contains(b)) return;
    const act = b.dataset.act;
    if (act === 'close') return api.close();
    if (actions[act]) actions[act](b, e, api);
  });
  stack.push(api);
  return api;
}
export function closeTopSheet() { const s = stack[stack.length - 1]; if (s) { s.close(); return true; } return false; }
export const sheetOpen = () => stack.length > 0;

export function menu(title, items) {
  return new Promise((resolve) => {
    const s = openSheet({
      title, className: 'menu',
      body: html`${items.filter(Boolean).map((it, i) => html`<button class="mi ${it.danger ? 'danger' : ''}" data-act="pick" data-i="${i}" ${it.disabled ? raw('disabled') : ''}>
        ${it.icon ? icon(it.icon) : ''}<span class="grow"><div>${it.label}</div>${it.sub ? html`<div class="sub">${it.sub}</div>` : ''}</span>${it.right || ''}</button>`)}`,
      onClose: (r) => resolve(r ?? null),
      actions: { pick: (b, e, api) => { const it = items.filter(Boolean)[+b.dataset.i]; api.close(it.value ?? it.label); it.onClick && it.onClick(); } },
    });
  });
}

export function confirmDlg(message, { ok = 'OK', danger = false, title = 'Are you sure?' } = {}) {
  return new Promise((resolve) => {
    openSheet({
      title, body: html`<p class="ink2" style="margin:4px 0 8px">${message}</p>`,
      footer: html`<button class="btn grow" data-act="close">Cancel</button><button class="btn grow ${danger ? 'danger' : 'primary'}" data-act="ok">${ok}</button>`,
      onClose: (r) => resolve(!!r), actions: { ok: (b, e, api) => api.close(true) },
    });
  });
}

export function promptDlg(title, { value = '', placeholder = '', type = 'text', inputmode = '', ok = 'Save', hint = '' } = {}) {
  return new Promise((resolve) => {
    const s = openSheet({
      title,
      body: html`<input class="input" id="pd" type="${type}" ${inputmode ? raw(`inputmode="${inputmode}"`) : ''} value="${value}" placeholder="${placeholder}" autocomplete="off">${hint ? html`<p class="small muted">${hint}</p>` : ''}`,
      footer: html`<button class="btn grow" data-act="close">Cancel</button><button class="btn primary grow" data-act="ok">${ok}</button>`,
      onClose: (r) => resolve(r ?? null),
      actions: { ok: (b, e, api) => api.close(s.el.querySelector('#pd').value) },
    });
    const inp = s.el.querySelector('#pd');
    setTimeout(() => { inp.focus(); inp.select?.(); }, 60);
    inp.addEventListener('keydown', (e) => { if (e.key === 'Enter') s.close(inp.value); });
  });
}

let toastEl = null, toastT = null;
export function toast(msg, { action = null, onAction = null, ms = 3200 } = {}) {
  toastEl?.remove(); clearTimeout(toastT);
  toastEl = document.createElement('div');
  toastEl.className = 'toast';
  if (stack.length) toastEl.style.cssText = 'top:16px;bottom:auto';
  toastEl.innerHTML = String(html`<span>${msg}</span>${action ? html`<button>${action}</button>` : ''}`);
  if (action) toastEl.querySelector('button').onclick = () => { toastEl?.remove(); onAction && onAction(); };
  document.body.append(toastEl);
  toastT = setTimeout(() => toastEl?.remove(), ms);
}

/** Evaluate a simple arithmetic money expression: "12.50+3*2" -> cents. (No eval: CSP-safe.) */
export function evalAmount(input) {
  const src = String(input || '').replace(/[$,\s]/g, '').replace(/[×x]/g, '*').replace(/÷/g, '/').replace(/−/g, '-');
  if (!src || !/^[-+*/().\d]+$/.test(src)) return NaN;
  let i = 0;
  const peek = () => src[i];
  function num() {
    if (peek() === '(') { i++; const v = expr(); if (src[i++] !== ')') throw 0; return v; }
    if (peek() === '-') { i++; return -num(); }
    if (peek() === '+') { i++; return num(); }
    const m = /^(\d+\.?\d*|\.\d+)/.exec(src.slice(i));
    if (!m) throw 0;
    i += m[0].length;
    return parseFloat(m[0]);
  }
  function term() { let v = num(); while (peek() === '*' || peek() === '/') { const op = src[i++]; const r = num(); v = op === '*' ? v * r : v / r; } return v; }
  function expr() { let v = term(); while (peek() === '+' || peek() === '-') { const op = src[i++]; const r = term(); v = op === '+' ? v + r : v - r; } return v; }
  try { const v = expr(); if (i !== src.length || !Number.isFinite(v)) return NaN; return Math.round(v * 100); } catch { return NaN; }
}
