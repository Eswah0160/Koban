// First-run setup.
import * as repo from '../repo.js';
import { html, icon, toast, confirmDlg } from './dom.js';
import { addAccount } from './accounts.js';
import { pickFile } from './importer.js';
import { restoreAll } from '../io/backup.js';
import { money } from '../util.js';

export function onboarding(root, done) {
  let step = repo.isSetUp() ? 'accounts' : 'welcome';
  let template = true;
  const draw = () => {
    if (step === 'welcome') {
      root.innerHTML = String(html`<div class="page" style="padding-top:40px;max-width:520px">
        <div style="font-size:44px">小判</div><h1 style="margin:6px 0 4px">Koban</h1>
        <p class="ink2">A zero-based budget: every dollar you have gets a job. Your data stays on this phone.</p>
        <ul class="list card" style="margin:18px 0">
          <li class="item">${icon('bell')}<div class="grow"><div class="title">Catches purchases</div><div class="sub">From bank / wallet notifications you choose</div></div></li>
          <li class="item">${icon('upload')}<div class="grow"><div class="title">Imports statements</div><div class="sub">CommBank, NAB, Westpac, ANZ CSV + OFX, de-duplicated</div></div></li>
          <li class="item">${icon('camera')}<div class="grow"><div class="title">Reads receipts</div><div class="sub">Splits line items into categories</div></div></li>
        </ul>
        <button class="btn primary block" data-act="next">Set up my budget</button>
        <button class="btn ghost block" data-act="restore" style="margin-top:6px">Restore from a backup file</button></div>`);
    } else if (step === 'cats') {
      root.innerHTML = String(html`<div class="page" style="padding-top:28px;max-width:520px"><h2>Categories</h2>
        <p class="ink2">Start with a sensible set you can rename, hide or extend any time.</p>
        <div class="card">${repo.TEMPLATE.map(([g, cs]) => html`<div class="grp-h" style="grid-template-columns:1fr"><span>${g}</span></div><div class="card-b small ink2" style="padding-top:8px">${cs.join(' · ')}</div>`)}</div>
        <label class="row" style="margin:10px 0 16px"><input type="checkbox" id="tpl" checked> Use these starter categories</label>
        <button class="btn primary block" data-act="seed">Continue</button></div>`);
    } else if (step === 'accounts') {
      const accts = repo.accounts();
      const bal = repo.accountBalances();
      root.innerHTML = String(html`<div class="page" style="padding-top:28px;max-width:520px"><h2>Your accounts</h2>
        <p class="ink2">Add the accounts you spend from (everyday, savings, credit cards) with today’s balance. Add super or shares as tracking accounts if you like.</p>
        <div class="card">${accts.length ? html`<ul class="list">${accts.map((a) => html`<li class="item"><div class="grow"><div class="title">${a.name}</div><div class="sub">${repo.ACCOUNT_TYPES[a.type]?.label}</div></div><div class="amt">${money(bal.get(a.id)?.balance || 0)}</div></li>`)}</ul>` : html`<p class="card-b muted small" style="padding-top:12px">None yet.</p>`}</div>
        <button class="btn block" data-act="add">+ Add account</button>
        <button class="btn primary block" data-act="finish" style="margin-top:10px" ${accts.length ? '' : 'disabled'}>Start budgeting</button></div>`);
    }
  };
  root.onclick = async (e) => {
    const a = e.target.closest('[data-act]')?.dataset.act;
    if (a === 'next') { step = 'cats'; draw(); }
    if (a === 'seed') { template = root.querySelector('#tpl').checked; repo.seed({ template }); step = 'accounts'; draw(); }
    if (a === 'add') addAccount({ onDone: () => draw() });
    if (a === 'finish') { root.onclick = null; done(); }
    if (a === 'restore') {
      const f = await pickFile('application/json,.json');
      if (!f) return;
      try { const d = JSON.parse(await f.text()); if (await confirmDlg(`Restore backup from ${d.exported_at?.slice(0, 10)}?`, { ok: 'Restore' })) { restoreAll(d); root.onclick = null; done(); } }
      catch (err) { toast(err.message); }
    }
  };
  draw();
}
