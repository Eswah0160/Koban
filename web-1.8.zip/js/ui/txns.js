// Transactions list (incl. review inbox, bulk actions).
import * as repo from '../repo.js';
import { db } from '../db.js';
import { html, icon, menu, toast, confirmDlg } from './dom.js';
import { state, registerScreen, screens, queueRender } from './app.js';
import { pickCategory, pickAccount } from './pickers.js';
import { money, dateLabel, debounce } from '../util.js';
import { aiConfig, geminiCategorise } from '../io/ai.js';
import * as native from '../native.js';

let limit = 200;

function filters() {
  const f = state.tx.filter;
  const o = { q: state.tx.q, accountId: state.tx.accountId, limit };
  if (f === 'review') o.unapproved = true;
  if (f === 'uncat') o.uncategorised = true;
  if (f === 'flagged') o.flagged = true;
  if (f.startsWith('cat:')) o.categoryId = +f.slice(4);
  return o;
}

function rowHtml(t, splits, idx, sel) {
  const isTransfer = !!t.transfer_account_id;
  const other = isTransfer ? repo.account(t.transfer_account_id) : null;
  let cat;
  if (t.is_split) cat = html`Split · ${(splits.get(t.id) || []).map((s) => idx.name(s.category_id)).join(', ')}`;
  else if (isTransfer && other?.on_budget && repo.account(t.account_id)?.on_budget) cat = html`${t.amount < 0 ? '→' : '←'} ${other?.name}`;
  else if (t.category_id == null && !t.is_opening) cat = html`<span class="uncat">Needs category</span>`;
  else cat = t.is_opening && t.category_id == null ? 'Starting balance' : idx.name(t.category_id);
  const initial = (t.payee || '?').replace(/^Transfer: /, '').trim().charAt(0).toUpperCase();
  return html`<div class="tx ${t.approved ? '' : 'unapproved'} ${sel ? 'selected' : ''}" data-tx="${t.id}">
    <div class="ic">${state.tx.selecting ? (sel ? '✓' : '') : initial}</div>
    <div class="main"><div class="p">${t.flag ? html`<span class="flag ${t.flag}"></span>` : ''}${t.payee || '—'}</div>
      <div class="c">${cat}${state.tx.accountId ? '' : html` · ${t.account_name}`}${t.memo ? html` · ${t.memo}` : ''}</div></div>
    <div class="r"><div class="amt ${t.amount > 0 ? 'in' : ''}">${money(t.amount, { sign: t.amount > 0 })}</div>
      <div class="cl">${t.source === 'notification' ? '🔔 ' : t.source === 'receipt' || t.receipt_id ? '🧾 ' : ''}${t.cleared === 'reconciled' ? '🔒' : t.cleared === 'cleared' ? 'Cleared' : 'Pending'}</div></div>
    ${!t.approved && !state.tx.selecting ? html`<button class="approve" data-approve="${t.id}" aria-label="Approve">✓</button>` : ''}
  </div>`;
}

function render(root, st, counts) {
  const rows = repo.listTxns(filters());
  const idx = repo.categoryIndex();
  const splits = repo.splitsFor(rows.filter((r) => r.is_split).map((r) => r.id));
  const f = state.tx.filter;
  const acct = state.tx.accountId ? repo.account(state.tx.accountId) : null;
  const byDay = [];
  let cur = null;
  for (const r of rows) {
    if (!cur || cur.date !== r.date) { cur = { date: r.date, rows: [], total: 0 }; byDay.push(cur); }
    cur.rows.push(r);
    if (!r.transfer_account_id) cur.total += r.amount;
  }
  const unapproved = f === 'review' ? rows.length : 0;
  const catChip = f.startsWith('cat:') ? html`<button class="chip on" data-f="all">${idx.name(+f.slice(4))} ✕</button>` : '';
  const totalIn = rows.filter((r) => r.amount > 0 && !r.transfer_account_id).reduce((t, r) => t + r.amount, 0);
  const totalOut = rows.filter((r) => r.amount < 0 && !r.transfer_account_id).reduce((t, r) => t - r.amount, 0);
  root.innerHTML = String(html`<div class="page"><div class="txgrid"><aside class="txside">
    <div class="search">${icon('search')}<input id="q" placeholder="Search payee, memo, category or amount" value="${state.tx.q}" autocomplete="off" enterkeyhint="search"></div>
    <div class="chips">
      ${catChip}
      <button class="chip ${f === 'all' ? 'on' : ''}" data-f="all">All</button>
      <button class="chip ${f === 'review' ? 'on' : counts.inbox ? 'acc' : ''}" data-f="review">Review ${counts.inbox || ''}</button>
      <button class="chip ${f === 'uncat' ? 'on' : counts.uncategorised ? 'warn' : ''}" data-f="uncat">Uncategorised ${counts.uncategorised || ''}</button>
      <button class="chip ${f === 'flagged' ? 'on' : ''}" data-f="flagged">Flagged</button>
      <button class="chip ${acct ? 'on' : ''}" data-act="acct">${acct ? acct.name + ' ✕' : 'Account ▾'}</button>
    </div>
    <div class="txsum"><div><span class="lbl">Shown</span><b class="num">${rows.length}</b></div><div><span class="lbl">In</span><b class="num pos">${money(totalIn, { whole: true })}</b></div><div><span class="lbl">Out</span><b class="num">${money(totalOut, { whole: true })}</b></div></div>
    </aside><div class="txmain">
    ${f === 'review' && rows.length ? html`<div class="row" style="margin-bottom:8px"><button class="btn sm primary grow" data-act="approve-all">Approve ${rows.filter((r) => r.category_id != null || r.is_split || r.transfer_account_id).length} with categories</button>
      ${aiConfig().enabled ? html`<button class="btn sm" data-act="ai">${icon('sparkle')} AI categorise</button>` : ''}</div>` : ''}
    ${f === 'uncat' && rows.length && aiConfig().enabled ? html`<button class="btn sm block" data-act="ai" style="margin-bottom:8px">${icon('sparkle')} AI categorise ${rows.length}</button>` : ''}
    ${byDay.length ? byDay.map((d) => html`<div class="dayh"><span>${dateLabel(d.date)}</span><span class="num">${d.total ? money(d.total) : ''}</span></div>
      <div class="card" style="margin-bottom:4px">${d.rows.map((r) => rowHtml(r, splits, idx, state.tx.selected.has(r.id)))}</div>`)
      : html`<div class="empty">${icon('inbox')}<h3>${f === 'review' ? 'All caught up' : 'No transactions'}</h3><p>${f === 'review' ? 'New notifications and imports land here for a quick check.' : 'Tap + to add one, or import a statement from Accounts.'}</p></div>`}
    ${rows.length >= limit ? html`<button class="btn block" data-act="more">Load more</button>` : ''}
  </div></div></div>
  ${state.tx.selecting ? html`<div class="bulkbar"><b style="padding:0 6px">${state.tx.selected.size}</b>
    <button class="btn" data-bulk="cat">Category</button><button class="btn" data-bulk="approve">Approve</button><button class="btn" data-bulk="flag">${icon('flag')}</button><button class="btn" data-bulk="delete">${icon('trash')}</button>
    <span class="grow"></span><button class="btn" data-bulk="done">${icon('close')}</button></div>` : ''}`);

  const q = root.querySelector('#q');
  q.oninput = debounce(() => { state.tx.q = q.value; limit = 200; const pos = q.selectionStart; queueRender(); requestAnimationFrame(() => { const n = document.getElementById('q'); if (n) { n.focus(); n.setSelectionRange(pos, pos); } }); }, 250);
  root.onclick = onClick;
  bindLongPress(root);
}

async function onClick(e) {
  const t = e.target;
  const fb = t.closest('[data-f]');
  if (fb) { state.tx.filter = fb.dataset.f; limit = 200; return queueRender(); }
  const act = t.closest('[data-act]')?.dataset.act;
  if (act === 'acct') {
    if (state.tx.accountId) { state.tx.accountId = null; return queueRender(); }
    const id = await pickAccount({}); if (id) { state.tx.accountId = id; queueRender(); } return;
  }
  if (act === 'more') { limit += 300; return queueRender(); }
  if (act === 'approve-all') {
    const ids = repo.listTxns({ unapproved: true, limit: 5000 }).filter((r) => r.category_id != null || r.is_split || r.transfer_account_id).map((r) => r.id);
    repo.approve(ids); native.haptic('confirm'); return toast(`Approved ${ids.length}`, { action: 'Undo', onAction: () => db.tx(() => ids.forEach((id) => db.update('transactions', id, { approved: 0 }))) });
  }
  if (act === 'ai') return aiCategorise();
  const ap = t.closest('[data-approve]');
  if (ap) {
    const id = +ap.dataset.approve;
    const tx = repo.txn(id);
    if (tx.category_id == null && !tx.is_split && !tx.transfer_account_id) return screens.txedit.open({ id });
    repo.approve([id]); native.haptic('tick'); return;
  }
  const bulk = t.closest('[data-bulk]')?.dataset.bulk;
  if (bulk) return bulkAction(bulk);
  const row = t.closest('[data-tx]');
  if (row) {
    const id = +row.dataset.tx;
    if (state.tx.selecting) { state.tx.selected.has(id) ? state.tx.selected.delete(id) : state.tx.selected.add(id); if (!state.tx.selected.size) state.tx.selecting = false; return queueRender(); }
    return screens.txedit.open({ id });
  }
}

function bindLongPress(root) {
  let timer = null, startY = 0;
  root.onpointerdown = (e) => {
    const row = e.target.closest('[data-tx]');
    if (!row || e.target.closest('[data-approve]')) return;
    startY = e.clientY;
    timer = setTimeout(() => {
      native.haptic('confirm');
      state.tx.selecting = true; state.tx.selected.add(+row.dataset.tx);
      queueRender();
      const block = (ev) => { ev.stopPropagation(); ev.preventDefault(); root.removeEventListener('click', block, true); };
      root.addEventListener('click', block, true);
    }, 450);
  };
  const cancel = () => clearTimeout(timer);
  root.onpointerup = cancel; root.onpointercancel = cancel;
  root.onpointermove = (e) => { if (Math.abs(e.clientY - startY) > 8) cancel(); };
}

async function bulkAction(a) {
  const ids = [...state.tx.selected];
  const done = () => { state.tx.selecting = false; state.tx.selected.clear(); queueRender(); };
  if (a === 'done') return done();
  if (a === 'approve') { repo.approve(ids); return done(); }
  if (a === 'cat') {
    const c = await pickCategory({ allowNone: true }); if (c === undefined) return;
    db.tx(() => ids.forEach((id) => { const t = repo.txn(id); if (!t.is_split && !(t.transfer_account_id && repo.account(t.transfer_account_id)?.on_budget)) db.update('transactions', id, { category_id: c, approved: 1 }); }));
    return done();
  }
  if (a === 'flag') {
    const f = await menu('Flag', ['red', 'orange', 'yellow', 'green', 'blue', 'purple', 'none'].map((c) => ({ value: c, label: c === 'none' ? 'Clear flag' : c[0].toUpperCase() + c.slice(1), right: c === 'none' ? '' : html`<span class="flag ${c}"></span>` })));
    if (!f) return;
    db.tx(() => ids.forEach((id) => db.update('transactions', id, { flag: f === 'none' ? null : f })));
    return done();
  }
  if (a === 'delete') {
    if (!(await confirmDlg(`Delete ${ids.length} transaction${ids.length === 1 ? '' : 's'}?`, { danger: true, ok: 'Delete' }))) return;
    ids.forEach((id) => repo.deleteTxn(id));
    return done();
  }
}

async function aiCategorise() {
  const rows = repo.listTxns({ uncategorised: true, limit: 60 });
  if (!rows.length) return toast('Nothing uncategorised');
  const idx = repo.categoryIndex();
  const names = idx.categories.filter((c) => !c.hidden && c.system !== 'ccp').map((c) => c.name);
  toast(`Asking Gemini about ${rows.length}…`, { ms: 10000 });
  try {
    const res = await geminiCategorise(rows.map((r) => ({ id: r.id, payee: r.payee, raw: r.raw_payee, amount: r.amount })), names);
    let n = 0;
    db.tx(() => {
      for (const r of rows) {
        const g = res.get(r.id);
        const cat = g?.category && idx.categories.find((c) => c.name === g.category);
        if (cat) { db.update('transactions', r.id, { category_id: cat.id }); n++; }
      }
    });
    toast(`Categorised ${n} of ${rows.length} — check them in Review`);
  } catch (e) { toast(e.message, { ms: 6000 }); }
}

registerScreen('tx', {
  top: () => ({ title: 'Transactions', actions: [{ id: 'receipt', icon: 'camera', label: 'Scan receipt' }, { id: 'import', icon: 'upload', label: 'Import statement' }] }),
  topAction(a) { if (a === 'receipt') screens.receipt.start(); if (a === 'import') screens.importer.start(state.tx.accountId); },
  render,
});
