// Recurring bills & income: one clear list + one simple form.
import * as repo from '../repo.js';
import { db } from '../db.js';
import { html, raw, icon, openSheet, toast, confirmDlg, evalAmount } from './dom.js';
import { registerScreen, screens } from './app.js';
import { pickCategory } from './pickers.js';
import { money, today, addDays, dateLabel, daysBetween, nextOccurrence, FREQ_PER_YEAR, thisMonth, monthOf } from '../util.js';

const FREQ_LABEL = { weekly: 'Weekly', fortnightly: 'Fortnightly', monthly: 'Monthly', quarterly: 'Quarterly', 'half-yearly': 'Every 6 months', yearly: 'Yearly' };
const perMonth = (s) => Math.round((s.amount * (FREQ_PER_YEAR[s.freq] || 12)) / 12);
function when(d) {
  const n = daysBetween(today(), d);
  if (n < 0) return `${-n} day${n === -1 ? '' : 's'} overdue`;
  if (n === 0) return 'today';
  if (n === 1) return 'tomorrow';
  if (n < 7) return `in ${n} days`;
  return dateLabel(d);
}

function render(root) {
  const all = db.all('SELECT * FROM scheduled ORDER BY active DESC, next_date');
  const idx = repo.categoryIndex();
  const active = all.filter((s) => s.active);
  const bills = active.filter((s) => s.amount < 0 && !s.transfer_account_id).reduce((t, s) => t + perMonth(s), 0);
  const income = active.filter((s) => s.amount > 0 && !s.transfer_account_id).reduce((t, s) => t + perMonth(s), 0);
  const t = today(), wk = addDays(t, 7), mEnd = thisMonth();
  const sections = [
    ['Overdue', active.filter((s) => s.next_date < t)],
    ['Next 7 days', active.filter((s) => s.next_date >= t && s.next_date <= wk)],
    ['Later this month', active.filter((s) => s.next_date > wk && monthOf(s.next_date) === mEnd)],
    ['Later', active.filter((s) => s.next_date > wk && monthOf(s.next_date) > mEnd)],
    ['Paused', all.filter((s) => !s.active)],
  ].filter(([, l]) => l.length);
  const row = (s) => html`<li class="item tap" data-sched="${s.id}" style="${s.active ? '' : 'opacity:.55'}">
    <div class="grow"><div class="title ellipsis">${s.payee || 'Transfer'}</div>
      <div class="sub">${FREQ_LABEL[s.freq] || s.freq} · ${s.active ? when(s.next_date) : 'paused'} · ${s.transfer_account_id ? 'Transfer' : idx.name(s.category_id)}${s.auto_enter ? ' · auto' : ''}</div></div>
    <div class="right"><div class="amt ${s.amount > 0 ? 'in' : ''}">${money(s.amount)}</div><div class="tiny muted">${money(perMonth(s), { whole: true })}/mo</div></div>
    ${s.active && s.next_date <= t && !s.auto_enter ? html`<button class="btn sm" data-pay="${s.id}">Enter</button>` : ''}</li>`;
  root.innerHTML = String(html`<div class="page">
    <div class="dcard" style="margin-bottom:12px">
      <div class="kv"><div><span class="lbl">Bills / month</span><b>${money(-bills, { whole: true })}</b></div><div><span class="lbl">Income / month</span><b class="pos">${money(income, { whole: true })}</b></div><div><span class="lbl">Left over</span><b class="${income + bills < 0 ? 'neg' : ''}">${money(income + bills, { whole: true })}</b></div></div>
      <button class="btn primary block" data-act="add">+ Add bill or income</button>
    </div>
    ${sections.length ? sections.map(([title, list]) => html`<div class="sectionlabel"><span>${title}</span><span>${list.length}</span></div><div class="card"><ul class="list">${list.map(row)}</ul></div>`)
      : html`<div class="empty">${icon('repeat')}<h3>No recurring items yet</h3><p>Add rent, phone, subscriptions and your pay. “Auto” items are entered on their due date; the rest wait for you to tap Enter.</p></div>`}
  </div>`);
  root.onclick = (e) => {
    if (e.target.closest('[data-act=add]')) return openRecurring();
    const pay = e.target.closest('[data-pay]');
    if (pay) { e.stopPropagation(); const s = db.get('SELECT * FROM scheduled WHERE id=?', [+pay.dataset.pay]); const tid = repo.enterScheduled(s, s.next_date); return toast(`Entered ${money(s.amount)}`, { action: 'Edit', onAction: () => screens.txedit.open({ id: tid }) }); }
    const r = e.target.closest('[data-sched]');
    if (r) openRecurring(+r.dataset.sched);
  };
}

/** Add/edit form. id = existing scheduled id, or prefill for a new one. */
export function openRecurring(id = null, prefill = {}) {
  const orig = id ? db.get('SELECT * FROM scheduled WHERE id=?', [id]) : null;
  const accts = repo.accounts();
  if (!accts.length) return toast('Add an account first');
  const s = orig ? { ...orig } : { account_id: Number(repo.meta('last_account', 0)) || accts[0].id, payee: '', amount: 0, category_id: null, transfer_account_id: null,
    freq: 'monthly', next_date: today(), end_date: null, auto_enter: 1, active: 1, ...prefill };
  let kind = s.transfer_account_id ? 'transfer' : s.amount > 0 ? 'income' : 'bill';
  const idx = repo.categoryIndex();
  const read = () => {
    const el = sh.el;
    const a = evalAmount(el.querySelector('#ramt').value);
    const mag = Number.isNaN(a) ? 0 : Math.abs(a);
    s.amount = kind === 'income' ? mag : -mag;
    s.payee = el.querySelector('#rpayee')?.value.trim() || (kind === 'transfer' ? 'Transfer' : '');
    s.account_id = +el.querySelector('#racct').value;
    s.transfer_account_id = kind === 'transfer' ? +el.querySelector('#rto').value : null;
    s.next_date = el.querySelector('#rdate').value || today();
    s.end_date = el.querySelector('#rend').value || null;
    s.auto_enter = el.querySelector('#rauto').checked ? 1 : 0;
  };
  const body = () => html`
    <div class="seg" style="margin-bottom:8px">${[['bill', 'Bill'], ['income', 'Income'], ['transfer', 'Transfer']].map(([k, l]) => html`<button data-act="kind" data-k="${k}" class="${kind === k ? 'on' : ''}">${l}</button>`)}</div>
    <div class="amtrow"><span class="cur">${kind === 'income' ? '+$' : kind === 'bill' ? '−$' : '$'}</span><input class="bigamt" id="ramt" inputmode="decimal" placeholder="0.00" value="${s.amount ? (Math.abs(s.amount) / 100).toFixed(2) : ''}"></div>
    ${kind === 'transfer' ? '' : html`<label class="pickrow"><span class="k">Name</span><input id="rpayee" value="${s.payee || ''}" placeholder="${kind === 'income' ? 'e.g. Stipend' : 'e.g. Rent, Netflix'}"></label>
      <button class="pickrow" data-act="cat"><span class="k">Category</span><span class="v ${s.category_id == null ? 'muted' : ''}">${s.category_id == null ? (kind === 'income' ? 'Ready to Assign' : 'Choose…') : idx.name(s.category_id)}</span></button>`}
    <label class="pickrow"><span class="k">${kind === 'transfer' ? 'From' : 'Account'}</span><select id="racct">${accts.map((a) => html`<option value="${a.id}" ${a.id === s.account_id ? raw('selected') : ''}>${a.name}</option>`)}</select></label>
    ${kind === 'transfer' ? html`<label class="pickrow"><span class="k">To</span><select id="rto">${accts.filter((a) => a.id !== s.account_id).map((a) => html`<option value="${a.id}" ${a.id === s.transfer_account_id ? raw('selected') : ''}>${a.name}</option>`)}</select></label>` : ''}
    <div class="lbl" style="margin:14px 0 6px">How often</div>
    <div class="chips wrap">${Object.entries(FREQ_LABEL).map(([k, l]) => html`<button class="chip ${s.freq === k ? 'on' : ''}" data-act="freq" data-f="${k}">${l}</button>`)}</div>
    <label class="pickrow"><span class="k">Next due</span><input id="rdate" type="date" value="${s.next_date}"></label>
    <label class="pickrow"><span class="k">Ends</span><input id="rend" type="date" value="${s.end_date || ''}"></label>
    <div class="pickrow"><span class="k">Auto</span><span class="v small muted">Enter it automatically on the due date</span><label class="toggle"><input type="checkbox" id="rauto" ${s.auto_enter ? raw('checked') : ''}><span></span></label></div>
    ${orig ? html`<div class="row wrap" style="margin-top:12px"><button class="btn sm" data-act="now">Enter now</button><button class="btn sm" data-act="skip">Skip next</button><button class="btn sm" data-act="pause">${s.active ? 'Pause' : 'Resume'}</button></div>` : ''}`;
  const redraw = () => { read(); sh.setBody(body()); };
  const sh = openSheet({
    title: orig ? 'Recurring' : 'New recurring',
    body: body(),
    footer: html`${orig ? html`<button class="btn danger" data-act="del" aria-label="Delete">${icon('trash')}</button>` : ''}<button class="btn primary grow" data-act="save">Save</button>`,
    actions: {
      kind: (b) => { read(); kind = b.dataset.k; if (kind === 'income' && s.category_id == null) s.category_id = repo.incomeCategoryId(); if (kind !== 'income' && s.category_id === repo.incomeCategoryId()) s.category_id = null; redraw(); },
      freq: (b) => { read(); s.freq = b.dataset.f; redraw(); },
      cat: async () => { read(); const c = await pickCategory({ allowIncome: kind === 'income' }); if (c !== undefined) { s.category_id = c; sh.setBody(body()); } },
      save: (b, e, api) => {
        read();
        if (!s.amount) return toast('Enter an amount');
        if (kind !== 'transfer' && !s.payee) return toast('Give it a name');
        if (kind === 'bill' && s.category_id == null) return toast('Pick a category');
        if (kind === 'income' && s.category_id == null) s.category_id = repo.incomeCategoryId();
        if (kind === 'transfer') s.category_id = null;
        repo.saveScheduled(s); repo.setMeta('last_account', s.account_id); api.close();
        toast(`${s.payee || 'Transfer'}: ${FREQ_LABEL[s.freq].toLowerCase()}, next ${dateLabel(s.next_date)}`);
      },
      now: (b, e, api) => { read(); repo.saveScheduled(s); const tid = repo.enterScheduled({ ...s }, s.next_date); api.close(); toast('Entered', { action: 'Edit', onAction: () => screens.txedit.open({ id: tid }) }); },
      skip: (b, e, api) => { read(); s.next_date = nextOccurrence(s.next_date, s.freq); repo.saveScheduled(s); api.close(); toast(`Skipped — next ${dateLabel(s.next_date)}`); },
      pause: (b, e, api) => { read(); s.active = s.active ? 0 : 1; repo.saveScheduled(s); api.close(); },
      del: async (b, e, api) => { if (await confirmDlg(`Delete “${s.payee || 'Transfer'}”? Past transactions stay.`, { danger: true, ok: 'Delete' })) { db.run('DELETE FROM scheduled WHERE id=?', [s.id]); api.close(); } },
    },
  });
  sh.el.addEventListener('change', (e) => { if (e.target.id === 'racct') redraw(); });
  return sh;
}

registerScreen('scheduled', { top: () => ({ title: 'Recurring', back: true, actions: [{ id: 'add', icon: 'plus', label: 'Add recurring' }] }), topAction: (a) => a === 'add' && openRecurring(), render });
