// Category / account pickers.
import * as repo from '../repo.js';
import { html, openSheet } from './dom.js';
import { money, thisMonth, monthOf } from '../util.js';

/** Pick a category. opts: {month, allowIncome, allowNone, exclude, title}. Resolves id | null | undefined(cancel). */
export function pickCategory({ month = thisMonth(), allowIncome = true, allowNone = false, exclude = null, title = 'Category', date = null } = {}) {
  const m = date ? monthOf(date) : month;
  const idx = repo.categoryIndex();
  const b = repo.budget(m).months.get(m);
  return new Promise((resolve) => {
    const list = (q) => {
      const ql = q.trim().toLowerCase();
      const out = [];
      for (const g of idx.groups) {
        if (g.system === 'income' && !allowIncome) continue;
        const cats = idx.categories.filter((c) => c.group_id === g.id && !c.hidden && c.id !== exclude && (!ql || c.name.toLowerCase().includes(ql) || g.name.toLowerCase().includes(ql)));
        if (!cats.length) continue;
        out.push(html`<div class="sectionlabel">${g.system === 'income' ? 'Income' : g.name}</div>`);
        for (const c of cats) {
          const av = b?.cats.get(c.id)?.available;
          const cls = c.system === 'income' ? '' : av < 0 ? 'bad' : av > 0 ? 'good' : '';
          out.push(html`<button class="pickrow" data-act="pick" data-id="${c.id}"><span class="v">${c.emoji ? c.emoji + ' ' : ''}${c.name}</span>
            ${c.system === 'income' ? html`<span class="small muted">${money(b?.rta ?? 0)} to assign</span>` : html`<span class="pill ${cls}">${money(av ?? 0)}</span>`}</button>`);
        }
      }
      return html`${allowNone ? html`<button class="pickrow" data-act="pick" data-id=""><span class="v muted">No category</span></button>` : ''}${out}`;
    };
    const s = openSheet({
      title,
      body: html`<div class="search" style="position:sticky;top:0;z-index:1"><input id="cq" placeholder="Search categories" autocomplete="off"></div><div id="cl">${list('')}</div>`,
      onClose: (r) => resolve(r),
      actions: { pick: (btn, e, api) => api.close(btn.dataset.id === '' ? null : Number(btn.dataset.id)) },
    });
    const q = s.el.querySelector('#cq');
    q.addEventListener('input', () => { s.el.querySelector('#cl').innerHTML = String(list(q.value)); });
  });
}

export function pickAccount({ title = 'Account', exclude = null, includeTracking = true } = {}) {
  const bal = repo.accountBalances();
  const accts = repo.accounts().filter((a) => a.id !== exclude && (includeTracking || a.on_budget));
  return new Promise((resolve) => {
    openSheet({
      title,
      body: html`${accts.map((a) => html`<button class="pickrow" data-act="pick" data-id="${a.id}"><span class="v">${a.name}<div class="small muted">${repo.ACCOUNT_TYPES[a.type]?.label || a.type}${a.on_budget ? '' : ' · tracking'}</div></span><span class="amt">${money(bal.get(a.id)?.balance || 0)}</span></button>`)}`,
      onClose: (r) => resolve(r),
      actions: { pick: (btn, e, api) => api.close(Number(btn.dataset.id)) },
    });
  });
}
