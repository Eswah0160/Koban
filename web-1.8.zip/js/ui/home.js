// Home dashboard: what needs doing, how the month is going, quick actions.
import * as repo from '../repo.js';
import { meta } from '../db.js';
import { html, icon } from './dom.js';
import { state, go, registerScreen, screens } from './app.js';
import { money, thisMonth, today, addDays, daysInMonth, dateLabel, monthLabel } from '../util.js';
import { expandScheduled, cashForecast, isCashLike, isLiability, ageOfMoney } from '../engine/analytics.js';
import { autoAssign } from '../engine/budget.js';
import { openCategory } from './budget.js';

const pct = (a, b) => (b > 0 ? Math.max(0, Math.min(1, a / b)) : 0);

function render(root) {
  const m = thisMonth();
  const B = repo.budget(m);
  const b = B.months.get(m);
  const idx = repo.categoryIndex();
  const counts = repo.counts();
  const spendCats = idx.categories.filter((c) => !c.system && !c.hidden);
  const rows = spendCats.map((c) => ({ c, r: b?.cats.get(c.id) })).filter((x) => x.r);

  // Month pace (spending categories only — card payments excluded)
  const spent = rows.reduce((s, x) => s + Math.max(0, -x.r.activity), 0);
  const plan = rows.reduce((s, x) => s + Math.max(0, x.r.assigned + x.r.carryIn), 0);
  const left = rows.reduce((s, x) => s + Math.max(0, x.r.available), 0);
  const day = Number(today().slice(8, 10)), dim = daysInMonth(m);
  const daysLeft = dim - day + 1;
  const projected = day > 0 ? Math.round((spent / day) * dim) : 0;
  const overspent = rows.filter((x) => x.r.available < 0);

  // Accounts
  const accts = repo.accounts();
  const bal = repo.accountBalances();
  const cash = accts.filter(isCashLike).reduce((s, a) => s + (bal.get(a.id)?.balance || 0), 0);
  const owed = accts.filter((a) => a.type === 'credit').reduce((s, a) => s + Math.min(0, bal.get(a.id)?.balance || 0), 0);
  const net = accts.reduce((s, a) => s + (bal.get(a.id)?.balance || 0), 0);

  // Upcoming + forecast
  const sched = repo.scheduledList();
  const upcoming = expandScheduled(sched, '0000-01-01', addDays(today(), 7)).slice(0, 5);
  const fc = cashForecast({ startBalance: accts.filter(isCashLike).reduce((s, a) => s + (bal.get(a.id)?.today_balance || 0), 0), scheduled: sched, accounts: accts, from: today(), days: 14 });

  // Things to do
  const todos = [];
  if (counts.inbox) todos.push({ n: counts.inbox, hot: true, t: `transaction${counts.inbox === 1 ? '' : 's'} to review`, act: 'review' });
  if (counts.uncategorised) todos.push({ n: counts.uncategorised, hot: true, t: 'need a category', act: 'uncat' });
  if (overspent.length) todos.push({ n: overspent.length, hot: true, t: `overspent — cover ${money(-overspent.reduce((s, x) => s + x.r.available, 0))}`, act: 'cover' });
  if ((b?.rta ?? 0) > 0) todos.push({ n: '$', t: `${money(b.rta)} ready to assign`, act: 'assign' });
  if ((b?.rta ?? 0) < 0) todos.push({ n: '!', hot: true, t: `assigned ${money(-b.rta)} more than you have`, act: 'budget' });
  if (b?.underfunded) todos.push({ n: '◎', t: `targets need ${money(b.underfunded)} — fund them`, act: 'fund' });
  if (fc.low.balance < 0) todos.push({ n: '!', hot: true, t: `cash dips to ${money(fc.low.balance)} on ${dateLabel(fc.low.date)}`, act: 'forecast' });

  // Envelopes to watch: pinned, else biggest spenders this month
  const pinned = meta('pinned_cats', []) || [];
  let watch = pinned.map((id) => rows.find((x) => x.c.id === id)).filter(Boolean);
  if (!watch.length) watch = [...rows].sort((a, z) => z.r.activity * -1 - a.r.activity * -1).filter((x) => x.r.activity < 0 || x.r.available !== 0).slice(0, 5);

  const recent = repo.listTxns({ limit: 5 });
  const aom = ageOfMoney(repo.allTxns(), repo.accounts(true));

  root.innerHTML = String(html`<div class="page"><div class="dash">
    <section class="dcard">
      <div class="lbl">${monthLabel(m)} · ${daysLeft} day${daysLeft === 1 ? '' : 's'} left</div>
      <div class="row" style="align-items:flex-end">
        <div class="grow"><div class="big num ${left < 0 ? 'neg' : ''}">${money(left)}</div><div class="lbl" style="margin-top:4px">left to spend in envelopes</div></div>
        ${daysLeft > 0 && left > 0 ? html`<div class="right"><div class="num" style="font-size:17px">${money(Math.floor(left / daysLeft))}</div><div class="lbl">per day</div></div>` : ''}
      </div>
      <div class="pace" title="Spent vs planned; red line = today"><i class="${spent > plan ? 'over' : ''}" style="width:${pct(spent, plan) * 100}%"></i><u style="left:${(day / dim) * 100}%"></u></div>
      <div class="kv">
        <div><span class="lbl">Spent</span><b>${money(spent, { whole: true })}</b></div>
        <div><span class="lbl">Planned</span><b>${money(plan, { whole: true })}</b></div>
        <div><span class="lbl">On pace for</span><b class="${projected > plan && plan > 0 ? 'neg' : ''}">${money(projected, { whole: true })}</b></div>
      </div>
    </section>

    <section class="dcard">
      <div class="quick">
        <button data-q="add">${icon('plus')}Add</button>
        <button data-q="receipt">${icon('camera')}Receipt</button>
        <button data-q="import">${icon('upload')}Import</button>
        <button data-q="transfer">${icon('swap')}Transfer</button>
      </div>
    </section>

    <section class="dcard">
      <h2>To do</h2>
      ${todos.length ? todos.map((x) => html`<button class="todo ${x.hot ? 'hot' : ''}" data-todo="${x.act}"><span class="n">${x.n}</span><span class="grow">${x.t}</span>${icon('fwd')}</button>`)
        : html`<div class="allclear">✓ All caught up</div>`}
    </section>

    <section class="dcard">
      <h2>Envelopes ${pinned.length ? '' : html`<span class="lbl" style="letter-spacing:.06em">· top spending</span>`}<button class="more" data-go="budget">Budget</button></h2>
      ${watch.length ? watch.map(({ c, r }) => {
        const base = Math.max(0, r.assigned + r.carryIn);
        const used = pct(-r.activity, base);
        return html`<button class="env" data-cat="${c.id}"><span class="ellipsis">${c.emoji ? c.emoji + ' ' : ''}${c.name}</span><span class="v ${r.available < 0 ? 'neg' : ''}">${money(r.available)}</span>
          <span class="bar"><i class="${r.available < 0 ? 'bad' : ''}" style="width:${(r.available < 0 ? 1 : used) * 100}%"></i></span></button>`;
      }) : html`<p class="muted small" style="margin:0">Assign money in Budget to see envelopes here.</p>`}
      <p class="tiny muted" style="margin:0">Pin envelopes here from a category’s detail.</p>
    </section>

    <section class="dcard">
      <h2>Next 7 days<button class="more" data-go="scheduled">Recurring</button></h2>
      ${upcoming.length ? upcoming.map((o) => html`<div class="mini"><span class="t">${o.payee || 'Transfer'}<small>${dateLabel(o.date)}${o.auto_enter ? ' · auto' : ''}</small></span><span class="amt ${o.amount > 0 ? 'in' : ''}">${money(o.amount)}</span></div>`)
        : html`<p class="muted small" style="margin:0">Nothing scheduled. Make a bill recurring from its transaction.</p>`}
    </section>

    <section class="dcard">
      <h2>Money<button class="more" data-go="accounts">Accounts</button></h2>
      <div class="kv">
        <div><span class="lbl">Cash</span><b>${money(cash, { whole: true })}</b></div>
        <div><span class="lbl">Cards owed</span><b class="${owed < 0 ? 'neg' : ''}">${money(-owed, { whole: true })}</b></div>
        <div><span class="lbl">Net worth</span><b>${money(net, { whole: true })}</b></div>
      </div>
      <div class="kv">
        <div><span class="lbl">Age of money</span><b>${aom.days != null ? aom.days + 'd' : '—'}</b></div>
        <div><span class="lbl">Ready to assign</span><b class="${(b?.rta ?? 0) < 0 ? 'neg' : ''}">${money(b?.rta ?? 0, { whole: true })}</b></div>
        <div><span class="lbl">14-day low</span><b class="${fc.low.balance < 0 ? 'neg' : ''}">${money(fc.low.balance, { whole: true })}</b></div>
      </div>
      <button class="btn sm" data-go="insights">${icon('chart')} Insights</button>
    </section>

    <section class="dcard span2">
      <h2>Recent<button class="more" data-go="tx">All</button></h2>
      ${recent.length ? recent.map((t) => html`<button class="mini env" data-tx="${t.id}" style="display:flex"><span class="t">${t.payee || '—'}<small>${dateLabel(t.date)} · ${t.category_name || (t.transfer_account_id ? 'Transfer' : t.is_split ? 'Split' : 'Needs category')}</small></span><span class="amt ${t.amount > 0 ? 'in' : ''}">${money(t.amount)}</span></button>`)
        : html`<p class="muted small" style="margin:0">No transactions yet — tap Add.</p>`}
    </section>
  </div></div>`);

  root.onclick = async (e) => {
    const q = e.target.closest('[data-q]')?.dataset.q;
    if (q === 'add') return screens.txedit.open({});
    if (q === 'receipt') return screens.receipt.start();
    if (q === 'import') return screens.importer.start();
    if (q === 'transfer') { const s = screens.txedit.open({}); s?.el.querySelector('[data-k=transfer]')?.click(); return; }
    const g = e.target.closest('[data-go]')?.dataset.go;
    if (g) { if (g === 'tx') state.tx.filter = 'all'; return go(g); }
    const c = e.target.closest('[data-cat]');
    if (c) return openCategory(+c.dataset.cat);
    const t = e.target.closest('[data-tx]');
    if (t) return screens.txedit.open({ id: +t.dataset.tx });
    const td = e.target.closest('[data-todo]')?.dataset.todo;
    if (td === 'review') { state.tx.filter = 'review'; return go('tx'); }
    if (td === 'uncat') { state.tx.filter = 'uncat'; return go('tx'); }
    if (td === 'assign' || td === 'budget') { state.month = m; return go('budget'); }
    if (td === 'cover' || td === 'fund') {
      const plan2 = autoAssign(td === 'cover' ? 'cover_overspent' : 'underfunded', repo.budget(m), m, repo.categories());
      const before = new Map([...plan2.keys()].map((id) => [id, repo.assignedFor(m, id)]));
      repo.applyAssignments(m, plan2);
      const { toast } = await import('./dom.js');
      return toast(`${td === 'cover' ? 'Covered' : 'Funded'} ${plan2.size} categor${plan2.size === 1 ? 'y' : 'ies'}`, { action: 'Undo', onAction: () => repo.applyAssignments(m, before) });
    }
    if (td === 'forecast') { state.insightsTab = 'forecast'; return go('insights'); }
  };
}

function renderMore(root) {
  const c = repo.counts();
  const items = [
    ['accounts', 'bank', 'Accounts', 'Balances, reconcile, import statements'],
    ['insights', 'chart', 'Insights', 'Spending, trends, net worth, subscriptions, forecast'],
    ['scheduled', 'repeat', 'Recurring', 'Bills and pay that repeat'],
    ['categories', 'edit', 'Categories', 'Rename, reorder, hide'],
    ['rules', 'filter', 'Rules', 'Clean payee names, auto-categorise'],
    ['capture', 'bell', 'Notification capture', c.inbox ? `${c.inbox} waiting in review` : 'Read purchases from bank alerts'],
    ['settings', 'gear', 'Settings', 'AI, backup, lock, theme, updates'],
  ];
  root.innerHTML = String(html`<div class="page"><div class="card"><ul class="list menu-list wlist">${items.map(([r, ic, t, s]) => html`<li class="item tap" data-go="${r}">${icon(ic)}<div class="grow"><div class="title">${t}</div><div class="sub">${s}</div></div>${icon('fwd')}</li>`)}</ul></div></div>`);
  root.onclick = (e) => { const g = e.target.closest('[data-go]')?.dataset.go; if (g) go(g); };
}

registerScreen('home', {
  top: () => ({ center: html`<div class="grow brand">KOBAN<small>小判</small></div>` }),
  render,
});
registerScreen('more', { top: () => ({ title: 'More' }), render: renderMore });
