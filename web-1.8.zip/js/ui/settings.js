// Settings + sub-screens: categories, rules, notification capture.
import * as repo from '../repo.js';
import { db, meta, setMeta } from '../db.js';
import { html, raw, icon, openSheet, toast, confirmDlg, promptDlg, menu } from './dom.js';
import { state, go, registerScreen, queueRender } from './app.js';
import { pickCategory, pickAccount } from './pickers.js';
import { pickFile } from './importer.js';
import { aiConfig, listModels, DEFAULT_MODEL } from '../io/ai.js';
import { exportAll, restoreAll, txnsCSV, monthMarkdown } from '../io/backup.js';
import { parseNotification, processCaptures } from '../io/notify.js';
import { money, thisMonth, monthLabel, today, addMonths } from '../util.js';
import * as native from '../native.js';

export function applyTheme() {
  const t = meta('theme', 'system');
  if (t === 'system') document.documentElement.removeAttribute('data-theme');
  else document.documentElement.setAttribute('data-theme', t);
}

const tog = (id, on, label, sub = '') => html`<li class="item"><div class="grow"><div class="title">${label}</div>${sub ? html`<div class="sub">${sub}</div>` : ''}</div><label class="toggle"><input type="checkbox" data-tog="${id}" ${on ? raw('checked') : ''}><span></span></label></li>`;
const link = (act, label, sub = '', ic = null) => html`<li class="item tap" data-act="${act}">${ic ? icon(ic) : ''}<div class="grow"><div class="title">${label}</div>${sub ? html`<div class="sub">${sub}</div>` : ''}</div>${icon('fwd')}</li>`;

function render(root) {
  const inf = native.info();
  const ai = aiConfig();
  const lastBackup = meta('last_backup');
  root.innerHTML = String(html`<div class="page"><div class="wgrid"><div class="wsec"><div class="sectionlabel">Getting money in</div>
    <div class="card"><ul class="list">
      ${link('capture', 'Notification capture', inf.native ? (inf.listenerEnabled ? 'On — reading the apps you picked' : 'Off — tap to set up') : 'Phone only', 'bell')}
      ${link('ai', 'AI (Gemini)', ai.enabled ? `Key set · ${ai.model}` : 'Not set — receipts use on-phone OCR', 'sparkle')}
      ${link('rules', 'Payee & category rules', `${db.val('SELECT COUNT(*) FROM rules')} rules`, 'filter')}
    </ul></div>
    </div><div class="wsec"><div class="sectionlabel">Budget</div>
    <div class="card"><ul class="list">
      ${link('categories', 'Categories & groups', '', 'edit')}
      ${link('scheduled', 'Recurring transactions', '', 'repeat')}
    </ul></div>
    </div><div class="wsec"><div class="sectionlabel">Backup & export</div>
    <div class="card"><ul class="list">
      ${tog('auto_backup', meta('auto_backup', true), 'Weekly auto-backup', lastBackup ? `Last: ${lastBackup} → Downloads/Koban` : 'Saves a JSON backup to Downloads/Koban')}
      ${link('backup', 'Back up now', 'JSON file with everything (not your API key)', 'download')}
      ${link('restore', 'Restore from backup', 'Replaces all data in the app', 'upload')}
      ${link('csv', 'Export transactions (CSV)', '', 'list')}
      ${link('md', 'Month summary for Obsidian', 'Markdown note with frontmatter', 'receipt')}
    </ul></div>
    </div><div class="wsec"><div class="sectionlabel">Privacy & look</div>
    <div class="card"><ul class="list">
      ${tog('lock', meta('lock', false), 'Fingerprint / PIN lock', inf.native ? 'Asks when opening and after 2 min away' : 'Phone only')}
      ${tog('secure', meta('secure', false), 'Hide in recent apps', 'Also blocks screenshots')}
      <li class="item"><div class="grow"><div class="title">Theme</div></div><div class="seg" style="width:220px">${['system', 'light', 'dark'].map((t) => html`<button data-theme="${t}" class="${meta('theme', 'system') === t ? 'on' : ''}">${t[0].toUpperCase() + t.slice(1)}</button>`)}</div></li>
    </ul></div>
    </div><div class="wsec"><div class="sectionlabel">App</div>
    <div class="card"><ul class="list">
      <li class="item"><div class="grow"><div class="title">Version</div><div class="sub">App ${inf.appVersion} · UI ${inf.webVersion} (${inf.webSource})</div></div><button class="btn sm" data-act="update">Check</button></li>
      ${link('help', 'How Koban works', '', 'budget')}
      <li class="item tap" data-act="erase"><div class="grow"><div class="title neg">Erase all data</div></div></li>
    </ul></div>
    </div></div>
    <p class="tiny muted" style="text-align:center">Data lives only in this app’s private storage on your phone.</p>
  </div>`);
  root.onclick = onClick;
  root.onchange = (e) => {
    const k = e.target.dataset.tog; if (!k) return;
    setMeta(k, e.target.checked);
    if (k === 'secure') native.setSecure(e.target.checked);
    if (k === 'lock') native.setLock(e.target.checked);
  };
}

async function onClick(e) {
  const th = e.target.closest('[data-theme]');
  if (th) { setMeta('theme', th.dataset.theme); applyTheme(); return queueRender(); }
  const a = e.target.closest('[data-act]')?.dataset.act;
  if (!a) return;
  if (['capture', 'rules', 'categories', 'scheduled'].includes(a)) return go(a);
  if (a === 'ai') return aiSheet();
  if (a === 'backup') { const r = backupNow(); return toast(r ? 'Backup saved to Downloads/Koban' : 'Backup failed'); }
  if (a === 'restore') {
    const f = await pickFile('application/json,.json');
    if (!f) return;
    let data; try { data = JSON.parse(await f.text()); } catch { return toast('Not a JSON file'); }
    if (!(await confirmDlg(`Replace everything with the backup from ${data.exported_at?.slice(0, 10) || '?'}? Current data will be lost (a backup of it is saved first).`, { danger: true, ok: 'Restore' }))) return;
    backupNow('pre-restore');
    try { restoreAll(data); toast('Restored'); } catch (err) { toast(err.message); }
    return;
  }
  if (a === 'csv') { native.saveFile(`koban-transactions-${today()}.csv`, 'text/csv', txnsCSV()); return toast('Saved to Downloads/Koban'); }
  if (a === 'md') {
    const m = await menu('Which month?', [0, 1, 2].map((i) => ({ value: addMonths(thisMonth(), -i), label: monthLabel(addMonths(thisMonth(), -i)) })));
    if (!m) return;
    const md = monthMarkdown(m);
    const how = await menu('Send to', [{ value: 'share', label: 'Share… (pick Obsidian)', sub: 'Uses Android share sheet' }, { value: 'save', label: 'Save .md to Downloads/Koban', sub: 'Move into your vault' }]);
    if (how === 'share') native.share(md, { subject: `Budget ${m}`, filename: `Budget ${m}.md`, mime: 'text/markdown' });
    if (how === 'save') { native.saveFile(`Budget ${m}.md`, 'text/markdown', md); toast('Saved'); }
    return;
  }
  if (a === 'update') {
    toast('Checking…');
    try {
      const r = await native.checkUpdate();
      if (r.apkAvailable && await confirmDlg(`A new app version (${r.apkVersion}) is available. Download and install it?`, { ok: 'Install', title: 'App update' })) return native.installApk(r.apkUrl);
      if (r.available) { toast(`Downloading UI ${r.version}…`); await native.applyUpdate(); toast('Updated', { action: 'Reload', onAction: native.reload, ms: 8000 }); }
      else toast(r.reason === 'browser' ? 'Updates apply on the phone' : 'You’re up to date');
    } catch (err) { toast('Update check failed: ' + err.message); }
    return;
  }
  if (a === 'help') return help();
  if (a === 'erase') {
    if (!(await confirmDlg('Erase every account, transaction and setting? A backup is saved to Downloads/Koban first.', { danger: true, ok: 'Erase' }))) return;
    backupNow('pre-erase');
    db.tx(() => { for (const t of ['accounts', 'category_groups', 'categories', 'transactions', 'splits', 'assignments', 'scheduled', 'rules', 'receipts', 'card_map', 'capture_inbox', 'capture_sources']) db.run(`DELETE FROM ${t}`); db.run("DELETE FROM meta WHERE key!='schema_version'"); });
    location.hash = ''; native.reload();
  }
}

export function backupNow(tag = '') {
  try {
    const data = exportAll();
    native.saveFile(`koban-backup-${today()}${tag ? '-' + tag : ''}.json`, 'application/json', JSON.stringify(data));
    setMeta('last_backup', today());
    return true;
  } catch (e) { console.error(e); return false; }
}

async function aiSheet() {
  const ai = aiConfig();
  let models = [];
  const body = () => html`<p class="small ink2">Free key from Google AI Studio (aistudio.google.com → Get API key). It’s stored only on this phone and used to read receipts and suggest categories. Without it Koban uses on-phone text recognition and your own history.</p>
    <div class="field"><label>Gemini API key</label><input class="input" id="k" type="password" value="${meta('gemini_key', '')}" placeholder="AIza…" autocomplete="off"></div>
    <div class="field"><label>Model</label>${models.length ? html`<select class="input" id="m">${models.map((m) => html`<option ${m === ai.model ? raw('selected') : ''}>${m}</option>`)}</select>` : html`<input class="input" id="m" value="${ai.model}">`}
      <span class="tiny muted">Default “${DEFAULT_MODEL}” follows Google’s current Flash model. Tap Test to list what your key can use.</span></div>`;
  const s = openSheet({
    title: 'AI (Gemini)', body: body(),
    footer: html`<button class="btn" data-act="test">Test key</button><button class="btn primary grow" data-act="save">Save</button>`,
    actions: {
      test: async () => {
        const k = s.el.querySelector('#k').value.trim(); if (!k) return toast('Paste a key first');
        try { models = await listModels(k); const cur = s.el.querySelector('#m').value; s.setBody(body()); s.el.querySelector('#k').value = k; if (models.includes(cur)) s.el.querySelector('#m').value = cur; toast(`Key works — ${models.length} models`); }
        catch (err) { toast('Key rejected: ' + err.message, { ms: 6000 }); }
      },
      save: (b, e, api) => { setMeta('gemini_key', s.el.querySelector('#k').value.trim()); setMeta('gemini_model', s.el.querySelector('#m').value.trim() || DEFAULT_MODEL); api.close(); queueRender(); toast('Saved'); },
    },
  });
}

function help() {
  openSheet({ title: 'How Koban works', body: html`
    <p><b>Give every dollar a job.</b> Money that lands in your budget accounts shows as <b>Ready to Assign</b>. Assign it to categories until it reaches $0. Spending comes out of a category’s <b>Available</b>.</p>
    <p><b>Positive balances roll over</b> to next month. <b>Overspent</b> (red) categories should be covered by moving money from another category; if not, cash overspending is taken from next month’s Ready to Assign.</p>
    <p><b>Credit cards:</b> when you buy on a card from a funded category, Koban moves that money into the card’s payment category so it’s there when the bill comes. Paying the card is a transfer from your everyday account.</p>
    <p><b>Targets</b> tell Koban what each category needs: monthly amounts, bills (incl. fortnightly), save-by-date goals. “Underfunded” shows what’s still needed; Auto-assign fills it.</p>
    <p><b>Getting transactions in:</b> notifications from apps you choose become transactions to review; statement CSV/OFX imports are matched against them so nothing doubles; receipts add line-item splits.</p>
    <p><b>Reconcile</b> an account occasionally: enter the bank’s balance and Koban locks everything that matches.</p>` });
}

// ---------- categories ----------
async function deleteCategoryFlow(cat) {
  const n = db.val('SELECT COUNT(*) FROM transactions WHERE category_id=?', [cat.id]) + db.val('SELECT COUNT(*) FROM splits WHERE category_id=?', [cat.id]);
  const money0 = db.val('SELECT COALESCE(SUM(amount),0) FROM assignments WHERE category_id=?', [cat.id]);
  let to = null;
  if (n || money0) {
    to = await pickCategory({ title: `Move ${n} transaction${n === 1 ? '' : 's'} and budgeted money to…`, exclude: cat.id, allowIncome: false, allowNone: true });
    if (to === undefined) return false;
  }
  if (!(await confirmDlg(`Delete “${cat.name}”?${n ? ` Its ${n} transaction${n === 1 ? '' : 's'} move to ${to ? repo.category(to)?.name : 'Uncategorised'}.` : ''}`, { danger: true, ok: 'Delete' }))) return false;
  repo.deleteCategory(cat.id, to);
  setMeta('pinned_cats', (meta('pinned_cats', []) || []).filter((x) => x !== cat.id));
  toast(`Deleted ${cat.name}`);
  return true;
}

function renderCategories(root) {
  const idx = repo.categoryIndex();
  const groups = idx.groups.filter((g) => g.system !== 'income');
  root.innerHTML = String(html`<div class="page"><p class="small muted">Tap a name to rename or set a target. ▲ moves it up, 🗑 deletes it (its transactions move to a category you pick).</p>
    <div class="wgrid">${groups.map((g) => html`<div class="card"><div class="card-h"><span class="grow" style="text-transform:none;font-size:15px;color:var(--ink);letter-spacing:0;font-family:var(--f-body)">${g.name}${g.hidden ? ' (hidden)' : ''}</span>
      ${g.system ? html`<span class="tiny muted">automatic</span>` : html`<button class="iconbtn" data-g="up" data-id="${g.id}" aria-label="Move group up">▲</button><button class="iconbtn" data-g="menu" data-id="${g.id}" aria-label="Group options">${icon('more')}</button>`}</div>
      <ul class="list">${idx.categories.filter((c) => c.group_id === g.id).map((c) => html`<li class="item" style="${c.hidden ? 'opacity:.5' : ''};padding:4px 6px 4px 14px"><div class="grow tap" data-c="menu" data-id="${c.id}" style="padding:8px 0"><div class="title">${c.emoji ? c.emoji + ' ' : ''}${c.name}</div>${c.hidden ? html`<div class="sub">hidden</div>` : ''}</div>
        ${c.system ? '' : html`<button class="iconbtn" data-c="up" data-id="${c.id}" aria-label="Move up">▲</button><button class="iconbtn" data-c="del" data-id="${c.id}" aria-label="Delete ${c.name}">${icon('trash')}</button>`}</li>`)}</ul>
      ${g.system ? '' : html`<button class="btn ghost sm" data-g="add" data-id="${g.id}" style="margin:4px 8px 8px">+ Category</button>`}</div>`)}</div>
    <button class="btn block" data-act="addgroup" style="margin-top:12px">+ New group</button></div>`);
  root.onclick = async (e) => {
    if (e.target.closest('[data-act=addgroup]')) { const n = await promptDlg('Group name'); if (n) repo.saveGroup({ name: n.trim() }); return; }
    const g = e.target.closest('[data-g]');
    if (g) {
      const id = +g.dataset.id, grp = idx.gById.get(id);
      if (g.dataset.g === 'add') { const n = await promptDlg(`New category in ${grp.name}`); if (n) repo.saveCategory({ group_id: id, name: n.trim() }); return; }
      if (g.dataset.g === 'up') { const ids = groups.filter((x) => !x.system).map((x) => x.id); const i = ids.indexOf(id); if (i > 0) { [ids[i - 1], ids[i]] = [ids[i], ids[i - 1]]; repo.reorder('category_groups', ids); } return; }
      const kids = idx.categories.filter((c) => c.group_id === id);
      const k = await menu(grp.name, [{ value: 'rename', label: 'Rename group' }, { value: 'hide', label: grp.hidden ? 'Unhide group' : 'Hide group' },
        { value: 'delete', label: kids.length ? `Delete group and its ${kids.length} categor${kids.length === 1 ? 'y' : 'ies'}` : 'Delete group', danger: true }]);
      if (k === 'rename') { const n = await promptDlg('Rename group', { value: grp.name }); if (n) repo.saveGroup({ ...grp, name: n.trim() }); }
      if (k === 'hide') repo.saveGroup({ ...grp, hidden: !grp.hidden });
      if (k === 'delete') {
        let to = null;
        const used = kids.some((c) => db.val('SELECT COUNT(*) FROM transactions WHERE category_id=?', [c.id]) || db.val('SELECT COUNT(*) FROM assignments WHERE category_id=? AND amount!=0', [c.id]));
        if (used) { to = await pickCategory({ title: 'Move their transactions and money to…', allowIncome: false, allowNone: true }); if (to === undefined) return; if (kids.some((c) => c.id === to)) return toast('Pick a category outside this group'); }
        if (!(await confirmDlg(`Delete ${grp.name}${kids.length ? ` and ${kids.map((c) => c.name).join(', ')}` : ''}?`, { danger: true, ok: 'Delete' }))) return;
        db.tx(() => { kids.forEach((c) => repo.deleteCategory(c.id, to)); db.run('DELETE FROM category_groups WHERE id=?', [id]); });
        toast(`Deleted ${grp.name}`);
      }
      return;
    }
    const c = e.target.closest('[data-c]');
    if (c) {
      const id = +c.dataset.id, cat = idx.byId.get(id);
      if (c.dataset.c === 'up') { const ids = idx.categories.filter((x) => x.group_id === cat.group_id).map((x) => x.id); const i = ids.indexOf(id); if (i > 0) { [ids[i - 1], ids[i]] = [ids[i], ids[i - 1]]; repo.reorder('categories', ids); } return; }
      if (cat.system) return;
      if (c.dataset.c === 'del') return deleteCategoryFlow(cat);
      const k = await menu(cat.name, [{ value: 'rename', label: 'Rename' }, { value: 'emoji', label: 'Emoji', sub: cat.emoji || 'none' }, { value: 'move', label: 'Move to group…' }, { value: 'hide', label: cat.hidden ? 'Unhide' : 'Hide' }, { value: 'target', label: 'Target…' }, { value: 'delete', label: 'Delete', danger: true }]);
      if (k === 'rename') { const n = await promptDlg('Rename', { value: cat.name }); if (n) repo.saveCategory({ ...cat, name: n.trim() }); }
      if (k === 'emoji') { const n = await promptDlg('Emoji', { value: cat.emoji || '' }); if (n != null) repo.saveCategory({ ...cat, emoji: n.trim() || null }); }
      if (k === 'hide') repo.saveCategory({ ...cat, hidden: !cat.hidden });
      if (k === 'move') { const gid = await menu('Move to', groups.filter((x) => !x.system).map((x) => ({ value: x.id, label: x.name }))); if (gid) repo.saveCategory({ ...cat, group_id: gid }); }
      if (k === 'target') { const { editTarget } = await import('./budget.js'); editTarget(id); }
      if (k === 'delete') deleteCategoryFlow(cat);
    }
  };
}

// ---------- rules ----------
function renderRules(root) {
  const idx = repo.categoryIndex();
  const rules = repo.rules();
  root.innerHTML = String(html`<div class="page"><p class="small muted">Rules rename messy bank text and set categories for statements and notifications. Koban also learns from your history; a rule is created when you tick “Remember” while reviewing.</p>
    <div class="card">${rules.length ? html`<ul class="list">${rules.map((r) => html`<li class="item tap" data-r="${r.id}" style="${r.enabled ? '' : 'opacity:.5'}"><div class="grow"><div class="title ellipsis">${r.match_type} “${r.pattern}”</div><div class="sub">→ ${r.set_payee || 'keep payee'} · ${r.set_category_id ? idx.name(r.set_category_id) : 'keep category'} · used ${r.hits}×</div></div></li>`)}</ul>` : html`<div class="empty">No rules yet.</div>`}</div>
    <button class="btn block" data-act="add">+ Add rule</button></div>`);
  root.onclick = (e) => {
    if (e.target.closest('[data-act=add]')) return editRule({});
    const r = e.target.closest('[data-r]'); if (r) editRule(rules.find((x) => x.id === +r.dataset.r));
  };
}
function editRule(rule) {
  const r = { match_type: 'contains', pattern: '', set_payee: '', set_category_id: null, enabled: 1, ...rule };
  const idx = repo.categoryIndex();
  const body = () => html`
    <div class="field"><label>When bank text</label><select class="input" id="mt">${[['contains', 'contains'], ['starts', 'starts with'], ['equals', 'equals'], ['regex', 'matches regex']].map(([k, l]) => html`<option value="${k}" ${r.match_type === k ? raw('selected') : ''}>${l}</option>`)}</select></div>
    <div class="field"><input class="input" id="pt" value="${r.pattern}" placeholder="WOOLWORTHS"></div>
    <div class="field"><label>Rename payee to</label><input class="input" id="sp" value="${r.set_payee || ''}" placeholder="Woolworths"></div>
    <button class="pickrow" data-act="cat"><span class="k">Category</span><span class="v">${r.set_category_id ? idx.name(r.set_category_id) : 'Don’t change'}</span></button>
    <label class="row" style="margin-top:12px"><input type="checkbox" id="en" ${r.enabled ? raw('checked') : ''}> Enabled</label>`;
  const read = () => { r.match_type = s.el.querySelector('#mt').value; r.pattern = s.el.querySelector('#pt').value.trim(); r.set_payee = s.el.querySelector('#sp').value.trim(); r.enabled = s.el.querySelector('#en').checked ? 1 : 0; };
  const s = openSheet({
    title: r.id ? 'Edit rule' : 'New rule', body: body(),
    footer: html`${r.id ? html`<button class="btn danger" data-act="del">${icon('trash')}</button>` : ''}<button class="btn primary grow" data-act="save">Save</button>`,
    actions: {
      cat: async () => { read(); const c = await pickCategory({ allowNone: true }); if (c !== undefined) { r.set_category_id = c; s.setBody(body()); } },
      save: (b, e, api) => { read(); if (!r.pattern) return toast('Enter what to match'); if (r.match_type === 'regex') { try { new RegExp(r.pattern); } catch { return toast('Invalid regex'); } } repo.saveRule(r); api.close(); },
      del: (b, e, api) => { db.run('DELETE FROM rules WHERE id=?', [r.id]); api.close(); },
    },
  });
}

// ---------- notification capture ----------
function renderCapture(root) {
  const inf = native.info();
  const sources = db.all('SELECT s.*, a.name AS account_name FROM capture_sources s LEFT JOIN accounts a ON a.id=s.account_id ORDER BY s.pkg');
  const srcSet = new Set(sources.map((s) => s.pkg));
  const seen = db.all('SELECT * FROM capture_seen ORDER BY last_seen DESC LIMIT 40').filter((s) => !srcSet.has(s.pkg));
  const log = db.all('SELECT * FROM capture_inbox ORDER BY posted_at DESC LIMIT 60');
  root.innerHTML = String(html`<div class="page">
    ${inf.native ? (inf.listenerEnabled
      ? html`<div class="banner">${icon('check')}<span class="grow">Notification access is on</span></div>`
      : html`<button class="banner warn" data-act="perm">${icon('bell')}<span class="grow">Allow Koban to read notifications (Android setting) — required for capture</span>${icon('fwd')}</button>
        <p class="small ink2">If Android says the setting is <b>restricted</b> (normal for apps installed outside the Play Store): <a href="#" data-act="appinfo">open Koban’s App info</a> → ⋮ menu (top right) → <b>Allow restricted settings</b>, then try again.</p>`)
      : html`<div class="banner warn">Notification capture works in the Android app.</div>`}
    <p class="small muted">Only apps you switch on below are read — and only their title + text are stored, on this phone. Other apps are only counted (name, never content) so you can find your bank’s app here.</p>
    <div class="sectionlabel">Reading</div>
    <div class="card">${sources.length ? html`<ul class="list">${sources.map((s) => html`<li class="item tap" data-src="${s.pkg}" style="${s.enabled ? '' : 'opacity:.5'}"><div class="grow"><div class="title ellipsis">${s.pkg}</div><div class="sub">→ ${s.account_name || 'card number or first everyday account'}${s.pattern ? ' · custom pattern' : ''}</div></div>${icon('fwd')}</li>`)}</ul>` : html`<p class="card-b small muted">No apps yet — pick your bank or wallet app from the list below once it has posted a notification.</p>`}</div>
    <div class="sectionlabel">Apps that posted notifications</div>
    <div class="card">${seen.length ? html`<ul class="list">${seen.map((s) => html`<li class="item"><div class="grow"><div class="title ellipsis">${s.label || s.pkg}</div><div class="sub">${s.pkg} · ${s.count} seen</div></div><button class="btn sm" data-add="${s.pkg}">Read</button></li>`)}</ul>` : html`<p class="card-b small muted">Nothing yet. After access is on, make a purchase or wait for your bank to notify you.</p>`}
      <button class="btn ghost sm" data-act="manual" style="margin:4px 8px 8px">+ Add app by package name</button></div>
    <div class="sectionlabel">Try the parser</div>
    <div class="card card-b" style="padding-top:12px"><textarea class="input" id="tt" placeholder="Paste a notification, e.g. “You spent $12.50 at Woolworths”"></textarea><div id="tr" class="small" style="margin-top:6px"></div></div>
    <div class="sectionlabel"><span>Recent captures</span><button class="btn sm ghost" data-act="reprocess">Process now</button></div>
    <div class="card">${log.length ? html`<ul class="list">${log.map((c) => html`<li class="item" data-cap="${c.id}"><div class="grow"><div class="sub">${new Date(c.posted_at).toLocaleString('en-AU')} · ${c.pkg}</div>
      <div class="small"><b>${c.title || ''}</b> ${c.text || ''}</div><div class="tiny ${c.status === 'ignored' ? 'muted' : 'pos'}">${c.status}${c.note ? ' · ' + c.note : ''}</div></div>
      ${c.status === 'ignored' ? html`<button class="btn sm" data-retry="${c.id}">Use</button>` : ''}</li>`)}</ul>` : html`<p class="card-b small muted">No captures yet.</p>`}</div>
    <p class="small muted">Wording not recognised? Long-press a capture, copy it and send it to Claude to add a pattern for your bank — or set a custom regex on the app above with named groups (?&lt;amount&gt;…) (?&lt;payee&gt;…).</p></div>`);
  const tt = root.querySelector('#tt');
  tt.oninput = () => {
    const lines = tt.value.split('\n');
    const p = parseNotification({ title: lines.length > 1 ? lines[0] : '', text: lines.length > 1 ? lines.slice(1).join(' ') : lines[0] });
    root.querySelector('#tr').innerHTML = String(p.ok ? html`<span class="pos">✓</span> ${money(p.amount)} · payee <b>${p.payee || '—'}</b> <span class="muted">(${p.via})</span>` : html`<span class="neg">✕ ${p.reason}</span>`);
  };
  root.onclick = async (e) => {
    const a = e.target.closest('[data-act]')?.dataset.act;
    if (a === 'perm') return native.openNotificationAccess();
    if (a === 'appinfo') { e.preventDefault(); return native.openAppSettings(); }
    if (a === 'reprocess') { const r = processCaptures(); return toast(`${r.created} created, ${r.ignored} ignored`); }
    if (a === 'manual') { const p = await promptDlg('Android package name', { placeholder: 'com.example.bank' }); if (p) { db.run('INSERT OR IGNORE INTO capture_sources(pkg, enabled) VALUES(?,1)', [p.trim()]); queueRender(); } return; }
    const add = e.target.closest('[data-add]');
    if (add) { db.run('INSERT OR IGNORE INTO capture_sources(pkg, enabled) VALUES(?,1)', [add.dataset.add]); return toast('Reading ' + add.dataset.add); }
    const rt = e.target.closest('[data-retry]');
    if (rt) { db.run("UPDATE capture_inbox SET status='new', note=NULL WHERE id=?", [+rt.dataset.retry]); const r = processCaptures(); if (!r.created) toast('Still couldn’t read an amount — try a custom pattern'); return; }
    const src = e.target.closest('[data-src]');
    if (src) return sourceSheet(src.dataset.src);
  };
}
async function sourceSheet(pkg) {
  const s0 = db.get('SELECT * FROM capture_sources WHERE pkg=?', [pkg]);
  const k = await menu(pkg, [
    { value: 'acct', label: 'Default account', sub: s0.account_id ? repo.account(s0.account_id)?.name : 'Not set' },
    { value: 'pattern', label: 'Custom pattern (regex)', sub: s0.pattern || 'Using built-in heuristics' },
    { value: 'toggle', label: s0.enabled ? 'Pause reading' : 'Resume reading' },
    { value: 'remove', label: 'Stop reading this app', danger: true },
  ]);
  if (k === 'acct') { const a = await pickAccount({}); if (a) db.run('UPDATE capture_sources SET account_id=? WHERE pkg=?', [a, pkg]); }
  if (k === 'pattern') { const p = await promptDlg('Regex with named groups', { value: s0.pattern || '', placeholder: 'spent \\$(?<amount>[\\d,.]+) at (?<payee>.+?)\\.', hint: 'Groups: amount (required), payee, dir (in/out).' }); if (p != null) { if (p) { try { new RegExp(p); } catch { return toast('Invalid regex'); } } db.run('UPDATE capture_sources SET pattern=? WHERE pkg=?', [p || null, pkg]); } }
  if (k === 'toggle') db.run('UPDATE capture_sources SET enabled=? WHERE pkg=?', [s0.enabled ? 0 : 1, pkg]);
  if (k === 'remove') db.run('DELETE FROM capture_sources WHERE pkg=?', [pkg]);
}

registerScreen('settings', { top: () => ({ title: 'Settings', back: true, noSettings: true }), render });
registerScreen('categories', { top: () => ({ title: 'Categories', back: true }), render: renderCategories });
registerScreen('rules', { top: () => ({ title: 'Rules', back: true }), render: renderRules });
registerScreen('capture', { top: () => ({ title: 'Notification capture', back: true }), render: renderCapture });
