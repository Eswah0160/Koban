// Receipt capture: photo -> Gemini (or on-device OCR fallback) -> review -> split transaction.
import * as repo from '../repo.js';
import { db } from '../db.js';
import { html, raw, openSheet, toast } from './dom.js';
import { registerScreen } from './app.js';
import { pickCategory } from './pickers.js';
import { pickFile } from './importer.js';
import { aiConfig, geminiReceipt, parseReceiptText, imageToB64 } from '../io/ai.js';
import { money, today, dateLabel } from '../util.js';
import { evalAmount } from './dom.js';
import * as native from '../native.js';

async function start({ attachTo = null, draft = null, b64 = null } = {}) {
  let img;
  try {
    if (b64) {
      const bin = atob(b64);
      const bytes = new Uint8Array(bin.length);
      for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
      img = await imageToB64(new Blob([bytes]));
    } else {
      const f = await pickFile('image/*');
      if (!f) return;
      img = await imageToB64(f);
    }
  } catch (e) { return toast('Couldn’t read that image'); }
  const busy = openSheet({ title: 'Reading receipt…', body: html`<img class="receipt-img" src="${img.dataUrl}" alt=""><p class="small muted" id="st">Starting…</p>` });
  const st = (m) => { const e = busy.el.querySelector('#st'); if (e) e.textContent = m; };
  const idx = repo.categoryIndex();
  const names = idx.categories.filter((c) => !c.hidden && !c.system).map((c) => c.name);
  let result = null, err = null;
  if (aiConfig().enabled) {
    st('Asking Gemini…');
    try { result = await geminiReceipt({ b64: img.b64, mime: img.mime, categoryNames: names }); } catch (e) { err = e.message; }
  }
  if (!result && native.ocrAvailable()) {
    st(err ? 'Gemini unavailable — using on-phone text recognition…' : 'Reading text on the phone…');
    try { const o = await native.ocr(img.b64); result = parseReceiptText(o.text); result.ocrText = o.text; } catch (e) { err = (err ? err + ' / ' : '') + e.message; }
  }
  if (!result) result = { merchant: draft?.payee || '', date: today(), total: Math.abs(draft?.amount || 0), items: [], via: 'manual' };
  busy.close();
  review({ img, result, err, attachTo, draft });
}

function review({ img, result, err, attachTo, draft }) {
  const idx = repo.categoryIndex();
  const byName = (n) => idx.categories.find((c) => c.name === n)?.id ?? null;
  const items = result.items.map((i) => ({ ...i, category_id: byName(i.category) ?? byName(result.category) }));
  const r = { payee: result.merchant, date: result.date || today(), total: result.total, category_id: byName(result.category) };
  const cmap = new Map(db.all('SELECT * FROM card_map').map((c) => [c.last4, c.account_id]));
  let accountId = draft?.account_id || (result.card_last4 && cmap.get(result.card_last4)) || Number(repo.meta('last_account', 0)) || repo.accounts()[0]?.id;
  const candidates = () => db.all(`SELECT t.*, a.name AS account_name FROM transactions t JOIN accounts a ON a.id=t.account_id
    WHERE t.amount=? AND t.date BETWEEN date(?, '-4 day') AND date(?, '+4 day') AND t.receipt_id IS NULL ORDER BY abs(julianday(t.date)-julianday(?)) LIMIT 5`, [-r.total, r.date, r.date, r.date]);
  let attach = attachTo ?? candidates()[0]?.id ?? null;

  const groups = () => {
    const g = new Map();
    for (const it of items) g.set(it.category_id ?? r.category_id ?? null, (g.get(it.category_id ?? r.category_id ?? null) || 0) + it.amount);
    const itemsSum = items.reduce((s, i) => s + i.amount, 0);
    const rest = r.total - itemsSum;
    if (rest !== 0) g.set(r.category_id ?? null, (g.get(r.category_id ?? null) || 0) + rest);
    return { g, rest };
  };
  const body = () => {
    const { g, rest } = groups();
    const cands = attachTo ? [repo.txn(attachTo)] : candidates();
    return html`
      <img class="receipt-img" src="${img.dataUrl}" alt="Receipt">
      <p class="small muted">Read by ${result.via === 'gemini' ? 'Gemini' : result.via === 'ocr' ? 'on-phone OCR (check carefully)' : 'nobody — fill it in'}${err ? html` · <span class="neg">${err}</span>` : ''}</p>
      <label class="pickrow"><span class="k">Payee</span><input id="rp" value="${r.payee}"></label>
      <label class="pickrow"><span class="k">Date</span><input id="rd" type="date" value="${r.date}"></label>
      <label class="pickrow"><span class="k">Total</span><input id="rt" inputmode="decimal" value="${(r.total / 100).toFixed(2)}"></label>
      <button class="pickrow" data-act="maincat"><span class="k">Category</span><span class="v">${idx.name(r.category_id)}</span></button>
      <label class="pickrow"><span class="k">Account</span><select id="ra">${repo.accounts().map((a) => html`<option value="${a.id}" ${a.id === accountId ? raw('selected') : ''}>${a.name}</option>`)}</select></label>
      ${cands.length ? html`<div class="lbl" style="margin-top:10px">Link to an existing transaction?</div>
        ${cands.filter(Boolean).map((c) => html`<label class="row small" style="padding:6px 0"><input type="radio" name="att" value="${c.id}" ${attach === c.id ? raw('checked') : ''}> ${c.payee} · ${money(c.amount)} · ${dateLabel(c.date)} · ${c.account_name || ''}</label>`)}
        ${attachTo ? '' : html`<label class="row small" style="padding:6px 0"><input type="radio" name="att" value="" ${attach == null ? raw('checked') : ''}> No — create a new transaction</label>`}` : ''}
      <div class="lbl" style="margin-top:12px">Items (${items.length})</div>
      ${items.map((it, i) => html`<div class="row" style="padding:5px 0;border-bottom:1px solid var(--line)"><span class="grow small ellipsis">${it.description}</span>
        <button class="btn sm" data-act="itemcat" data-i="${i}" style="max-width:40%"><span class="ellipsis">${idx.name(it.category_id ?? r.category_id)}</span></button><span class="num small" style="width:64px;text-align:right">${money(it.amount)}</span></div>`)}
      ${rest ? html`<p class="small muted">${money(rest)} not itemised (tax, rounding, discounts) → ${idx.name(r.category_id)}</p>` : ''}
      <div class="lbl" style="margin-top:12px">Will be recorded as</div>
      <table class="tbl">${[...g.entries()].map(([cid, v]) => html`<tr><td>${idx.name(cid)}</td><td class="n">${money(-v)}</td></tr>`)}</table>`;
  };
  const read = () => {
    const el = s.el;
    r.payee = el.querySelector('#rp').value.trim();
    r.date = el.querySelector('#rd').value || today();
    const t = evalAmount(el.querySelector('#rt').value); if (!Number.isNaN(t)) r.total = Math.abs(t);
    accountId = +el.querySelector('#ra').value;
    const a = el.querySelector('input[name=att]:checked'); attach = a ? (a.value ? +a.value : null) : attach;
  };
  const s = openSheet({
    title: 'Receipt', body: body(),
    footer: html`<button class="btn primary block" data-act="save">Save</button>`,
    actions: {
      maincat: async () => { read(); const c = await pickCategory({ date: r.date }); if (c !== undefined) { r.category_id = c; s.setBody(body()); } },
      itemcat: async (b) => { read(); const c = await pickCategory({ date: r.date }); if (c !== undefined) { items[+b.dataset.i].category_id = c; s.setBody(body()); } },
      save: (b, e, api) => {
        read();
        if (!r.total) return toast('Enter the total');
        const { g } = groups();
        if ([...g.keys()].some((k) => k == null)) return toast('Pick a category');
        const rid = db.insert('receipts', { ai_json: JSON.stringify(result), ocr_text: result.ocrText || null });
        try { const url = native.saveReceiptImage(rid, img.b64); db.update('receipts', rid, { path: url.startsWith('data:') ? url : `receipts/${rid}.jpg` }); } catch (e2) { toast('Image not saved: ' + e2.message); }
        const splits = [...g.entries()].map(([cid, v]) => ({ category_id: cid, amount: -v }));
        if (attach) {
          const t = repo.txn(attach);
          const upd = { ...t, receipt_id: rid, approved: 1, payee: t.payee || r.payee };
          if (!t.transfer_account_id && Math.abs(t.amount) === r.total) { if (splits.length > 1) { upd.splits = splits; } else { upd.splits = null; upd.category_id = splits[0].category_id; } }
          repo.saveTxn(upd);
          toast('Receipt attached');
        } else {
          repo.saveTxn({ account_id: accountId, date: r.date, amount: -r.total, payee: r.payee, category_id: splits.length === 1 ? splits[0].category_id : null,
            splits: splits.length > 1 ? splits : null, source: 'receipt', receipt_id: rid, approved: 1, memo: items.length ? `${items.length} items` : null });
          toast(`Saved ${money(-r.total)} at ${r.payee}`);
        }
        repo.setMeta('last_account', accountId);
        api.close();
      },
    },
  });
  s.el.addEventListener('change', (e) => { if (['rd', 'rt'].includes(e.target.id)) { read(); s.setBody(body()); } });
}

function view(rid) {
  const r = db.get('SELECT * FROM receipts WHERE id=?', [rid]);
  if (!r) return toast('Receipt not found');
  let data = null; try { data = JSON.parse(r.ai_json); } catch {}
  const src = native.receiptUrl(r.path);
  openSheet({ title: 'Receipt', body: html`${src ? html`<img class="receipt-img" style="max-height:60vh" src="${src}" alt="Receipt">` : html`<p class="muted">Image not available in this browser.</p>`}
    ${data ? html`<p class="small"><b>${data.merchant}</b> · ${data.date || ''} · ${money(data.total || 0)}</p><table class="tbl">${(data.items || []).map((i) => html`<tr><td class="small">${i.description}</td><td class="n small">${money(i.amount)}</td></tr>`)}</table>` : ''}` });
}

registerScreen('receipt', { start, view, render() {} });
